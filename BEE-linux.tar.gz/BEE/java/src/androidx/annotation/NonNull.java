package androidx.annotation;

import java.lang.annotation.*;

/** Ca în AndroidX: doar o adnotare (în simulator nu face nimic). */
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.METHOD, ElementType.PARAMETER, ElementType.FIELD, ElementType.LOCAL_VARIABLE, ElementType.TYPE_USE})
public @interface NonNull {}
