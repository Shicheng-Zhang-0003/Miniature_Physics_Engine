package org.opencv.core;

/** Ca în OpenCV (Java): până la 4 valori, ex. o culoare în spațiul ales (new Scalar(32, 176, 0) în YCrCb). */
public class Scalar {
    public double[] val;

    public Scalar(double v0, double v1, double v2, double v3) { val = new double[] {v0, v1, v2, v3}; }
    public Scalar(double v0, double v1, double v2) { this(v0, v1, v2, 0); }
    public Scalar(double v0, double v1) { this(v0, v1, 0, 0); }
    public Scalar(double v0) { this(v0, 0, 0, 0); }
    public Scalar(double[] vals) { val = new double[4]; set(vals); }

    public void set(double[] vals) {
        for (int i = 0; i < 4; i++) val[i] = vals != null && vals.length > i ? vals[i] : 0;
    }
    public static Scalar all(double v) { return new Scalar(v, v, v, v); }
    public Scalar clone() { return new Scalar(val); }
    public Scalar mul(Scalar it, double scale) {
        return new Scalar(val[0] * it.val[0] * scale, val[1] * it.val[1] * scale, val[2] * it.val[2] * scale, val[3] * it.val[3] * scale);
    }
    public Scalar mul(Scalar it) { return mul(it, 1); }
    public Scalar conj() { return new Scalar(val[0], -val[1], -val[2], -val[3]); }
    public boolean isReal() { return val[1] == 0 && val[2] == 0 && val[3] == 0; }

    @Override public int hashCode() { return java.util.Arrays.hashCode(val); }
    @Override public boolean equals(Object o) { return o instanceof Scalar && java.util.Arrays.equals(val, ((Scalar) o).val); }
    @Override public String toString() { return "[" + val[0] + ", " + val[1] + ", " + val[2] + ", " + val[3] + "]"; }
}
