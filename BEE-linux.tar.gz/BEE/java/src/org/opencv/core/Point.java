package org.opencv.core;

/** Ca în OpenCV (Java): un punct în imagine (pixeli). */
public class Point {
    public double x, y;

    public Point(double x, double y) { this.x = x; this.y = y; }
    public Point() { this(0, 0); }
    public Point(double[] vals) { this(); set(vals); }

    public void set(double[] vals) {
        x = vals != null && vals.length > 0 ? vals[0] : 0;
        y = vals != null && vals.length > 1 ? vals[1] : 0;
    }
    public Point clone() { return new Point(x, y); }
    public double dot(Point p) { return x * p.x + y * p.y; }
    public boolean inside(Rect r) { return r.contains(this); }

    @Override public int hashCode() { return Double.hashCode(x) * 31 + Double.hashCode(y); }
    @Override public boolean equals(Object o) { return o instanceof Point && ((Point) o).x == x && ((Point) o).y == y; }
    @Override public String toString() { return "{" + x + ", " + y + "}"; }
}
