package org.opencv.core;

/** Ca în OpenCV (Java): un dreptunghi cu laturile pe axe (pixeli). */
public class Rect {
    public int x, y, width, height;

    public Rect(int x, int y, int width, int height) { this.x = x; this.y = y; this.width = width; this.height = height; }
    public Rect() { this(0, 0, 0, 0); }
    public Rect(Point p1, Point p2) {
        x = (int) Math.min(p1.x, p2.x);
        y = (int) Math.min(p1.y, p2.y);
        width = (int) Math.max(p1.x, p2.x) - x;
        height = (int) Math.max(p1.y, p2.y) - y;
    }
    public Rect(Point p, Size s) { this((int) p.x, (int) p.y, (int) s.width, (int) s.height); }
    public Rect(double[] vals) { set(vals); }

    public void set(double[] vals) {
        x = vals != null && vals.length > 0 ? (int) vals[0] : 0;
        y = vals != null && vals.length > 1 ? (int) vals[1] : 0;
        width = vals != null && vals.length > 2 ? (int) vals[2] : 0;
        height = vals != null && vals.length > 3 ? (int) vals[3] : 0;
    }
    public Rect clone() { return new Rect(x, y, width, height); }
    public Point tl() { return new Point(x, y); }
    public Point br() { return new Point(x + width, y + height); }
    public Size size() { return new Size(width, height); }
    public double area() { return width * (double) height; }
    public boolean empty() { return width <= 0 || height <= 0; }
    public boolean contains(Point p) { return x <= p.x && p.x < x + width && y <= p.y && p.y < y + height; }

    @Override public int hashCode() { return ((x * 31 + y) * 31 + width) * 31 + height; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof Rect)) return false;
        Rect r = (Rect) o;
        return x == r.x && y == r.y && width == r.width && height == r.height;
    }
    @Override public String toString() { return "{" + x + ", " + y + ", " + width + "x" + height + "}"; }
}
