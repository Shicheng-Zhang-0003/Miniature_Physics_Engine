package org.opencv.core;

/** Ca în OpenCV (Java): lățime x înălțime (pixeli). */
public class Size {
    public double width, height;

    public Size(double width, double height) { this.width = width; this.height = height; }
    public Size() { this(0, 0); }
    public Size(Point p) { this(p.x, p.y); }
    public Size(double[] vals) { this(); set(vals); }

    public void set(double[] vals) {
        width = vals != null && vals.length > 0 ? vals[0] : 0;
        height = vals != null && vals.length > 1 ? vals[1] : 0;
    }
    public double area() { return width * height; }
    public boolean empty() { return width <= 0 || height <= 0; }
    public Size clone() { return new Size(width, height); }

    @Override public int hashCode() { return Double.hashCode(width) * 31 + Double.hashCode(height); }
    @Override public boolean equals(Object o) { return o instanceof Size && ((Size) o).width == width && ((Size) o).height == height; }
    @Override public String toString() { return (int) width + "x" + (int) height; }
}
