package org.opencv.core;

/** Ca în OpenCV (Java): un dreptunghi rotit (centru, mărime, unghi în grade), ex. getBoxFit() al unui blob. */
public class RotatedRect {
    public Point center;
    public Size size;
    public double angle;

    public RotatedRect() { this(new Point(), new Size(), 0); }
    public RotatedRect(Point c, Size s, double a) { center = c.clone(); size = s.clone(); angle = a; }
    public RotatedRect(double[] vals) { this(); set(vals); }

    public void set(double[] vals) {
        center.set(vals);
        size.set(vals != null && vals.length > 2 ? new double[] {vals[2], vals.length > 3 ? vals[3] : 0} : null);
        angle = vals != null && vals.length > 4 ? vals[4] : 0;
    }

    /** Cele 4 colțuri, în aceeași ordine ca OpenCV. */
    public void points(Point[] pt) {
        double a = Math.sin(Math.toRadians(angle)) * 0.5, b = Math.cos(Math.toRadians(angle)) * 0.5;
        pt[0] = new Point(center.x - a * size.height - b * size.width, center.y + b * size.height - a * size.width);
        pt[1] = new Point(center.x + a * size.height - b * size.width, center.y - b * size.height - a * size.width);
        pt[2] = new Point(2 * center.x - pt[0].x, 2 * center.y - pt[0].y);
        pt[3] = new Point(2 * center.x - pt[1].x, 2 * center.y - pt[1].y);
    }

    public Rect boundingRect() {
        Point[] pt = new Point[4];
        points(pt);
        double x0 = pt[0].x, y0 = pt[0].y, x1 = pt[0].x, y1 = pt[0].y;
        for (Point p : pt) {
            x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y);
            x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y);
        }
        int x = (int) Math.floor(x0), y = (int) Math.floor(y0);
        return new Rect(x, y, (int) Math.ceil(x1) - x + 1, (int) Math.ceil(y1) - y + 1);
    }
    public RotatedRect clone() { return new RotatedRect(center, size, angle); }

    @Override public int hashCode() { return (center.hashCode() * 31 + size.hashCode()) * 31 + Double.hashCode(angle); }
    @Override public boolean equals(Object o) {
        if (!(o instanceof RotatedRect)) return false;
        RotatedRect r = (RotatedRect) o;
        return center.equals(r.center) && size.equals(r.size) && angle == r.angle;
    }
    @Override public String toString() { return "{ " + center + " " + size + " * " + angle + " }"; }
}
