package org.firstinspires.ftc.vision.opencv;

import com.qualcomm.robotcore.util.SortOrder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.ftcsim.SimClient;
import org.ftcsim.SimVisionPortal;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.RotatedRect;
import org.opencv.core.Size;

/**
 * Blob-urile simulate: webcam-ul primește piesele din câmpul vizual (centru, rază, culoare), deci fiecare piesă de
 * culoarea căutată e un disc în imagine, tăiat de ROI. Conturul, aria, cercul etc. se calculează din acest disc.
 * shortcut: piesele de aceeași culoare care se ating rămân blob-uri separate (OpenCV le-ar uni) și o piesă ascunsă
 * parțial de alta mai apropiată are conturul întreg; dacă echipele se bazează pe asta, decupați discurile între ele.
 */
class ColorBlobLocatorProcessorImpl extends ColorBlobLocatorProcessor implements SimVisionPortal.Processor {
    private final ColorRange colorRange;
    private final ImageRegion roiImg;
    private final List<BlobFilter> filters = new ArrayList<>();
    private volatile BlobSort sort;
    private SimVisionPortal portal;
    private SimClient.WebcamFrame last;
    private List<Blob> blobs = new ArrayList<>();

    ColorBlobLocatorProcessorImpl(ColorRange colorRange, ImageRegion roiImg) {
        this.colorRange = colorRange;
        this.roiImg = roiImg;
    }

    @Override public void attach(SimVisionPortal p) { portal = p; }
    @Override public synchronized void addFilter(BlobFilter filter) { filters.add(filter); }
    @Override public synchronized void removeFilter(BlobFilter filter) { filters.remove(filter); }
    @Override public synchronized void removeAllFilters() { filters.clear(); }
    @Override public void setSort(BlobSort sort) { this.sort = sort; }

    /** Ca în SDK: aceeași listă până la cadrul următor (Util.filterByCriteria o modifică pe loc). */
    @Override public synchronized List<Blob> getBlobs() {
        SimClient.WebcamFrame f = portal == null ? null : portal.frameFor(this);
        if (f != null && f != last) {
            last = f;
            blobs = find(f);
        }
        return blobs;
    }

    private List<Blob> find(SimClient.WebcamFrame f) {
        int w = portal.width(), h = portal.height();
        Rect roi = roiImg.asOpenCvRect(w, h);
        List<Blob> out = new ArrayList<>();
        for (double[] d : discs(f, w, h)) {
            if (!colorRange.contains((int) d[3])) continue;
            List<Point> poly = new ArrayList<>();
            for (int i = 0; i < 32; i++) {
                double a = 2 * Math.PI * i / 32;
                poly.add(new Point(d[0] + d[2] * Math.cos(a), d[1] + d[2] * Math.sin(a)));
            }
            poly = clip(poly, roi);
            if (poly.size() >= 3) out.add(new SimBlob(poly));
        }
        for (BlobFilter b : filters) Util.filterByCriteria(b.criteria, b.minValue, b.maxValue, out);
        BlobSort s = sort;
        if (s != null) Util.sortByCriteria(s.criteria, s.sortOrder, out);
        else Util.sortByCriteria(BlobCriteria.BY_CONTOUR_AREA, SortOrder.DESCENDING, out);
        return out;
    }

    /** Piesele văzute, ca discuri în imagine {u, v, rază (pixeli), culoare RGB, distanță}, de la cea mai depărtată la cea mai apropiată. */
    static List<double[]> discs(SimClient.WebcamFrame f, int w, int h) {
        double fx = w / 2.0 / Math.tan(Math.toRadians(f.hfov) / 2);
        List<double[]> out = new ArrayList<>();
        for (SimClient.Piece p : f.pieces) {
            if (p.y > p.r) out.add(new double[] {w / 2.0 + fx * p.x / p.y, h / 2.0 - fx * p.z / p.y, fx * p.r / p.y, p.rgb, p.y});
        }
        out.sort(Comparator.comparingDouble(d -> -d[4]));
        return out;
    }

    /** Sutherland-Hodgman: poligonul tăiat de dreptunghi. */
    private static List<Point> clip(List<Point> poly, Rect r) {
        double[][] edges = {{1, 0, r.x}, {-1, 0, -(r.x + r.width - 1)}, {0, 1, r.y}, {0, -1, -(r.y + r.height - 1)}};  // a·x + b·y >= c
        for (double[] e : edges) {
            List<Point> in = poly;
            poly = new ArrayList<>();
            for (int i = 0; i < in.size(); i++) {
                Point p = in.get(i), q = in.get((i + 1) % in.size());
                double dp = e[0] * p.x + e[1] * p.y - e[2], dq = e[0] * q.x + e[1] * q.y - e[2];
                if (dp >= 0) poly.add(p);
                if ((dp >= 0) != (dq >= 0)) {
                    double t = dp / (dp - dq);
                    poly.add(new Point(p.x + t * (q.x - p.x), p.y + t * (q.y - p.y)));
                }
            }
            if (poly.isEmpty()) break;
        }
        return poly;
    }

    /** Un blob convex: aria, perimetrul și cutia din poligon (cutia cu laturile pe axe e cea minimă pentru un disc tăiat de ROI). */
    private static class SimBlob extends Blob {
        private final Point[] pts;
        private final double area, arcLength;
        private final RotatedRect box;
        private final Circle circle;

        SimBlob(List<Point> poly) {
            pts = poly.toArray(new Point[0]);
            double a = 0, len = 0, x0 = Double.MAX_VALUE, y0 = Double.MAX_VALUE, x1 = -Double.MAX_VALUE, y1 = -Double.MAX_VALUE;
            for (int i = 0; i < pts.length; i++) {
                Point p = pts[i], q = pts[(i + 1) % pts.length];
                a += p.x * q.y - q.x * p.y;
                len += Math.hypot(q.x - p.x, q.y - p.y);
                x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y);
                x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y);
            }
            area = Math.abs(a) / 2;
            arcLength = len;
            Point c = new Point((x0 + x1) / 2, (y0 + y1) / 2);
            box = new RotatedRect(c, new Size(x1 - x0, y1 - y0), 0);
            double rad = 0;
            for (Point p : pts) rad = Math.max(rad, Math.hypot(p.x - c.x, p.y - c.y));
            circle = new Circle(c, (float) rad);  // cercul în care încape (minim pentru un disc întreg)
        }

        @Override public Point[] getContourPoints() { return pts; }
        @Override public int getContourArea() { return Math.max(1, (int) area); }
        @Override public double getDensity() { return getContourArea() / Math.max(area, 1); }  // conturul e convex: aria lui = a anvelopei
        @Override public double getAspectRatio() {
            double a = Math.max(box.size.width, 1), b = Math.max(box.size.height, 1);
            return Math.max(a, b) / Math.min(a, b);
        }
        @Override public RotatedRect getBoxFit() { return box; }
        @Override public double getArcLength() { return arcLength; }
        @Override public double getCircularity() { return 4 * Math.PI * getContourArea() / (arcLength * arcLength); }
        @Override public Circle getCircle() { return circle; }
    }
}
