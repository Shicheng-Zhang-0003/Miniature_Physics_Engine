package org.firstinspires.ftc.vision.opencv;

import org.opencv.core.Point;

/** Ca în SDK-ul FTC: un cerc (pixeli), ex. cercul în care încape un blob. */
public class Circle {
    private final Point center;
    private final float radius;

    public Circle(Point center, float radius) {
        this.center = center;
        this.radius = radius;
    }
    public Circle(float x, float y, float radius) { this(new Point(x, y), radius); }

    public Point getCenter() { return center; }
    public float getRadius() { return radius; }
    public float getX() { return (float) center.x; }
    public float getY() { return (float) center.y; }
}
