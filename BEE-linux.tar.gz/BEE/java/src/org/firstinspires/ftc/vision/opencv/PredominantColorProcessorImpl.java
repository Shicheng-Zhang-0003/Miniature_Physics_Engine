package org.firstinspires.ftc.vision.opencv;

import android.graphics.Color;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.ftcsim.SimClient;
import org.ftcsim.SimVisionPortal;
import org.opencv.core.Rect;

/**
 * Culoarea dominantă simulată. Zona (ROI) e eșantionată pe o grilă: un punct are culoarea piesei care îl acoperă
 * (cea mai apropiată), altfel a podelei. Ca procesorul real (k-means pe Cr/Cb): Y = media zonei, Cr / Cb = ale culorii
 * celei mai întinse; apoi aceleași praguri ca în SDK 11 pentru BLACK / WHITE și nuanța cea mai apropiată.
 */
class PredominantColorProcessorImpl extends PredominantColorProcessor implements SimVisionPortal.Processor {
    static final int FLOOR_RGB = 0x56565c;  // plăcile de spumă gri (view3d.gd, C_TILE_A)

    private final ImageRegion roiImg;
    private final List<Swatch> swatches;
    private SimVisionPortal portal;
    private SimClient.WebcamFrame last;
    private volatile Result result = new Result();

    PredominantColorProcessorImpl(ImageRegion roiImg, Swatch[] swatches) {
        this.roiImg = roiImg;
        this.swatches = Arrays.asList(swatches.clone());
    }

    @Override public void attach(SimVisionPortal p) { portal = p; }

    @Override public synchronized Result getAnalysis() {
        SimClient.WebcamFrame f = portal == null ? null : portal.frameFor(this);
        if (f != null && f != last) {
            last = f;
            result = analyze(f);
        }
        return result;
    }

    private Result analyze(SimClient.WebcamFrame f) {
        int w = portal.width(), h = portal.height();
        Rect roi = roiImg.asOpenCvRect(w, h);
        List<double[]> discs = ColorBlobLocatorProcessorImpl.discs(f, w, h);
        Map<Integer, Integer> count = new HashMap<>();
        double ySum = 0;
        int n = 16;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                double u = roi.x + (i + 0.5) * roi.width / n, v = roi.y + (j + 0.5) * roi.height / n;
                int rgb = FLOOR_RGB;
                for (double[] d : discs) if (Math.hypot(u - d[0], v - d[1]) <= d[2]) rgb = (int) d[3];  // cea mai apropiată e ultima
                count.merge(rgb, 1, Integer::sum);
                ySum += ColorRange.toSpace(rgb, ColorSpace.YCrCb)[0];
            }
        }
        int top = FLOOR_RGB;
        for (Map.Entry<Integer, Integer> e : count.entrySet()) if (e.getValue() > count.getOrDefault(top, 0)) top = e.getKey();
        int[] ycc = ColorRange.toSpace(top, ColorSpace.YCrCb);
        int[] yCrCb = {ColorRange.clip(ySum / (n * n)), ycc[1], ycc[2]};
        int[] rgb = {ColorRange.clip(yCrCb[0] + 1.403 * (yCrCb[1] - 128)),
                ColorRange.clip(yCrCb[0] - 0.714 * (yCrCb[1] - 128) - 0.344 * (yCrCb[2] - 128)),
                ColorRange.clip(yCrCb[0] + 1.773 * (yCrCb[2] - 128))};
        int color = Color.rgb(rgb[0], rgb[1], rgb[2]);
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        int[] hsvOut = {(int) (hsv[0] / 2), (int) (hsv[1] * 255), (int) (hsv[2] * 255)};
        return new Result(closest(hsv[0], hsv[1], hsv[2]), color, rgb, hsvOut, yCrCb);
    }

    /** Ca în SDK 11: alb / negru după saturație și luminozitate, altfel nuanța cea mai apropiată dintre cele cerute. */
    private Swatch closest(float hue, float sat, float val) {
        if (sat < 0.15 && val > 0.55 && swatches.contains(Swatch.WHITE)) return Swatch.WHITE;
        if (val < 0.1 || ((sat < 0.2 || val < 0.2) && swatches.contains(Swatch.BLACK))) return Swatch.BLACK;
        Swatch best = null;
        int bestDiff = 360;
        for (Swatch s : swatches) {
            if (s.hue < 0) continue;
            int d = Math.abs((int) hue - s.hue);
            if (d > 180) d = 360 - d;
            if (d < bestDiff) {
                bestDiff = d;
                best = s;
            }
        }
        return best;
    }
}
