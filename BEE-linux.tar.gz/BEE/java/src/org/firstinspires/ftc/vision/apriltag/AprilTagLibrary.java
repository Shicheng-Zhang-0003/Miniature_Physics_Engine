package org.firstinspires.ftc.vision.apriltag;

import java.util.ArrayList;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;

/** Ca în SDK-ul FTC: tag-urile cunoscute (doar pentru ele detectorul calculează poza). */
public class AprilTagLibrary {
    private final AprilTagMetadata[] data;

    private AprilTagLibrary(AprilTagMetadata[] data) { this.data = data; }

    public AprilTagMetadata[] getAllTags() { return data; }

    public AprilTagMetadata lookupTag(int id) {
        for (AprilTagMetadata m : data) if (m.id == id) return m;
        return null;
    }

    public static class Builder {
        private final ArrayList<AprilTagMetadata> data = new ArrayList<>();
        private boolean allowOverwrite = false;

        public Builder setAllowOverwrite(boolean allowOverwrite) { this.allowOverwrite = allowOverwrite; return this; }

        public Builder addTag(AprilTagMetadata metadata) {
            for (AprilTagMetadata m : new ArrayList<>(data)) {
                if (m.id != metadata.id) continue;
                if (!allowOverwrite) {
                    throw new RuntimeException("You attempted to add a tag to the library when it already contains a tag with that ID. "
                            + "You can call .setAllowOverwrite(true) to allow overwriting the existing entry");
                }
                data.remove(m);
            }
            data.add(metadata);
            return this;
        }
        public Builder addTag(int id, String name, double size, VectorF fieldPosition, DistanceUnit distanceUnit, Quaternion fieldOrientation) {
            return addTag(new AprilTagMetadata(id, name, size, fieldPosition, distanceUnit, fieldOrientation));
        }
        public Builder addTag(int id, String name, double size, DistanceUnit distanceUnit) {
            return addTag(new AprilTagMetadata(id, name, size, new VectorF(0, 0, 0), distanceUnit, Quaternion.identityQuaternion()));
        }
        public Builder addTags(AprilTagLibrary library) {
            for (AprilTagMetadata m : library.getAllTags()) addTag(m);
            return this;
        }
        public AprilTagLibrary build() { return new AprilTagLibrary(data.toArray(new AprilTagMetadata[0])); }
    }
}
