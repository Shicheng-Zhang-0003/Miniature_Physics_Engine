package org.firstinspires.ftc.vision.opencv;

import com.qualcomm.robotcore.util.Range;
import org.opencv.core.Rect;

/** Ca în SDK-ul FTC: zona din imagine în care caută un procesor de culoare (ROI). */
public class ImageRegion {
    final boolean imageCoords;
    final double left, top, right, bottom;

    private ImageRegion(boolean imageCoords, double left, double top, double right, double bottom) {
        this.imageCoords = imageCoords;
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    /** În pixeli (0, 0 = colțul din stânga sus). */
    public static ImageRegion asImageCoordinates(int left, int top, int right, int bottom) {
        return new ImageRegion(true, left, top, right, bottom);
    }

    /** -1..1 pe ambele axe, centrul imaginii = (0, 0), y în sus. */
    public static ImageRegion asUnityCenterCoordinates(double left, double top, double right, double bottom) {
        return new ImageRegion(false, left, top, right, bottom);
    }

    public static ImageRegion entireFrame() { return asUnityCenterCoordinates(-1, 1, 1, -1); }

    /** Ca în SDK: dreptunghiul în pixeli, mutat înăuntrul imaginii. */
    protected Rect asOpenCvRect(int width, int height) {
        Rect r = new Rect();
        if (imageCoords) {
            r.x = (int) left;
            r.y = (int) top;
            r.width = (int) (right - left);
            r.height = (int) (bottom - top);
        } else {
            r.x = (int) Range.scale(left, -1, 1, 0, width);
            r.y = (int) (height - Range.scale(top, -1, 1, 0, height));
            r.width = (int) Range.scale(right - left, 0, 2, 0, width);
            r.height = (int) Range.scale(top - bottom, 0, 2, 0, height);
        }
        r.x = Math.min(Math.max(r.x, 0), width - r.width);
        r.y = Math.min(Math.max(r.y, 0), height - r.height);
        return r;
    }
}
