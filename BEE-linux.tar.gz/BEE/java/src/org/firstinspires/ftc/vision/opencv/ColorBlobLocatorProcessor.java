package org.firstinspires.ftc.vision.opencv;

import com.qualcomm.robotcore.util.SortOrder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.firstinspires.ftc.vision.VisionProcessor;
import org.opencv.core.Point;
import org.opencv.core.RotatedRect;

/** Ca în SDK-ul FTC 11: petele (blob-urile) de o anumită culoare din imagine (simulat de ColorBlobLocatorProcessorImpl). */
public abstract class ColorBlobLocatorProcessor implements VisionProcessor {
    public enum ContourMode { EXTERNAL_ONLY, ALL_FLATTENED_HIERARCHY }

    public enum MorphOperationType { OPENING, CLOSING }

    public enum BlobCriteria { BY_CONTOUR_AREA, BY_DENSITY, BY_ASPECT_RATIO, BY_ARC_LENGTH, BY_CIRCULARITY }

    public static class BlobFilter {
        public final BlobCriteria criteria;
        public final double minValue;
        public final double maxValue;

        public BlobFilter(BlobCriteria criteria, double minValue, double maxValue) {
            this.criteria = criteria;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }
    }

    public static class BlobSort {
        public final BlobCriteria criteria;
        public final SortOrder sortOrder;

        public BlobSort(BlobCriteria criteria, SortOrder sortOrder) {
            this.criteria = criteria;
            this.sortOrder = sortOrder;
        }
    }

    /** shortcut: fără getContour() / getContourAsFloat() (tipurile Mat din OpenCV nu există aici); getContourPoints() le înlocuiește. */
    public abstract static class Blob {
        public abstract Point[] getContourPoints();
        public abstract int getContourArea();
        public abstract double getDensity();
        public abstract double getAspectRatio();
        public abstract RotatedRect getBoxFit();
        public abstract double getArcLength();
        public abstract double getCircularity();
        public abstract Circle getCircle();
    }

    public static class Builder {
        private ColorRange colorRange;
        private ContourMode contourMode;
        private ImageRegion imageRegion = ImageRegion.entireFrame();

        public Builder setDrawContours(boolean drawContours) { return this; }
        public Builder setBoxFitColor(int color) { return this; }
        public Builder setCircleFitColor(int color) { return this; }
        public Builder setRoiColor(int color) { return this; }
        public Builder setContourColor(int color) { return this; }
        public Builder setTargetColorRange(ColorRange colorRange) { this.colorRange = colorRange; return this; }
        public Builder setContourMode(ContourMode contourMode) { this.contourMode = contourMode; return this; }
        public Builder setRoi(ImageRegion roi) { imageRegion = roi; return this; }
        public Builder setBlurSize(int blurSize) { return this; }
        public Builder setMorphOperationType(MorphOperationType morphOperationType) { return this; }
        public Builder setErodeSize(int erodeSize) { return this; }
        public Builder setDilateSize(int dilateSize) { return this; }

        public ColorBlobLocatorProcessor build() {
            if (imageRegion == null) throw new IllegalArgumentException("You must set a region of interest!");
            if (colorRange == null) throw new IllegalArgumentException("You must set a color range!");
            if (contourMode == null) throw new IllegalArgumentException("You must set a contour mode!");
            return new ColorBlobLocatorProcessorImpl(colorRange, imageRegion);
        }
    }

    public abstract void addFilter(BlobFilter filter);
    public abstract void removeFilter(BlobFilter filter);
    public abstract void removeAllFilters();
    public abstract void setSort(BlobSort sort);
    public abstract List<Blob> getBlobs();

    public static class Util {
        static double value(BlobCriteria criteria, Blob b) {
            switch (criteria) {
                case BY_CONTOUR_AREA: return b.getContourArea();
                case BY_DENSITY: return b.getDensity();
                case BY_ASPECT_RATIO: return b.getAspectRatio();
                case BY_ARC_LENGTH: return b.getArcLength();
                default: return b.getCircularity();
            }
        }

        /** Scoate blob-urile cu valoarea în afara [minValue, maxValue]. */
        public static void filterByCriteria(BlobCriteria criteria, double minValue, double maxValue, List<Blob> blobs) {
            List<Blob> out = new ArrayList<>();
            for (Blob b : blobs) {
                double v = value(criteria, b);
                if (v > maxValue || v < minValue) out.add(b);
            }
            blobs.removeAll(out);
        }

        public static void sortByCriteria(BlobCriteria criteria, SortOrder sortOrder, List<Blob> blobs) {
            Comparator<Blob> c = Comparator.comparingDouble(b -> value(criteria, b));
            blobs.sort(sortOrder == SortOrder.DESCENDING ? c.reversed() : c);
        }

        public static void filterByArea(double minArea, double maxArea, List<Blob> blobs) { filterByCriteria(BlobCriteria.BY_CONTOUR_AREA, minArea, maxArea, blobs); }
        public static void sortByArea(SortOrder sortOrder, List<Blob> blobs) { sortByCriteria(BlobCriteria.BY_CONTOUR_AREA, sortOrder, blobs); }
        public static void filterByDensity(double minDensity, double maxDensity, List<Blob> blobs) { filterByCriteria(BlobCriteria.BY_DENSITY, minDensity, maxDensity, blobs); }
        public static void sortByDensity(SortOrder sortOrder, List<Blob> blobs) { sortByCriteria(BlobCriteria.BY_DENSITY, sortOrder, blobs); }
        public static void filterByAspectRatio(double minAspect, double maxAspect, List<Blob> blobs) { filterByCriteria(BlobCriteria.BY_ASPECT_RATIO, minAspect, maxAspect, blobs); }
        public static void sortByAspectRatio(SortOrder sortOrder, List<Blob> blobs) { sortByCriteria(BlobCriteria.BY_ASPECT_RATIO, sortOrder, blobs); }
    }
}
