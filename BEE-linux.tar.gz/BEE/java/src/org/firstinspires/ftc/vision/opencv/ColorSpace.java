package org.firstinspires.ftc.vision.opencv;

/** Ca în SDK-ul FTC: spațiul de culoare al unui ColorRange (canalele ca în OpenCV pe 8 biți). */
public enum ColorSpace { YCrCb, HSV, RGB }
