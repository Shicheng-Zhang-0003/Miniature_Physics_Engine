package org.firstinspires.ftc.vision.opencv;

import org.opencv.core.Scalar;

/** Ca în SDK-ul FTC 11: un interval de culoare (aceleași intervale predefinite, în YCrCb). */
public class ColorRange {
    protected final ColorSpace colorSpace;
    protected final Scalar min;
    protected final Scalar max;

    public static final ColorRange BLUE = new ColorRange(ColorSpace.YCrCb, new Scalar(16, 0, 155), new Scalar(255, 127, 255));
    public static final ColorRange RED = new ColorRange(ColorSpace.YCrCb, new Scalar(32, 176, 0), new Scalar(255, 255, 132));
    public static final ColorRange YELLOW = new ColorRange(ColorSpace.YCrCb, new Scalar(32, 128, 0), new Scalar(255, 170, 120));
    public static final ColorRange GREEN = new ColorRange(ColorSpace.YCrCb, new Scalar(32, 0, 0), new Scalar(255, 120, 133));
    public static final ColorRange ARTIFACT_GREEN = new ColorRange(ColorSpace.YCrCb, new Scalar(32, 50, 118), new Scalar(255, 105, 145));
    public static final ColorRange ARTIFACT_PURPLE = new ColorRange(ColorSpace.YCrCb, new Scalar(32, 135, 135), new Scalar(255, 155, 169));

    public ColorRange(ColorSpace colorSpace, Scalar min, Scalar max) {
        this.colorSpace = colorSpace;
        this.min = min;
        this.max = max;
    }

    /** O culoare RGB (0xRRGGBB) e în interval? */
    boolean contains(int rgb) {
        int[] c = toSpace(rgb, colorSpace);
        for (int i = 0; i < 3; i++) if (c[i] < min.val[i] || c[i] > max.val[i]) return false;
        return true;
    }

    /** O culoare RGB (0xRRGGBB) în spațiul cerut, cu canalele ca OpenCV pe 8 biți (YCrCb: Y, Cr, Cb; HSV: H 0..180). */
    static int[] toSpace(int rgb, ColorSpace space) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        switch (space) {
            case YCrCb: {
                double y = 0.299 * r + 0.587 * g + 0.114 * b;
                return new int[] {clip(y), clip((r - y) * 0.713 + 128), clip((b - y) * 0.564 + 128)};
            }
            case HSV: {
                int v = Math.max(r, Math.max(g, b)), d = v - Math.min(r, Math.min(g, b));
                double h = d == 0 ? 0 : v == r ? 60.0 * (g - b) / d : v == g ? 120 + 60.0 * (b - r) / d : 240 + 60.0 * (r - g) / d;
                return new int[] {clip((h < 0 ? h + 360 : h) / 2), v == 0 ? 0 : clip(255.0 * d / v), v};
            }
            default:
                return new int[] {r, g, b};
        }
    }

    static int clip(double v) { return (int) Math.max(0, Math.min(255, Math.round(v))); }
}
