package org.firstinspires.ftc.vision.apriltag;

import java.util.ArrayList;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.vision.VisionProcessor;

/** Ca în SDK-ul FTC: detectorul de AprilTag-uri (simulat de org.ftcsim.SimAprilTag). */
public abstract class AprilTagProcessor implements VisionProcessor {
    public static final int THREADS_DEFAULT = 3;

    public enum PoseSolver { APRILTAG_BUILTIN, OPENCV_ITERATIVE, OPENCV_SOLVEPNP_EPNP, OPENCV_IPPE, OPENCV_IPPE_SQUARE, OPENCV_SQPNP }

    public enum TagFamily { TAG_36h11, TAG_25h9, TAG_16h5, TAG_standard41h12 }

    public static AprilTagProcessor easyCreateWithDefaults() { return new Builder().build(); }

    public static class Builder {
        private Position cameraPosition = new Position();
        private YawPitchRollAngles cameraOrientation = new YawPitchRollAngles(AngleUnit.DEGREES, 0, 0, 0, 0);
        private TagFamily tagFamily = TagFamily.TAG_36h11;
        private AprilTagLibrary tagLibrary = AprilTagGameDatabase.getCurrentGameTagLibrary();
        private DistanceUnit outputUnitsLength = DistanceUnit.INCH;
        private AngleUnit outputUnitsAngle = AngleUnit.DEGREES;

        /** Unde e camera pe robot (vezi ConceptAprilTagLocalization): de aici vine detection.robotPose. */
        public Builder setCameraPose(Position position, YawPitchRollAngles orientation) {
            cameraPosition = position;
            cameraOrientation = orientation;
            return this;
        }
        // shortcut: webcam-ul simulat e calibrat (pinhole din FOV), deci parametrii lentilei nu schimbă poza;
        // dacă trebuie testate calibrări greșite, folosiți-i la proiecția din SimAprilTag
        public Builder setLensIntrinsics(double fx, double fy, double cx, double cy) { return this; }
        public Builder setSuppressCalibrationWarnings(boolean suppressCalibrationWarnings) { return this; }
        public Builder setTagFamily(TagFamily tagFamily) { this.tagFamily = tagFamily; return this; }
        public Builder setTagLibrary(AprilTagLibrary tagLibrary) { this.tagLibrary = tagLibrary; return this; }
        public Builder setOutputUnits(DistanceUnit distanceUnit, AngleUnit angleUnit) {
            outputUnitsLength = distanceUnit;
            outputUnitsAngle = angleUnit;
            return this;
        }
        public Builder setDrawAxes(boolean drawAxes) { return this; }
        public Builder setDrawCubeProjection(boolean drawCube) { return this; }
        public Builder setDrawTagOutline(boolean drawOutline) { return this; }
        public Builder setDrawTagID(boolean drawTagID) { return this; }
        public Builder setNumThreads(int threads) { return this; }

        public AprilTagProcessor build() {
            if (tagLibrary == null) throw new RuntimeException("Cannot create AprilTagProcessor without setting tag library!");
            if (tagFamily == null) throw new RuntimeException("Cannot create AprilTagProcessor without setting tag family!");
            return new org.ftcsim.SimAprilTag(cameraPosition, cameraOrientation, tagFamily, tagLibrary, outputUnitsLength, outputUnitsAngle);
        }
    }

    public abstract void setDecimation(float decimation);
    public abstract void setPoseSolver(PoseSolver poseSolver);
    public abstract int getPerTagAvgPoseSolveTime();
    public abstract ArrayList<AprilTagDetection> getDetections();
    public abstract ArrayList<AprilTagDetection> getFreshDetections();
}
