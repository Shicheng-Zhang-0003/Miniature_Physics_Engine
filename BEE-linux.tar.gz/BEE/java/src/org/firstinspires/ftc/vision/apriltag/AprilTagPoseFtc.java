package org.firstinspires.ftc.vision.apriltag;

/** Ca în SDK-ul FTC: tag-ul față de cameră. x dreapta, y înainte, z sus; range / bearing / elevation. */
public class AprilTagPoseFtc {
    public final double x, y, z;
    public final double yaw, pitch, roll;
    public final double range, bearing, elevation;

    public AprilTagPoseFtc(double x, double y, double z, double yaw, double pitch, double roll, double range, double bearing, double elevation) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.roll = roll;
        this.range = range;
        this.bearing = bearing;
        this.elevation = elevation;
    }
}
