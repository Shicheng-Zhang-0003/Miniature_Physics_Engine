package org.firstinspires.ftc.vision;

/**
 * Ca în SDK-ul FTC: un procesor adăugat la VisionPortal (AprilTag, ColorBlobLocator, PredominantColor).
 * shortcut: fără init / processFrame / onDrawFrame (imaginea și OpenCV nu există în simulator), deci un procesor
 * scris de echipă nu se compilează aici; dacă apare nevoia, ar trebui o imagine randată în Godot.
 */
public interface VisionProcessor {
}
