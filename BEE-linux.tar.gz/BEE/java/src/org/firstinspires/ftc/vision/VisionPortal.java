package org.firstinspires.ftc.vision;

import android.util.Size;
import java.util.ArrayList;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.controls.CameraControl;

/**
 * Ca în SDK-ul FTC: camera + procesoarele ei. În simulator imaginea nu există: webcam-ul primește de la Godot
 * ce vede (tag-urile și piesele din câmpul vizual) și procesoarele fac din asta detecțiile (org.ftcsim.SimVisionPortal).
 */
public abstract class VisionPortal {
    public static final int DEFAULT_VIEW_CONTAINER_ID = 1;

    public enum CameraState {
        OPENING_CAMERA_DEVICE, CAMERA_DEVICE_READY, STARTING_STREAM, STREAMING, STOPPING_STREAM, CLOSING_CAMERA_DEVICE, CAMERA_DEVICE_CLOSED, ERROR
    }

    public enum MultiPortalLayout { VERTICAL, HORIZONTAL }

    public enum StreamFormat { YUY2, MJPEG }

    /** Pe Driver Station împarte previzualizarea; aici doar id-urile (nu există previzualizare). */
    public static int[] makeMultiPortalView(int numPortals, MultiPortalLayout mpl) {
        int[] ids = new int[numPortals];
        for (int i = 0; i < numPortals; i++) ids[i] = DEFAULT_VIEW_CONTAINER_ID + 1 + i;
        return ids;
    }

    public static VisionPortal easyCreateWithDefaults(BuiltinCameraDirection cameraDirection, VisionProcessor... processors) {
        return new Builder().setCamera(cameraDirection).addProcessors(processors).build();
    }

    public static VisionPortal easyCreateWithDefaults(CameraName cameraName, VisionProcessor... processors) {
        return new Builder().setCamera(cameraName).addProcessors(processors).build();
    }

    public static class Builder {
        private CameraName camera;
        private StreamFormat streamFormat;
        private Size cameraResolution = new Size(640, 480);
        private boolean autoStartStreamOnBuild = true;
        private final List<VisionProcessor> processors = new ArrayList<>();

        public Builder setCamera(CameraName camera) { this.camera = camera; return this; }
        public Builder setCamera(BuiltinCameraDirection cameraDirection) {
            camera = ClassFactory.getInstance().getCameraManager().nameFromCameraDirection(cameraDirection);
            return this;
        }
        public Builder setStreamFormat(StreamFormat streamFormat) { this.streamFormat = streamFormat; return this; }
        public Builder enableLiveView(boolean enableLiveView) { return this; }
        public Builder setAutoStopLiveView(boolean autoPause) { return this; }
        public Builder setLiveViewContainerId(int liveViewContainerId) { return this; }
        public Builder setCameraResolution(Size cameraResolution) { this.cameraResolution = cameraResolution; return this; }
        public Builder addProcessor(VisionProcessor processor) { processors.add(processor); return this; }
        public Builder addProcessors(VisionProcessor... processors) {
            for (VisionProcessor p : processors) addProcessor(p);
            return this;
        }
        public Builder setAutoStartStreamOnBuild(boolean autoStartStreamOnBuild) { this.autoStartStreamOnBuild = autoStartStreamOnBuild; return this; }
        public Builder setShowStatsOverlay(boolean showStatsOverlay) { return this; }

        public VisionPortal build() {
            if (camera == null) throw new RuntimeException("You can't build a vision portal without setting a camera!");
            if (streamFormat != null && !camera.isWebcam() && !camera.isSwitchable()) {
                throw new IllegalStateException("setStreamFormat() may only be used with a webcam");
            }
            VisionPortal portal = new org.ftcsim.SimVisionPortal(camera, cameraResolution, autoStartStreamOnBuild, processors.toArray(new VisionProcessor[0]));
            processors.clear();
            return portal;
        }
    }

    public abstract void setProcessorEnabled(VisionProcessor processor, boolean enabled);
    public abstract boolean getProcessorEnabled(VisionProcessor processor);
    public abstract CameraState getCameraState();
    public abstract void saveNextFrameRaw(String filename);
    public abstract void stopStreaming();
    public abstract void resumeStreaming();
    public abstract void stopLiveView();
    public abstract void resumeLiveView();
    public abstract float getFps();
    public abstract <T extends CameraControl> T getCameraControl(Class<T> controlType);
    public abstract void setActiveCamera(WebcamName webcamName);
    public abstract WebcamName getActiveCamera();
    public abstract void close();
}
