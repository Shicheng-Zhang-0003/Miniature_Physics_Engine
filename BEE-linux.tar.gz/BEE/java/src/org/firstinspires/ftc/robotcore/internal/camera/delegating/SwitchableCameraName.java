package org.firstinspires.ftc.robotcore.internal.camera.delegating;

import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraName;

/** Ca în SDK-ul FTC: mai multe webcam-uri, unul activ (VisionPortal.setActiveCamera). */
public interface SwitchableCameraName extends CameraName {
    CameraName[] getMembers();
    boolean allMembersAreWebcams();
}
