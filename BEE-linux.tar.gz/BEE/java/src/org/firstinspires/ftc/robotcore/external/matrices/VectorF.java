package org.firstinspires.ftc.robotcore.external.matrices;

import java.util.Locale;

/** Ca în SDK-ul FTC (fără operațiile cu matrici): un vector de float-uri, ex. poziția unui tag pe teren. */
public class VectorF {
    protected float[] data;

    public static VectorF length(int length) { return new VectorF(new float[length]); }

    public VectorF(float[] data) { this.data = data; }
    public VectorF(float x) { this(new float[] {x}); }
    public VectorF(float x, float y) { this(new float[] {x, y}); }
    public VectorF(float x, float y, float z) { this(new float[] {x, y, z}); }
    public VectorF(float x, float y, float z, float w) { this(new float[] {x, y, z, w}); }

    public float[] getData() { return data; }
    public int length() { return data.length; }
    public float get(int index) { return data[index]; }
    public void put(int index, float value) { data[index] = value; }

    /** x, y, z împărțite la w (ca în SDK; cu 3 elemente e o copie). */
    public VectorF normalized3D() {
        if (data.length == 3) return new VectorF(data[0], data[1], data[2]);
        if (data.length == 4) return new VectorF(data[0] / data[3], data[1] / data[3], data[2] / data[3]);
        throw new IllegalArgumentException("vector must be of length 3 or 4");
    }
    public float magnitude() { return (float) Math.sqrt(dotProduct(this)); }
    public float dotProduct(VectorF him) {
        if (him.length() != length()) throw new IllegalArgumentException("vectors must be the same length");
        float s = 0;
        for (int i = 0; i < data.length; i++) s += data[i] * him.data[i];
        return s;
    }
    public VectorF added(VectorF him) { VectorF r = new VectorF(data.clone()); r.add(him); return r; }
    public void add(VectorF him) { for (int i = 0; i < data.length; i++) data[i] += him.data[i]; }
    public VectorF subtracted(VectorF him) { VectorF r = new VectorF(data.clone()); r.subtract(him); return r; }
    public void subtract(VectorF him) { for (int i = 0; i < data.length; i++) data[i] -= him.data[i]; }
    public VectorF multiplied(float scale) { VectorF r = new VectorF(data.clone()); r.multiply(scale); return r; }
    public void multiply(float scale) { for (int i = 0; i < data.length; i++) data[i] *= scale; }

    @Override public String toString() {
        StringBuilder s = new StringBuilder("{");
        for (int i = 0; i < data.length; i++) s.append(i > 0 ? " " : "").append(String.format(Locale.ROOT, "%.2f", data[i]));
        return s.append("}").toString();
    }
}
