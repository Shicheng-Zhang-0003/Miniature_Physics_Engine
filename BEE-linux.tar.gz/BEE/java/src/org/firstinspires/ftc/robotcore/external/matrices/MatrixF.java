package org.firstinspires.ftc.robotcore.external.matrices;

import java.util.Locale;

/** Ca în SDK-ul FTC (subset): o matrice de float-uri, ex. rotația R din AprilTagPoseRaw. */
public abstract class MatrixF {
    protected int numRows, numCols;

    public MatrixF(int numRows, int numCols) {
        if (numRows <= 0 || numCols <= 0) throw new IllegalArgumentException("matrix dimensions must be positive");
        this.numRows = numRows;
        this.numCols = numCols;
    }

    public static MatrixF identityMatrix(int dim) {
        MatrixF m = new GeneralMatrixF(dim, dim);
        for (int i = 0; i < dim; i++) m.put(i, i, 1);
        return m;
    }

    public abstract MatrixF emptyMatrix(int numRows, int numCols);
    public abstract float get(int row, int col);
    public abstract void put(int row, int col, float value);

    public int numRows() { return numRows; }
    public int numCols() { return numCols; }

    public VectorF getRow(int row) {
        VectorF v = VectorF.length(numCols);
        for (int c = 0; c < numCols; c++) v.put(c, get(row, c));
        return v;
    }
    public VectorF getColumn(int col) {
        VectorF v = VectorF.length(numRows);
        for (int r = 0; r < numRows; r++) v.put(r, get(r, col));
        return v;
    }
    public MatrixF transposed() {
        MatrixF t = emptyMatrix(numCols, numRows);
        for (int r = 0; r < numRows; r++) for (int c = 0; c < numCols; c++) t.put(c, r, get(r, c));
        return t;
    }
    public MatrixF multiplied(MatrixF him) {
        if (numCols != him.numRows) throw new IllegalArgumentException("matrix dimensions do not match");
        MatrixF m = emptyMatrix(numRows, him.numCols);
        for (int r = 0; r < numRows; r++) for (int c = 0; c < him.numCols; c++) {
            float s = 0;
            for (int k = 0; k < numCols; k++) s += get(r, k) * him.get(k, c);
            m.put(r, c, s);
        }
        return m;
    }
    public VectorF multiplied(VectorF him) {
        if (numCols != him.length()) throw new IllegalArgumentException("matrix and vector dimensions do not match");
        VectorF v = VectorF.length(numRows);
        for (int r = 0; r < numRows; r++) {
            float s = 0;
            for (int k = 0; k < numCols; k++) s += get(r, k) * him.get(k);
            v.put(r, s);
        }
        return v;
    }

    @Override public String toString() {
        StringBuilder s = new StringBuilder("{");
        for (int r = 0; r < numRows; r++) {
            s.append(r > 0 ? ",{" : "{");
            for (int c = 0; c < numCols; c++) s.append(c > 0 ? "," : "").append(String.format(Locale.ROOT, "%.3f", get(r, c)));
            s.append("}");
        }
        return s.append("}").toString();
    }
}
