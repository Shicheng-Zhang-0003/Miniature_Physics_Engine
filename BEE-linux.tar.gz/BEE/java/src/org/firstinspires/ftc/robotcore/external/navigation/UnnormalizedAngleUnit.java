package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK: unghiuri / viteze unghiulare care NU se aduc în [-180, 180). */
public enum UnnormalizedAngleUnit {
    DEGREES, RADIANS;

    public double fromRadians(double radians) { return this == RADIANS ? radians : Math.toDegrees(radians); }
    public double fromDegrees(double degrees) { return this == DEGREES ? degrees : Math.toRadians(degrees); }
    public double toRadians(double angle) { return this == RADIANS ? angle : Math.toRadians(angle); }
    public double toDegrees(double angle) { return this == DEGREES ? angle : Math.toDegrees(angle); }
    public AngleUnit getNormalized() { return this == DEGREES ? AngleUnit.DEGREES : AngleUnit.RADIANS; }
}
