package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC. */
public enum AxesReference { EXTRINSIC, INTRINSIC }
