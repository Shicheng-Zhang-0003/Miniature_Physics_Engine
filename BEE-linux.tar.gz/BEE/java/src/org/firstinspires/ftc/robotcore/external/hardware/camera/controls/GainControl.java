package org.firstinspires.ftc.robotcore.external.hardware.camera.controls;

/** Ca în SDK-ul FTC: amplificarea (gain) webcam-ului. */
public interface GainControl extends CameraControl {
    int getMinGain();
    int getMaxGain();
    int getGain();
    boolean setGain(int gain);
}
