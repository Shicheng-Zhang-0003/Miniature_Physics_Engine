package org.firstinspires.ftc.robotcore.external.hardware.camera;

/** Ca în SDK-ul FTC: camera din spate / din față a telefonului (un Control Hub nu are, deci nici simulatorul). */
public enum BuiltinCameraDirection { BACK, FRONT }
