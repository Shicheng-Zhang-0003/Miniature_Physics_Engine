package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC. Yaw pozitiv = rotire spre stânga (sens trigonometric, privit de sus). */
public class YawPitchRollAngles {
    private final AngleUnit unit;
    private final double yaw, pitch, roll;
    private final long acquisitionTime;

    public YawPitchRollAngles(AngleUnit unit, double yaw, double pitch, double roll, long acquisitionTime) {
        this.unit = unit;
        this.yaw = yaw;
        this.pitch = pitch;
        this.roll = roll;
        this.acquisitionTime = acquisitionTime;
    }

    public double getYaw(AngleUnit u) { return u.fromRadians(unit.toRadians(yaw)); }
    public double getPitch(AngleUnit u) { return u.fromRadians(unit.toRadians(pitch)); }
    public double getRoll(AngleUnit u) { return u.fromRadians(unit.toRadians(roll)); }
    public double getYaw() { return yaw; }
    public double getPitch() { return pitch; }
    public double getRoll() { return roll; }
    public long getAcquisitionTime() { return acquisitionTime; }

    @Override
    public String toString() {
        return String.format(java.util.Locale.ROOT, "{yaw=%.3f, pitch=%.3f, roll=%.3f}", yaw, pitch, roll);
    }
}
