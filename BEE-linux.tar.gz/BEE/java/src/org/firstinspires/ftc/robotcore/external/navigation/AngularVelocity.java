package org.firstinspires.ftc.robotcore.external.navigation;

import java.util.Locale;

/** Ca în SDK-ul FTC: viteza unghiulară pe cele 3 axe (z = yaw). Unitatea e nenormalizată (o viteză poate depăși 180°/s). */
public class AngularVelocity {
    public UnnormalizedAngleUnit angleUnit;
    public float xRotationRate, yRotationRate, zRotationRate;
    public long acquisitionTime;

    public AngularVelocity() { this(UnnormalizedAngleUnit.DEGREES, 0, 0, 0, 0); }

    public AngularVelocity(UnnormalizedAngleUnit unit, float x, float y, float z, long acquisitionTime) {
        this.angleUnit = unit;
        this.xRotationRate = x;
        this.yRotationRate = y;
        this.zRotationRate = z;
        this.acquisitionTime = acquisitionTime;
    }

    public AngularVelocity(AngleUnit unit, float x, float y, float z, long acquisitionTime) {
        this(unit.getUnnormalized(), x, y, z, acquisitionTime);
    }

    public AngularVelocity toAngleUnit(AngleUnit unit) {
        UnnormalizedAngleUnit u = unit.getUnnormalized();
        return new AngularVelocity(u, (float) u.fromRadians(angleUnit.toRadians(xRotationRate)), (float) u.fromRadians(angleUnit.toRadians(yRotationRate)),
                (float) u.fromRadians(angleUnit.toRadians(zRotationRate)), acquisitionTime);
    }

    @Override public String toString() {
        return String.format(Locale.ROOT, "{x=%.3f, y=%.3f, z=%.3f} %s", xRotationRate, yRotationRate, zRotationRate, angleUnit);
    }
}
