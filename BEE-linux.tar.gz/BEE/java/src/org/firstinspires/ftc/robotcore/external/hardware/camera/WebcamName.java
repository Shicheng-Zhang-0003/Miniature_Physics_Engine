package org.firstinspires.ftc.robotcore.external.hardware.camera;

import com.qualcomm.robotcore.hardware.HardwareDevice;

/** Ca în SDK-ul FTC: un webcam din configurație, hardwareMap.get(WebcamName.class, "Webcam 1") (simulat de org.ftcsim.SimWebcam). */
public interface WebcamName extends CameraName, HardwareDevice {
    String getUsbDeviceNameIfAttached();
    boolean isAttached();
}
