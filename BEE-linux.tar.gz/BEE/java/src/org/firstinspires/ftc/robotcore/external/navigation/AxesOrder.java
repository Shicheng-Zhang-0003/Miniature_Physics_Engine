package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC. */
public enum AxesOrder { XZX, XYX, YXY, YZY, ZYZ, ZXZ, XZY, XYZ, YXZ, YZX, ZYX, ZXY }
