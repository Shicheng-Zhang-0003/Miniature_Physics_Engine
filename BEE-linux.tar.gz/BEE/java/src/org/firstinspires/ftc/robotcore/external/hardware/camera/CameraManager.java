package org.firstinspires.ftc.robotcore.external.hardware.camera;

import java.util.List;
import org.firstinspires.ftc.robotcore.internal.camera.delegating.SwitchableCameraName;

/** Ca în SDK-ul FTC (fără deschiderea directă a camerei): ClassFactory.getInstance().getCameraManager(). */
public interface CameraManager {
    List<WebcamName> getAllWebcams();
    CameraName nameFromCameraDirection(BuiltinCameraDirection cameraDirection);
    CameraName nameForUnknownCamera();
    SwitchableCameraName nameForSwitchableCamera(CameraName... cameraNames);
}
