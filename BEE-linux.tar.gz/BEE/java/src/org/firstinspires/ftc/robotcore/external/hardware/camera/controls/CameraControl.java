package org.firstinspires.ftc.robotcore.external.hardware.camera.controls;

/** Ca în SDK-ul FTC: o setare a webcam-ului (VisionPortal.getCameraControl(ExposureControl.class)). */
public interface CameraControl {
}
