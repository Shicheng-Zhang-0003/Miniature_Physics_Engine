package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC: unghiuri normalizate în [-180, 180) grade / [-π, π) radiani. */
public enum AngleUnit {
    DEGREES(0), RADIANS(1);

    public static final float Pif = (float) Math.PI;
    public final byte bVal;

    AngleUnit(int i) { bVal = (byte) i; }

    public double fromRadians(double radians) { return normalize(this == RADIANS ? radians : Math.toDegrees(radians)); }
    public float fromRadians(float radians) { return (float) fromRadians((double) radians); }
    public double fromDegrees(double degrees) { return normalize(this == DEGREES ? degrees : Math.toRadians(degrees)); }
    public float fromDegrees(float degrees) { return (float) fromDegrees((double) degrees); }
    public double fromUnit(AngleUnit them, double theirs) { return them == DEGREES ? fromDegrees(theirs) : fromRadians(theirs); }
    public float fromUnit(AngleUnit them, float theirs) { return (float) fromUnit(them, (double) theirs); }

    public double toRadians(double angle) { return RADIANS.normalize(this == RADIANS ? angle : Math.toRadians(angle)); }
    public float toRadians(float angle) { return (float) toRadians((double) angle); }
    public double toDegrees(double angle) { return DEGREES.normalize(this == DEGREES ? angle : Math.toDegrees(angle)); }
    public float toDegrees(float angle) { return (float) toDegrees((double) angle); }

    /** Ca în SDK: unghiul adus în [-π, π). */
    public static double normalizeRadians(double radians) {
        while (radians >= Math.PI) radians -= 2 * Math.PI;
        while (radians < -Math.PI) radians += 2 * Math.PI;
        return radians;
    }
    public static float normalizeRadians(float radians) { return (float) normalizeRadians((double) radians); }
    /** Ca în SDK: unghiul adus în [-180, 180). */
    public static double normalizeDegrees(double degrees) {
        while (degrees >= 180.0) degrees -= 360.0;
        while (degrees < -180.0) degrees += 360.0;
        return degrees;
    }
    public static float normalizeDegrees(float degrees) { return (float) normalizeDegrees((double) degrees); }

    public double normalize(double angle) { return this == RADIANS ? normalizeRadians(angle) : normalizeDegrees(angle); }
    public float normalize(float angle) { return (float) normalize((double) angle); }

    public UnnormalizedAngleUnit getUnnormalized() { return this == DEGREES ? UnnormalizedAngleUnit.DEGREES : UnnormalizedAngleUnit.RADIANS; }
}
