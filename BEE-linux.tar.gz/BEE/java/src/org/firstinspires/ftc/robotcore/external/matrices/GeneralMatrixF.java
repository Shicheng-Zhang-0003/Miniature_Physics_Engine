package org.firstinspires.ftc.robotcore.external.matrices;

/** Ca în SDK-ul FTC: o matrice cu datele pe rânduri (row-major). */
public class GeneralMatrixF extends MatrixF {
    private final float[] data;

    public GeneralMatrixF(int numRows, int numCols) { this(numRows, numCols, new float[numRows * numCols]); }
    public GeneralMatrixF(int numRows, int numCols, float[] data) {
        super(numRows, numCols);
        if (data.length != numRows * numCols) throw new IllegalArgumentException("data length must be numRows * numCols");
        this.data = data;
    }

    public float[] getData() { return data; }
    @Override public MatrixF emptyMatrix(int numRows, int numCols) { return new GeneralMatrixF(numRows, numCols); }
    @Override public float get(int row, int col) { return data[row * numCols + col]; }
    @Override public void put(int row, int col, float value) { data[row * numCols + col] = value; }
    @Override public GeneralMatrixF transposed() { return (GeneralMatrixF) super.transposed(); }
}
