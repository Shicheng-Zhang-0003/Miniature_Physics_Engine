package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC: trei unghiuri; la ordinea ZYX, firstAngle = heading (yaw). */
public class Orientation {
    public AxesReference axesReference;
    public AxesOrder axesOrder;
    public AngleUnit angleUnit;
    public float firstAngle, secondAngle, thirdAngle;
    public long acquisitionTime;

    public Orientation() { this(AxesReference.EXTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES, 0, 0, 0, 0); }
    public Orientation(AxesReference r, AxesOrder o, AngleUnit u, float a, float b, float c, long t) {
        axesReference = r; axesOrder = o; angleUnit = u; firstAngle = a; secondAngle = b; thirdAngle = c; acquisitionTime = t;
    }
    public Orientation toAngleUnit(AngleUnit unit) {
        if (unit == angleUnit) return this;
        return new Orientation(axesReference, axesOrder, unit, (float) unit.fromUnit(angleUnit, firstAngle),
                (float) unit.fromUnit(angleUnit, secondAngle), (float) unit.fromUnit(angleUnit, thirdAngle), acquisitionTime);
    }

    /** Pe terenul plat: doar unghiul în jurul lui Z, mutat pe poziția lui Z din ordinea nouă. */
    public Orientation toAxesOrder(AxesOrder order) {
        float[] a = {firstAngle, secondAngle, thirdAngle};
        float yaw = a[axesOrder.name().indexOf('Z')];
        float[] b = new float[3];
        b[order.name().indexOf('Z')] = yaw;
        return new Orientation(axesReference, order, angleUnit, b[0], b[1], b[2], acquisitionTime);
    }

    public Orientation toAxesReference(AxesReference reference) {
        return new Orientation(reference, axesOrder, angleUnit, firstAngle, secondAngle, thirdAngle, acquisitionTime);
    }

    @Override public String toString() {
        return String.format(java.util.Locale.ROOT, "{%s %s %.1f %.1f %.1f}", axesReference, axesOrder, firstAngle, secondAngle, thirdAngle);
    }
}
