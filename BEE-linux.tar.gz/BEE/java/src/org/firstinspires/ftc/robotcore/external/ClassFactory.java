package org.firstinspires.ftc.robotcore.external;

import com.qualcomm.robotcore.hardware.HardwareMap;
import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraManager;
import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;

/** Ca în SDK-ul FTC (doar camerele): ClassFactory.getInstance().getCameraManager().nameForSwitchableCamera(webcam1, webcam2). */
public abstract class ClassFactory {
    private static final ClassFactory INSTANCE = new ClassFactory() {
        @Override public CameraManager getCameraManager() { return org.ftcsim.SimWebcam.MANAGER; }
    };

    public static ClassFactory getInstance() { return INSTANCE; }

    public abstract CameraManager getCameraManager();

    /** Toate webcam-urile din configurație, ca o singură cameră comutabilă. */
    public static CameraName createSwitchableCameraNameForAllWebcams(HardwareMap hardwareMap) {
        return getInstance().getCameraManager().nameForSwitchableCamera(hardwareMap.getAll(WebcamName.class).toArray(new CameraName[0]));
    }
}
