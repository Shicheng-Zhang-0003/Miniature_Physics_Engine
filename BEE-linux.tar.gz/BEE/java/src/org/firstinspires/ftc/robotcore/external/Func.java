package org.firstinspires.ftc.robotcore.external;

/** Ca în SDK-ul FTC: o valoare calculată abia când e nevoie de ea (ex. telemetria, la trimitere). */
public interface Func<T> {
    T value();
}
