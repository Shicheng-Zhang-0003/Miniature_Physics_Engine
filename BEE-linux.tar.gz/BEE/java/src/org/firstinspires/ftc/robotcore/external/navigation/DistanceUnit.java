package org.firstinspires.ftc.robotcore.external.navigation;

import java.util.Locale;

/** Ca în SDK-ul FTC. */
public enum DistanceUnit {
    METER(0, 1.0), CM(1, 0.01), MM(2, 0.001), INCH(3, 0.0254);

    public static final double infinity = Double.MAX_VALUE;
    public static final double mmPerInch = 25.4;
    public static final double mPerInch = mmPerInch * 0.001;
    public final byte bVal;
    private final double meters;

    DistanceUnit(int b, double meters) { bVal = (byte) b; this.meters = meters; }

    public double fromMeters(double m) { return m == infinity ? infinity : m / meters; }
    public double fromInches(double inches) { return inches == infinity ? infinity : inches * mPerInch / meters; }
    public double fromCm(double cm) { return cm == infinity ? infinity : cm * 0.01 / meters; }
    public double fromMm(double mm) { return mm == infinity ? infinity : mm * 0.001 / meters; }
    public double fromUnit(DistanceUnit him, double his) { return his == infinity ? infinity : fromMeters(him.toMeters(his)); }
    public double toMeters(double v) { return v == infinity ? infinity : v * meters; }
    public double toInches(double v) { return v == infinity ? infinity : v * meters / mPerInch; }
    public double toCm(double v) { return v == infinity ? infinity : v * meters / 0.01; }
    public double toMm(double v) { return v == infinity ? infinity : v * meters / 0.001; }

    public String toString(double inOurUnits) {
        switch (this) {
            case METER: return String.format(Locale.getDefault(), "%.3fm", inOurUnits);
            case CM: return String.format(Locale.getDefault(), "%.1fcm", inOurUnits);
            case MM: return String.format(Locale.getDefault(), "%.0fmm", inOurUnits);
            default: return String.format(Locale.getDefault(), "%.2fin", inOurUnits);
        }
    }

    @Override public String toString() {
        switch (this) {
            case METER: return "m";
            case CM: return "cm";
            case MM: return "mm";
            default: return "in";
        }
    }
}
