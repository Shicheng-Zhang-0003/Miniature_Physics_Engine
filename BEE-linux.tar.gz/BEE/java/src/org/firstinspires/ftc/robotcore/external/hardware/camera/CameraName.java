package org.firstinspires.ftc.robotcore.external.hardware.camera;

/** Ca în SDK-ul FTC (fără permisiunile Android): numele unei camere, un webcam, camera telefonului sau una comutabilă. */
public interface CameraName {
    boolean isWebcam();
    boolean isCameraDirection();
    boolean isSwitchable();
    boolean isUnknown();
}
