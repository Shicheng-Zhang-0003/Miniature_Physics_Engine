package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC. */
public enum CurrentUnit {
    AMPS, MILLIAMPS;

    public double toAmps(double current) { return this == AMPS ? current : current / 1000.0; }
    public double toMilliAmps(double current) { return this == MILLIAMPS ? current : current * 1000.0; }
    public double convert(double current, CurrentUnit from) { return this == AMPS ? from.toAmps(current) : from.toMilliAmps(current); }
}
