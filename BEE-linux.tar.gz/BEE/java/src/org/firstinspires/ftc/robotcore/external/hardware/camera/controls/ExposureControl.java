package org.firstinspires.ftc.robotcore.external.hardware.camera.controls;

import java.util.concurrent.TimeUnit;

/** Ca în SDK-ul FTC (fără getCachedExposure): timpul de expunere al webcam-ului. */
public interface ExposureControl extends CameraControl {
    long unknownExposure = 0;

    enum Mode {
        Unknown, Auto, ContinuousAuto, Manual, ShutterPriority, AperturePriority;

        public static Mode fromId(int id) { return id >= 0 && id < values().length ? values()[id] : Unknown; }
    }

    Mode getMode();
    boolean setMode(Mode mode);
    boolean isModeSupported(Mode mode);
    long getMinExposure(TimeUnit resultUnit);
    long getMaxExposure(TimeUnit resultUnit);
    long getExposure(TimeUnit resultUnit);
    boolean setExposure(long duration, TimeUnit durationUnit);
    boolean isExposureSupported();
    boolean getAePriority();
    boolean setAePriority(boolean priority);
}
