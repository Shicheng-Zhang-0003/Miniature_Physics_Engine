package org.firstinspires.ftc.robotcore.external.navigation;

/** Ca în SDK-ul FTC. */
public enum VoltageUnit {
    VOLTS, MILLIVOLTS;

    public double toVolts(double voltage) { return this == VOLTS ? voltage : voltage / 1000.0; }
    public double toMilliVolts(double voltage) { return this == MILLIVOLTS ? voltage : voltage * 1000.0; }
    public double convert(double voltage, VoltageUnit from) { return this == VOLTS ? from.toVolts(voltage) : from.toMilliVolts(voltage); }
}
