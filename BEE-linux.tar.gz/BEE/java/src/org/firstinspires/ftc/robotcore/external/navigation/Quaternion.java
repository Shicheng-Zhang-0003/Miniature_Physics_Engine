package org.firstinspires.ftc.robotcore.external.navigation;

import java.util.Locale;

/** Ca în SDK-ul FTC (fără partea de matrici): o rotație 3D. Pe terenul plat al simulatorului doar yaw-ul e nenul. */
public class Quaternion {
    public float w, x, y, z;
    public long acquisitionTime;

    public static Quaternion identityQuaternion() { return new Quaternion(1, 0, 0, 0, 0); }

    public Quaternion() { this(0, 0, 0, 0, 0); }
    public Quaternion(float w, float x, float y, float z, long acquisitionTime) {
        this.w = w; this.x = x; this.y = y; this.z = z; this.acquisitionTime = acquisitionTime;
    }

    public float magnitude() { return (float) Math.sqrt(w * w + x * x + y * y + z * z); }
    public Quaternion normalized() {
        float m = magnitude();
        return new Quaternion(w / m, x / m, y / m, z / m, acquisitionTime);
    }
    public Quaternion conjugate() { return new Quaternion(w, -x, -y, -z, acquisitionTime); }
    /** @deprecated ca în SDK (numele vechi, scris greșit) */
    @Deprecated public Quaternion congugate() { return conjugate(); }
    public Quaternion inverse() { return normalized().conjugate(); }
    public Quaternion multiply(Quaternion q, long mostRecentAcquisitionTime) {
        return new Quaternion(
                w * q.w - x * q.x - y * q.y - z * q.z,
                w * q.x + x * q.w + y * q.z - z * q.y,
                w * q.y - x * q.z + y * q.w + z * q.x,
                w * q.z + x * q.y - y * q.x + z * q.w,
                mostRecentAcquisitionTime);
    }

    /** Doar unghiul în jurul lui Z (yaw), pus pe poziția axei Z din ordinea cerută. */
    public Orientation toOrientation(AxesReference reference, AxesOrder order, AngleUnit unit) {
        Quaternion q = normalized();
        double yaw = Math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z));
        float[] a = new float[3];
        a[order.name().indexOf('Z')] = (float) unit.fromRadians(yaw);
        return new Orientation(reference, order, unit, a[0], a[1], a[2], acquisitionTime);
    }

    @Override public String toString() { return String.format(Locale.ROOT, "{w=%.3f, x=%.3f, y=%.3f, z=%.3f}", w, x, y, z); }
}
