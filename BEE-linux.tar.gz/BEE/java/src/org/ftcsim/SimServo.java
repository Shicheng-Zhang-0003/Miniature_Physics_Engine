package org.ftcsim;

import com.qualcomm.robotcore.hardware.ServoController;
import com.qualcomm.robotcore.hardware.ServoImplEx;
import java.util.Locale;

/**
 * Un servo din simulator: trimite poziția (0..1) la sim. Ca ServoImpl din SDK: poziția se taie la [0, 1],
 * se inversează (REVERSE) și abia apoi se mapează în intervalul din scaleRange().
 */
public class SimServo extends ServoImplEx {
    private final SimClient sim;
    private final String name;
    private Direction direction = Direction.FORWARD;
    private double position = 0;
    private double min = 0, max = 1;
    private boolean pwm = true;

    public SimServo(SimClient sim, String name) {
        this.sim = sim;
        this.name = name;
    }

    @Override public void setDirection(Direction d) { direction = d; }
    @Override public Direction getDirection() { return direction; }

    @Override
    public void setPosition(double p) {
        position = Math.max(MIN_POSITION, Math.min(MAX_POSITION, p));
        double out = direction == Direction.REVERSE ? MAX_POSITION - position : position;
        double scaled = min + out * (max - min);
        pwm = true;  // ca pe hub: o poziție nouă pornește din nou semnalul
        sim.send(String.format(Locale.ROOT, "SERVO %s %.4f", SimClient.esc(name), scaled));
    }

    @Override public double getPosition() { return position; }

    @Override
    public void scaleRange(double min, double max) {
        // ca în SDK: capetele trebuie să fie în [0, 1] și min < max
        if (min < MIN_POSITION || min > MAX_POSITION || max < MIN_POSITION || max > MAX_POSITION || min >= max) {
            throw new IllegalArgumentException(String.format(Locale.ROOT, "scaleRange(%f, %f): min and max must be in [0, 1] and min < max", min, max));
        }
        this.min = min;
        this.max = max;
    }

    @Override public int getPortNumber() { return 0; }
    // PwmControl: fără semnal servo-ul nu mai ține poziția (ca pe hub); o poziție nouă îl pornește din nou
    @Override public void setPwmEnable() { pwm = true; }
    @Override public void setPwmDisable() { pwm = false; }
    @Override public boolean isPwmEnabled() { return pwm; }

    @Override public ServoController getController() {
        final SimServo s = this;
        return new ServoController() {
            @Override public void pwmEnable() { pwm = true; }
            @Override public void pwmDisable() { pwm = false; }
            @Override public PwmStatus getPwmStatus() { return pwm ? PwmStatus.ENABLED : PwmStatus.DISABLED; }
            @Override public void setServoPosition(int servo, double position) {
                pwm = true;
                sim.send(String.format(Locale.ROOT, "SERVO %s %.4f", SimClient.esc(name), Math.max(0, Math.min(1, position))));
            }
            @Override public double getServoPosition(int servo) { return s.min + (s.direction == Direction.REVERSE ? 1 - s.position : s.position) * (s.max - s.min); }
            @Override public String getDeviceName() { return "Control Hub (simulated)"; }
        };
    }

    @Override public String getDeviceName() { return "Servo (" + name + ")"; }
}
