package org.ftcsim;

import com.qualcomm.robotcore.hardware.CRServoImplEx;
import com.qualcomm.robotcore.hardware.ServoController;
import java.util.Locale;

/** Un servo cu rotație continuă: puterea merge la sim (ex. un intake cu CRServo). */
public class SimCRServo extends CRServoImplEx {
    private final SimClient sim;
    private final String name;
    private Direction direction = Direction.FORWARD;
    private double power = 0;

    public SimCRServo(SimClient sim, String name) { this.sim = sim; this.name = name; }

    @Override public void setDirection(Direction d) { direction = d; setPower(power); }
    @Override public Direction getDirection() { return direction; }
    @Override public void setPower(double p) {
        power = Math.max(-1, Math.min(1, p));
        pwm = true;
        sim.send(String.format(Locale.ROOT, "POWER %s %.4f", SimClient.esc(name), power * (direction == Direction.REVERSE ? -1 : 1)));
    }
    @Override public double getPower() { return power; }
    @Override public int getPortNumber() { return 0; }
    // PwmControl: fără semnal servo-ul continuu se oprește (ca pe hub); o putere nouă îl pornește din nou
    private boolean pwm = true;
    @Override public void setPwmEnable() { pwm = true; }
    @Override public void setPwmDisable() { pwm = false; sim.send(String.format(Locale.ROOT, "POWER %s %.4f", SimClient.esc(name), 0.0)); }
    @Override public boolean isPwmEnabled() { return pwm; }
    @Override public ServoController getController() {
        return new ServoController() {
            @Override public void pwmEnable() {}
            @Override public void pwmDisable() { setPower(0); }
            @Override public PwmStatus getPwmStatus() { return PwmStatus.ENABLED; }
            @Override public void setServoPosition(int servo, double position) { setPower(position * 2 - 1); }
            @Override public double getServoPosition(int servo) { return (power + 1) / 2; }
            @Override public String getDeviceName() { return "Control Hub (simulated)"; }
        };
    }
}
