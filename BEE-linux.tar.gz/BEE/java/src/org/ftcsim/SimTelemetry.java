package org.ftcsim;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.firstinspires.ftc.robotcore.external.Func;
import org.firstinspires.ftc.robotcore.external.Telemetry;

/**
 * Telemetria: apare în joc (panoul Driver Station) și în terminal. Ca în SDK: update() trimite ce s-a adăugat,
 * apoi (autoClear) șterge tot în afară de itemii „retained”; un item cu Func se calculează la trimitere și e
 * retained implicit; Line.addData pune mai mulți itemi pe aceeași linie.
 */
public class SimTelemetry implements Telemetry {
    private final List<SimLine> lines = new ArrayList<>();
    private final Map<Object, Runnable> actions = new LinkedHashMap<>();
    private final SimClient sim;
    private boolean autoClear = true;
    private int intervalMs = 250;
    private long lastSent = 0;
    private String sep = " : ", itemSep = " | ";
    private DisplayFormat format = DisplayFormat.CLASSIC;
    private String pending = null;  // ultima telemetrie netrimisă (din cauza intervalului)

    public SimTelemetry(SimClient sim) { this.sim = sim; }

    private class SimItem implements Item {
        final SimLine line;
        String caption;
        Object value = "";
        String valueFormat;  // pentru Func cu format
        Boolean retained;
        SimItem(SimLine line, String caption) { this.line = line; this.caption = caption; }

        String render() {
            Object v = value;
            if (v instanceof Func) {
                try {
                    Object r = ((Func<?>) v).value();
                    v = valueFormat != null ? String.format(Locale.ROOT, valueFormat, r) : String.valueOf(r);
                } catch (RuntimeException e) {
                    v = e.toString();
                }
            }
            return caption == null || caption.isEmpty() ? String.valueOf(v) : caption + sep + v;
        }
        boolean producer() { return value instanceof Func; }

        @Override public String getCaption() { return caption; }
        @Override public Item setCaption(String c) { caption = c; return this; }
        @Override public Item setValue(String f, Object... a) { value = String.format(Locale.ROOT, f, a); valueFormat = null; return this; }
        @Override public Item setValue(Object v) { value = String.valueOf(v); valueFormat = null; return this; }
        @Override public <T> Item setValue(Func<T> p) { value = p; valueFormat = null; return this; }
        @Override public <T> Item setValue(String f, Func<T> p) { value = p; valueFormat = f; return this; }
        @Override public Item setRetained(Boolean r) { retained = r; return this; }
        @Override public boolean isRetained() { return retained != null ? retained : producer(); }
        // ca în SDK: datele adăugate dintr-un item merg pe aceeași linie
        @Override public Item addData(String c, String f, Object... a) { return line.addData(c, f, a); }
        @Override public Item addData(String c, Object v) { return line.addData(c, v); }
        @Override public <T> Item addData(String c, Func<T> p) { return line.addData(c, p); }
        @Override public <T> Item addData(String c, String f, Func<T> p) { return line.addData(c, f, p); }
    }

    private class SimLine implements Line {
        final String caption;
        final List<SimItem> items = new ArrayList<>();
        SimLine(String caption) { this.caption = caption; }
        private SimItem add(String c) { SimItem i = new SimItem(this, c); items.add(i); return i; }
        @Override public Item addData(String c, String f, Object... a) { return add(c).setValue(f, a); }
        @Override public Item addData(String c, Object v) { return add(c).setValue(v); }
        @Override public <T> Item addData(String c, Func<T> p) { return add(c).setValue(p); }
        @Override public <T> Item addData(String c, String f, Func<T> p) { return add(c).setValue(f, p); }
        String render() {
            StringBuilder sb = new StringBuilder(caption == null ? "" : caption);
            for (int i = 0; i < items.size(); i++) {
                if (i > 0) sb.append(itemSep);
                sb.append(items.get(i).render());
            }
            return sb.toString();
        }
    }

    private SimLine newLine(String caption) { SimLine l = new SimLine(caption); lines.add(l); return l; }

    /** telemetry.log(): fiecare linie pleacă imediat spre simulator (TLOG), fără interval. */
    private final Log log = new Log() {
        int capacity = 9;
        DisplayOrder order = DisplayOrder.OLDEST_FIRST;
        @Override public int getCapacity() { return capacity; }
        @Override public void setCapacity(int c) { capacity = c; }
        @Override public DisplayOrder getDisplayOrder() { return order; }
        @Override public void setDisplayOrder(DisplayOrder o) { order = o; }
        @Override public void add(String entry) {
            sim.send("TLOG " + String.valueOf(entry).replace("\n", " "));
            System.out.println(String.format(Locale.ROOT, "[log t=%.2fs] %s", sim.simTime, entry));
        }
        @Override public void add(String f, Object... a) { add(String.format(Locale.ROOT, f, a)); }
        @Override public void clear() { sim.send("TLOG_CLEAR"); }
    };

    @Override public Log log() { return log; }
    @Override public Item addData(String caption, String format, Object... args) { return newLine(null).addData(caption, format, args); }
    @Override public Item addData(String caption, Object value) { return newLine(null).addData(caption, value); }
    @Override public <T> Item addData(String caption, Func<T> p) { return newLine(null).addData(caption, p); }
    @Override public <T> Item addData(String caption, String format, Func<T> p) { return newLine(null).addData(caption, format, p); }
    @Override public Line addLine() { return newLine(""); }
    @Override public Line addLine(String lineCaption) { return newLine(lineCaption); }

    @Override public boolean removeItem(Item item) {
        for (Iterator<SimLine> it = lines.iterator(); it.hasNext(); ) {
            SimLine l = it.next();
            if (l.items.remove(item)) {
                if (l.items.isEmpty() && (l.caption == null || l.caption.isEmpty())) it.remove();
                return true;
            }
        }
        return false;
    }
    @Override public boolean removeLine(Line line) { return lines.remove(line); }

    /** Ca în SDK: șterge tot ce nu e retained. */
    @Override public void clear() {
        for (Iterator<SimLine> it = lines.iterator(); it.hasNext(); ) {
            SimLine l = it.next();
            l.items.removeIf(i -> !i.isRetained());
            if (l.items.isEmpty()) it.remove();
        }
    }
    @Override public void clearAll() { lines.clear(); actions.clear(); }

    @Override public Object addAction(Runnable action) { Object token = new Object(); actions.put(token, action); return token; }
    @Override public boolean removeAction(Object token) { return actions.remove(token) != null; }
    @Override public void setAutoClear(boolean a) { autoClear = a; }
    @Override public boolean isAutoClear() { return autoClear; }
    @Override public void setMsTransmissionInterval(int ms) { intervalMs = ms; }
    @Override public int getMsTransmissionInterval() { return intervalMs; }
    @Override public void speak(String text) {}
    @Override public void speak(String text, String languageCode, String countryCode) {}
    @Override public String getCaptionValueSeparator() { return sep; }
    @Override public void setCaptionValueSeparator(String s) { sep = s; }
    @Override public String getItemSeparator() { return itemSep; }
    @Override public void setItemSeparator(String s) { itemSep = s; }
    @Override public void setDisplayFormat(DisplayFormat f) { format = f; }

    private String plain(String s) {
        if (format != DisplayFormat.HTML) return s;
        // panoul din joc arată text simplu: <br> devine linie nouă, restul etichetelor dispare
        return s.replaceAll("(?i)<br\\s*/?>", "\n").replaceAll("<[^>]*>", "")
                .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
    }

    @Override
    public boolean update() {
        for (Runnable r : new ArrayList<>(actions.values())) r.run();
        StringBuilder sb = new StringBuilder();
        for (SimLine l : lines) sb.append(plain(l.render()).replace("\r", "").replace("\n", "\\n")).append("\\n");
        pending = sb.toString();
        long now = System.currentTimeMillis();
        if (now - lastSent >= intervalMs) {
            lastSent = now;
            flush();
        }
        if (autoClear) clear();
        return true;
    }

    /** Trimite ultima telemetrie (apelat și la final, ca să nu se piardă ultimul mesaj). */
    public void flush() {
        if (pending == null) return;
        sim.send("TELEM " + pending);
        System.out.print(String.format(Locale.ROOT, "--- telemetry  t=%.2fs ---%n%s", sim.simTime, pending.replace("\\n", System.lineSeparator())));
        pending = null;
    }
}
