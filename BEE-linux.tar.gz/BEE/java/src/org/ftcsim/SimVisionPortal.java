package org.ftcsim;

import android.util.Size;
import com.qualcomm.robotcore.util.RobotLog;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.controls.CameraControl;
import org.firstinspires.ftc.vision.VisionPortal;
import org.firstinspires.ftc.vision.VisionProcessor;

/**
 * VisionPortal-ul simulat: starea camerei (ca VisionPortalImpl din SDK 11, cu aceleași excepții), rezoluția și
 * procesoarele. Procesoarele își iau cadrele de aici, când codul le cere rezultatul (nu există fir de procesare).
 */
public class SimVisionPortal extends VisionPortal {
    /** Un procesor simulat: află de portal când e adăugat la el. */
    public interface Processor {
        void attach(SimVisionPortal portal);
    }

    private static final long OPEN_MS = 700;  // un webcam real pornește în ~0.5-1 s: până atunci OPENING_CAMERA_DEVICE
    private static final long SWITCH_MS = 100;

    private final CameraName camera;
    private final List<SimWebcam> members;
    private volatile SimWebcam active;
    private final int width, height;
    private final Map<VisionProcessor, Boolean> processors = new LinkedHashMap<>();
    private CameraState state;
    private CameraState next;  // starea în care ajunge la nextAt (pornirea / oprirea camerei durează puțin)
    private long nextAt;

    public SimVisionPortal(CameraName camera, Size resolution, boolean autoStart, VisionProcessor[] list) {
        this.camera = camera;
        width = resolution.getWidth();
        height = resolution.getHeight();
        members = SimWebcam.membersOf(camera);
        active = members.isEmpty() ? null : members.get(0);
        for (VisionProcessor p : list) {
            processors.put(p, true);
            if (p instanceof Processor) ((Processor) p).attach(this);
        }
        if (active == null) {
            // ca pe un Control Hub: nu are cameră de telefon, deci camera nu se deschide
            state = CameraState.ERROR;
            RobotLog.ee("VisionPortal", "Unable to open camera %s: the simulated robot only has webcams (hardwareMap.get(WebcamName.class, ...))", camera);
        } else {
            go(CameraState.OPENING_CAMERA_DEVICE, autoStart ? CameraState.STREAMING : CameraState.CAMERA_DEVICE_READY, OPEN_MS);
        }
    }

    private synchronized void go(CameraState now, CameraState then, long ms) {
        state = now;
        next = then;
        nextAt = SimClock.millis() + ms;
    }

    public int width() { return width; }
    public int height() { return height; }

    /** Ultimul cadru al webcam-ului activ pentru procesorul p, sau null (camera nu transmite, procesorul e oprit, încă nu e niciun cadru). */
    public synchronized SimClient.WebcamFrame frameFor(VisionProcessor p) {
        if (getCameraState() != CameraState.STREAMING || !Boolean.TRUE.equals(processors.get(p))) return null;
        SimWebcam w = active;
        return w == null ? null : w.frame();
    }

    @Override public synchronized CameraState getCameraState() {
        if (next != null && SimClock.millis() >= nextAt) {
            state = next;
            next = null;
        }
        return state;
    }

    @Override public synchronized void setProcessorEnabled(VisionProcessor processor, boolean enabled) {
        if (!processors.containsKey(processor)) throw new IllegalArgumentException("Processor not attached to this helper!");
        processors.put(processor, enabled);
    }

    @Override public synchronized boolean getProcessorEnabled(VisionProcessor processor) {
        if (!processors.containsKey(processor)) throw new IllegalArgumentException("Processor not attached to this helper!");
        return processors.get(processor);
    }

    @Override public void saveNextFrameRaw(String filename) {
        RobotLog.ww("VisionPortal", "saveNextFrameRaw(%s): the simulated webcam has no image to save", filename);
    }

    @Override public synchronized void stopStreaming() {
        CameraState s = getCameraState();
        if (s == CameraState.STREAMING || s == CameraState.STARTING_STREAM) {
            go(CameraState.STOPPING_STREAM, CameraState.CAMERA_DEVICE_READY, SWITCH_MS);
        } else if (s != CameraState.STOPPING_STREAM && s != CameraState.CAMERA_DEVICE_READY && s != CameraState.CLOSING_CAMERA_DEVICE) {
            throw new RuntimeException(String.format("Illegal CameraState %s when calling stopStreaming()", s));
        }
    }

    @Override public synchronized void resumeStreaming() {
        CameraState s = getCameraState();
        if (s == CameraState.CAMERA_DEVICE_READY || s == CameraState.STOPPING_STREAM) {
            go(CameraState.STARTING_STREAM, CameraState.STREAMING, SWITCH_MS);
        } else if (s != CameraState.STREAMING && s != CameraState.STARTING_STREAM) {
            throw new RuntimeException(String.format("Illegal CameraState %s when calling resumeStreaming()", s));
        }
    }

    @Override public void stopLiveView() {}
    @Override public void resumeLiveView() {}
    @Override public float getFps() { return getCameraState() == CameraState.STREAMING ? 30f : 0f; }

    @Override public <T extends CameraControl> T getCameraControl(Class<T> controlType) {
        if (getCameraState() != CameraState.STREAMING) throw new IllegalStateException("You cannot use camera controls until the camera is streaming");
        SimWebcam w = active;
        if (w == null) throw new UnsupportedOperationException("Getting controls is only supported for webcams");
        return controlType.isInstance(w.controls) ? controlType.cast(w.controls) : null;
    }

    @Override public void setActiveCamera(WebcamName webcamName) {
        if (!camera.isSwitchable()) throw new UnsupportedOperationException("setActiveCamera is only supported for switchable webcams");
        if (!(webcamName instanceof SimWebcam) || !members.contains(webcamName)) {
            throw new IllegalArgumentException("Camera " + webcamName + " is not a member of the switchable camera");
        }
        active = (SimWebcam) webcamName;
    }

    @Override public WebcamName getActiveCamera() {
        if (!camera.isSwitchable()) throw new UnsupportedOperationException("getActiveCamera is only supported for switchable webcams");
        return active;
    }

    @Override public synchronized void close() {
        if (getCameraState() != CameraState.CAMERA_DEVICE_CLOSED) go(CameraState.CLOSING_CAMERA_DEVICE, CameraState.CAMERA_DEVICE_CLOSED, SWITCH_MS);
    }
}
