package org.ftcsim;

import com.qualcomm.robotcore.hardware.Gamepad;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.vision.apriltag.AprilTagLibrary;

/** Conexiunea cu simulatorul Godot (socket local, câte un mesaj text pe linie). */
public class SimClient {
    /** Un cadru al camerei: botpose (inch, grade) și tag-urile văzute. */
    public static class VisionFrame {
        public boolean valid;
        public double[] botpose = new double[3];
        public List<double[]> tags = new ArrayList<>();  // id, tx, ty, ta, x, y, z (inch, față de cameră)
        public long timeMs = System.currentTimeMillis();
    }

    private final Socket socket;
    private final BufferedReader in;
    private final Writer out;
    private final Map<String, double[]> values = new ConcurrentHashMap<>();  // nume -> valori din STATE
    private final Map<String, VisionFrame> vision = new ConcurrentHashMap<>();
    /** Obiectele (piesele de joc) văzute de cameră: clasă, tx, ty, ta, distanță (inch). */
    public static class Detection {
        public String cls; public double tx, ty, ta, dist;
    }
    private final Map<String, List<Detection>> detections = new ConcurrentHashMap<>();
    /** O piesă văzută de un webcam: centrul (inch, față de cameră: x dreapta, y înainte, z sus), raza, culoarea (RGB). */
    public static class Piece {
        public String cls; public double x, y, z, r; public int rgb;
    }
    /** Un cadru al unui webcam: FOV-ul orizontal și ce e în fața lui, cu geometria reală. */
    public static class WebcamFrame {
        public double hfov;
        public final List<double[]> tags = new ArrayList<>();  // id, x, y, z (ca la Piece), qw, qx, qy, qz (cadrul tag-ului AprilTag în cadrul OpenCV)
        public final List<Piece> pieces = new ArrayList<>();
        public final long nanos = System.nanoTime();
    }
    private final Map<String, WebcamFrame> webcams = new ConcurrentHashMap<>();
    final Map<String, String> config = new LinkedHashMap<>();
    private final CountDownLatch configured = new CountDownLatch(1);
    private final CountDownLatch firstState = new CountDownLatch(1);  // senzorii au valori (ca pe robot, de la INIT)
    private final List<Runnable> stateListeners = new CopyOnWriteArrayList<>();
    private volatile boolean connected = true;
    volatile double simTime = 0;
    private volatile long stateNanos = 0;  // când a venit ultimul STATE (ceasul simulării: se oprește la pauză)
    final Gamepad gamepad1 = new Gamepad();
    final Gamepad gamepad2 = new Gamepad();

    public SimClient(String host, int port) throws IOException {
        socket = new Socket(host, port);
        socket.setTcpNoDelay(true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        out = new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8);
        Thread reader = new Thread(this::readLoop, "sim-reader");
        reader.setDaemon(true);
        reader.start();
    }

    public void hello(String opModeName) throws InterruptedException {
        send("HELLO " + opModeName);
        configured.await();
        // altfel un Pinpoint făcut înainte de primul STATE și-ar lua originea din zero (poziția absolută pe teren)
        firstState.await(2, java.util.concurrent.TimeUnit.SECONDS);
    }

    public void onState(Runnable r) { stateListeners.add(r); }

    private void readLoop() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                String[] t = line.trim().split(" ");
                try {
                switch (t[0]) {
                    case "STATE":
                        simTime = Double.parseDouble(t[1]);
                        stateNanos = SimClock.nanoTime();
                        for (int i = 2; i < t.length; i++) {
                            String[] p = t[i].split(":");
                            double[] v = new double[p.length - 1];
                            for (int k = 1; k < p.length; k++) v[k - 1] = Double.parseDouble(p[k]);
                            values.put(unesc(p[0]), v);
                        }
                        firstState.countDown();
                        for (Runnable r : stateListeners) r.run();
                        break;
                    case "VISION": {
                        VisionFrame f = new VisionFrame();
                        f.valid = t[2].equals("1");
                        String[] bp = t[3].split(":");
                        for (int k = 0; k < 3; k++) f.botpose[k] = Double.parseDouble(bp[k]);
                        for (int i = 4; i < t.length; i++) {
                            String[] p = t[i].split(":");
                            double[] tag = new double[p.length];
                            for (int k = 0; k < p.length; k++) tag[k] = Double.parseDouble(p[k]);
                            f.tags.add(tag);
                        }
                        vision.put(unesc(t[1]), f);
                        break;
                    }
                    case "DETECT": {
                        List<Detection> list = new ArrayList<>();
                        for (int i = 2; i < t.length; i++) {
                            String[] p = t[i].split(":");
                            Detection d = new Detection();
                            d.cls = p[0];
                            d.tx = Double.parseDouble(p[1]);
                            d.ty = Double.parseDouble(p[2]);
                            d.ta = Double.parseDouble(p[3]);
                            d.dist = Double.parseDouble(p[4]);
                            list.add(d);
                        }
                        detections.put(unesc(t[1]), list);
                        break;
                    }
                    case "WEBCAM": {
                        WebcamFrame f = new WebcamFrame();
                        f.hfov = Double.parseDouble(t[2]);
                        for (int i = 3; i < t.length; i++) {
                            String[] p = t[i].split(":");
                            if (p[0].equals("T")) {
                                double[] tag = new double[8];
                                for (int k = 0; k < 8; k++) tag[k] = Double.parseDouble(p[k + 1]);
                                f.tags.add(tag);
                            } else if (p[0].equals("P")) {
                                Piece pc = new Piece();
                                pc.cls = p[1];
                                pc.x = Double.parseDouble(p[2]);
                                pc.y = Double.parseDouble(p[3]);
                                pc.z = Double.parseDouble(p[4]);
                                pc.r = Double.parseDouble(p[5]);
                                pc.rgb = Integer.parseInt(p[6], 16);
                                f.pieces.add(pc);
                            }
                        }
                        webcams.put(unesc(t[1]), f);
                        break;
                    }
                    case "TAGS": {
                        // tag-urile terenului (id:nume:mărime:x:y:z:qw:qx:qy:qz, inch, teren FTC): biblioteca jocului curent
                        AprilTagLibrary.Builder b = new AprilTagLibrary.Builder().setAllowOverwrite(true);
                        for (int i = 1; i < t.length; i++) {
                            String[] p = t[i].split(":");
                            float[] v = new float[7];
                            for (int k = 0; k < 7; k++) v[k] = Float.parseFloat(p[k + 3]);
                            b.addTag(Integer.parseInt(p[0]), unesc(p[1]), Double.parseDouble(p[2]), new VectorF(v[0], v[1], v[2]),
                                    DistanceUnit.INCH, new Quaternion(v[3], v[4], v[5], v[6], 0));
                        }
                        SimAprilTag.setFieldTags(b.build());
                        break;
                    }
                    case "GAMEPAD": {
                        float[] axes = new float[6];
                        for (int k = 0; k < 6; k++) axes[k] = Float.parseFloat(t[2 + k]);
                        (t[1].equals("2") ? gamepad2 : gamepad1).setFromSim(axes, Integer.parseInt(t[8]));
                        break;
                    }
                    case "START": SimSignals.start(); break;
                    case "STOP": SimSignals.stop(); break;
                    case "PAUSE": SimClock.setPaused(t.length > 1 && t[1].equals("1")); break;
                    case "CONFIG":
                        for (int i = 1; i < t.length; i++) {
                            String[] p = t[i].split("=", 2);
                            if (p.length == 2) config.put(unesc(p[0]), p[1]);  // un token stricat nu oprește conexiunea
                        }
                        configured.countDown();
                        break;
                    default:
                }
                } catch (RuntimeException bad) {
                    // un mesaj stricat nu oprește conexiunea (altfel hello() ar aștepta CONFIG la nesfârșit)
                    System.err.println("ignored a bad message from the simulator: " + line + " (" + bad + ")");
                }
            }
        } catch (IOException ignored) {
        }
        connected = false;
        configured.countDown();
        firstState.countDown();
        SimSignals.stop();
    }

    public boolean isConnected() { return connected; }

    /** Numele din configurația FTC pot avea spații („left front”): în mesaje, %, spațiu, = și : sunt scrise ca la URL-uri. */
    public static String esc(String n) {
        return n.replace("%", "%25").replace(" ", "%20").replace("=", "%3D").replace(":", "%3A").replace("\t", "%09");
    }

    public static String unesc(String n) {
        return n.replace("%09", "\t").replace("%3A", ":").replace("%3D", "=").replace("%20", " ").replace("%25", "%");
    }

    public double[] value(String name) {
        return values.getOrDefault(name, new double[] {0, 0, 0, 0, 0, 0});
    }

    /**
     * Secunde de la ultimul STATE (cel mult 2 cadre). Simulatorul trimite encoderele de ~60 de ori pe secundă, dar
     * bucla OpMode-ului merge mult mai repede: un encoder real se schimbă continuu, deci între două cadre îl
     * estimăm din viteză (altfel localizarea vede „0, 0, 0, salt” și viteza ei calculată are vârfuri).
     */
    public double sinceState() {
        if (stateNanos == 0) return 0;
        return Math.max(0, Math.min(1.0 / 30.0, (SimClock.nanoTime() - stateNanos) / 1e9));
    }

    /** Compatibil cu codul vechi: {ticks, ticks/s}. */
    public double[] encoder(String name) { return value(name); }

    public VisionFrame vision(String name) { return vision.get(name); }

    public List<Detection> detections(String name) { return detections.getOrDefault(name, new ArrayList<Detection>()); }

    public WebcamFrame webcam(String name) { return webcams.get(name); }

    public synchronized void send(String line) {
        if (!connected) return;
        try {
            out.write(line + "\n");
            out.flush();
        } catch (IOException e) {
            connected = false;
        }
    }

    public void close() {
        send("BYE");
        try {
            socket.close();
        } catch (IOException ignored) {
        }
    }
}
