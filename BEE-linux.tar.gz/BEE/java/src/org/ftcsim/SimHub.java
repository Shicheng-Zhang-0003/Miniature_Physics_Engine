package org.ftcsim;

import com.qualcomm.hardware.lynx.LynxModule.BulkCachingMode;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.LockSupport;

/**
 * Cât durează o citire pe Control Hub. Pe hub-ul real fiecare citire de encoder e o comandă (~1.2 ms), iar cu
 * bulk caching o singură citire „bulk” (~2 ms) aduce tot. De aceea o buclă fără sleep nu rulează la 10 kHz:
 * pe robot ajunge la câteva sute de Hz. Aici, la fel (odometria cu encodere vede pași de câțiva ticks, nu 0 / 1).
 *   OFF: fiecare citire costă o comandă. AUTO: a doua citire a aceluiași dispozitiv cere un bulk nou.
 *   MANUAL: după clearBulkCache(), prima citire face bulk-ul.
 */
public final class SimHub {
    static final long READ_NS = 1_200_000, BULK_NS = 2_000_000;
    private static BulkCachingMode mode = BulkCachingMode.OFF;
    private static final Set<Object> cached = new HashSet<>();
    private static boolean manualValid = false;

    private SimHub() {}

    public static synchronized void setMode(BulkCachingMode m) {
        mode = m;
        cached.clear();
        manualValid = false;
    }

    public static synchronized void clearCache() {
        cached.clear();
        manualValid = false;
    }

    /** O citire din codul echipei (getCurrentPosition, getVelocity...): așteaptă cât ar dura pe hub. */
    public static synchronized void read(Object device) {
        switch (mode) {
            case OFF:
                LockSupport.parkNanos(READ_NS);
                break;
            case AUTO:
                if (cached.isEmpty() || cached.contains(device)) {
                    cached.clear();
                    LockSupport.parkNanos(BULK_NS);
                }
                cached.add(device);
                break;
            case MANUAL:
                if (!manualValid) {
                    manualValid = true;
                    LockSupport.parkNanos(BULK_NS);
                }
                break;
        }
    }
}
