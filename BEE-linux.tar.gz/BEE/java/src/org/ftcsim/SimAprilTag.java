package org.ftcsim;

import java.util.ArrayList;
import org.firstinspires.ftc.robotcore.external.matrices.GeneralMatrixF;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagLibrary;
import org.firstinspires.ftc.vision.apriltag.AprilTagMetadata;
import org.firstinspires.ftc.vision.apriltag.AprilTagPoseFtc;
import org.firstinspires.ftc.vision.apriltag.AprilTagPoseRaw;
import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;
import org.opencv.core.Point;

/**
 * Detectorul AprilTag simulat. Pentru fiecare webcam, Godot trimite tag-urile din câmpul vizual cu poza lor reală față
 * de cameră (linia WEBCAM). De aici e ca în SDK 11 (AprilTagProcessorImpl): proiecția în pixeli la rezoluția aleasă,
 * pragul de mărime (depinde de decimation), ftcPose / rawPose calculate cu mărimea din bibliotecă și robotPose din
 * poziția tag-ului pe teren și poza camerei pe robot (setCameraPose).
 */
public class SimAprilTag extends AprilTagProcessor implements SimVisionPortal.Processor {
    private static volatile AprilTagLibrary field = new AprilTagLibrary.Builder().build();

    /** Tag-urile terenului simulat, cu mărimea și poziția lor reale (linia TAGS de la conectare). */
    public static AprilTagLibrary fieldTagLibrary() { return field; }

    static void setFieldTags(AprilTagLibrary library) { field = library; }

    private final double[][] robotInCamera;
    private final TagFamily family;
    private final AprilTagLibrary library;
    private final DistanceUnit unitLength;
    private final AngleUnit unitAngle;
    private volatile float decimation = 3;  // ca în SDK
    private SimVisionPortal portal;
    private SimClient.WebcamFrame last;
    private ArrayList<AprilTagDetection> detections = new ArrayList<>();
    private ArrayList<AprilTagDetection> fresh;

    public SimAprilTag(Position cameraPosition, YawPitchRollAngles cameraOrientation, TagFamily family, AprilTagLibrary library,
                       DistanceUnit unitLength, AngleUnit unitAngle) {
        Position p = cameraPosition.toUnit(DistanceUnit.INCH);
        // ca în SDK: yaw / pitch / roll sunt rotații intrinseci Z-X-Z; toate zero = camera privește în sus
        double[][] r = mul(mul(rotZ(cameraOrientation.getYaw(AngleUnit.RADIANS)), rotX(cameraOrientation.getPitch(AngleUnit.RADIANS))),
                rotZ(cameraOrientation.getRoll(AngleUnit.RADIANS)));
        robotInCamera = invert(pose(p.x, p.y, p.z, r));
        this.family = family;
        this.library = library;
        this.unitLength = unitLength;
        this.unitAngle = unitAngle;
    }

    @Override public void attach(SimVisionPortal p) { portal = p; }
    @Override public void setDecimation(float decimation) { this.decimation = decimation; }
    @Override public void setPoseSolver(PoseSolver poseSolver) {}
    @Override public int getPerTagAvgPoseSolveTime() { return 0; }

    @Override public synchronized ArrayList<AprilTagDetection> getDetections() {
        update();
        return detections;
    }

    @Override public synchronized ArrayList<AprilTagDetection> getFreshDetections() {
        update();
        ArrayList<AprilTagDetection> r = fresh;
        fresh = null;
        return r;
    }

    private void update() {
        SimClient.WebcamFrame f = portal == null ? null : portal.frameFor(this);
        // ca pe Control Hub: cu decimation 1 detectorul face ~10 cadre/s, cu 2 ~22, cu 3 ~30 (comentariile exemplelor SDK)
        double fps = decimation < 1.5f ? 10 : decimation < 2.5f ? 22 : 30;
        if (f == null || f == last || (last != null && f.nanos - last.nanos < 1e9 / fps)) return;
        last = f;
        detections = detect(f);
        fresh = detections;
    }

    private ArrayList<AprilTagDetection> detect(SimClient.WebcamFrame f) {
        ArrayList<AprilTagDetection> out = new ArrayList<>();
        if (family != TagFamily.TAG_36h11) return out;  // tag-urile FTC, și cele din simulator, sunt 36h11
        int w = portal.width(), h = portal.height();
        double fx = w / 2.0 / Math.tan(Math.toRadians(f.hfov) / 2);
        // latura tag-ului trebuie să aibă ~8 px în imaginea micșorată (decimation): pentru un tag de 2 in la 640x480
        // dă distanțele din comentariile exemplelor SDK (decimation 1 / 2 / 3: 10 / 6 / 4 picioare)
        double minPx = Math.max(10, 8 * decimation);
        for (double[] t : f.tags) {
            int id = (int) t[0];
            AprilTagMetadata real = field.lookupTag(id);
            if (real == null) continue;
            double size = DistanceUnit.INCH.fromUnit(real.distanceUnit, real.tagsize);
            double[] p = {t[1], -t[3], t[2]};  // cadrul OpenCV al camerei: x dreapta, y jos, z înainte
            double[][] r = quat(t[4], t[5], t[6], t[7]);
            // colțurile, ca în SDK: (-s/2, s/2), (s/2, s/2), (s/2, -s/2), (-s/2, -s/2) în cadrul tag-ului (x dreapta, y jos)
            Point[] corners = new Point[4];
            boolean inImage = true;
            for (int i = 0; i < 4; i++) {
                double cx = (i == 0 || i == 3 ? -0.5 : 0.5) * size, cy = (i < 2 ? 0.5 : -0.5) * size;
                double x = p[0] + r[0][0] * cx + r[0][1] * cy, y = p[1] + r[1][0] * cx + r[1][1] * cy, z = p[2] + r[2][0] * cx + r[2][1] * cy;
                corners[i] = new Point(w / 2.0 + fx * x / z, h / 2.0 + fx * y / z);
                inImage &= z > 0 && corners[i].x >= 0 && corners[i].x < w && corners[i].y >= 0 && corners[i].y < h;
            }
            double minEdge = Double.MAX_VALUE;
            for (int i = 0; i < 4; i++) {
                minEdge = Math.min(minEdge, Math.hypot(corners[i].x - corners[(i + 1) % 4].x, corners[i].y - corners[(i + 1) % 4].y));
            }
            if (!inImage || minEdge < minPx) continue;
            Point center = new Point(w / 2.0 + fx * p[0] / p[2], h / 2.0 + fx * p[1] / p[2]);
            AprilTagMetadata md = library.lookupTag(id);
            AprilTagPoseRaw raw = null;
            AprilTagPoseFtc ftc = null;
            Pose3D robot = null;
            if (md != null) {
                // ca în SDK: distanța vine din mărimea din bibliotecă (o mărime greșită o scalează)
                double k = DistanceUnit.INCH.fromUnit(md.distanceUnit, md.tagsize) / size;
                double x = unitLength.fromInches(p[0] * k), y = unitLength.fromInches(p[1] * k), z = unitLength.fromInches(p[2] * k);
                raw = new AprilTagPoseRaw(x, y, z, new GeneralMatrixF(3, 3, floats(r)));
                double[] yxz = yxz(r);
                ftc = new AprilTagPoseFtc(x, z, -y, -angle(yxz[0]), angle(yxz[1]), angle(yxz[2]), Math.hypot(x, z),
                        angle(Math.atan2(-x, z)), angle(Math.atan2(-y, z)));
                robot = robotPose(p[0] * k, p[1] * k, p[2] * k, r, md, f.nanos);
            }
            out.add(new AprilTagDetection(id, 0, 50f, center, corners, md, ftc, raw, robot, f.nanos));  // 50: un tag clar
        }
        return out;
    }

    // ca în SDK: robot = (tag pe teren) · (tag față de cameră)^-1 · (robot față de cameră); poziția din bibliotecă e luată în inch
    private Pose3D robotPose(double x, double y, double z, double[][] r, AprilTagMetadata md, long nanos) {
        Quaternion q = md.fieldOrientation;
        double[][] tag = pose(md.fieldPosition.get(0), md.fieldPosition.get(1), md.fieldPosition.get(2), quat(q.w, q.x, q.y, q.z));
        double[][] m = mul(mul(tag, invert(pose(x, y, z, r))), robotInCamera);
        double[] zxy = zxy(m);
        return new Pose3D(new Position(DistanceUnit.INCH, m[0][3], m[1][3], m[2][3], nanos).toUnit(unitLength),
                new YawPitchRollAngles(unitAngle, angle(zxy[0]), angle(zxy[1]), angle(zxy[2]), nanos));
    }

    private double angle(double rad) { return unitAngle.fromRadians(rad); }

    // ---------- matrici de rotație / transformări rigide (4x4), ca Orientation / OpenGLMatrix din SDK ----------

    /** Ca Quaternion.toMatrix() din SDK (fără normalizare). */
    static double[][] quat(double w, double x, double y, double z) {
        return new double[][] {
            {1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)},
            {2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)},
            {2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)}};
    }

    static double[][] rotX(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new double[][] {{1, 0, 0}, {0, c, -s}, {0, s, c}};
    }

    static double[][] rotZ(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new double[][] {{c, -s, 0}, {s, c, 0}, {0, 0, 1}};
    }

    static double[][] pose(double x, double y, double z, double[][] r) {
        return new double[][] {{r[0][0], r[0][1], r[0][2], x}, {r[1][0], r[1][1], r[1][2], y}, {r[2][0], r[2][1], r[2][2], z}, {0, 0, 0, 1}};
    }

    static double[][] mul(double[][] a, double[][] b) {
        int n = a.length;
        double[][] m = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) for (int k = 0; k < n; k++) m[i][j] += a[i][k] * b[k][j];
        return m;
    }

    /** Inversa unei transformări rigide: rotația transpusă, translația -R^T t. */
    static double[][] invert(double[][] m) {
        double[][] r = new double[3][3];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r[i][j] = m[j][i];
        double[] t = new double[3];
        for (int i = 0; i < 3; i++) t[i] = -(r[i][0] * m[0][3] + r[i][1] * m[1][3] + r[i][2] * m[2][3]);
        return pose(t[0], t[1], t[2], r);
    }

    /** Unghiurile intrinseci Y-X-Z (R = Ry · Rx · Rz), ca Orientation.getOrientation(R, INTRINSIC, YXZ, ...). */
    static double[] yxz(double[][] r) {
        return smaller(Math.atan2(r[0][2], r[2][2]), Math.asin(Math.max(-1, Math.min(1, -r[1][2]))), Math.atan2(r[1][0], r[1][1]));
    }

    /** Unghiurile intrinseci Z-X-Y (R = Rz · Rx · Ry): yaw, pitch, roll ale robotului. */
    static double[] zxy(double[][] r) {
        return smaller(Math.atan2(-r[0][1], r[1][1]), Math.asin(Math.max(-1, Math.min(1, r[2][1]))), Math.atan2(-r[2][0], r[2][2]));
    }

    /** Ca în SDK: aceeași rotație are două seturi de unghiuri; îl alege pe cel cu unghiurile mai mici. */
    private static double[] smaller(double a, double b, double c) {
        double[] other = {wrap(a + Math.PI), wrap(Math.PI - b), wrap(c + Math.PI)};
        return a * a + b * b + c * c <= other[0] * other[0] + other[1] * other[1] + other[2] * other[2] ? new double[] {a, b, c} : other;
    }

    private static double wrap(double rad) { return Math.atan2(Math.sin(rad), Math.cos(rad)); }

    private static float[] floats(double[][] r) {
        float[] f = new float[9];
        for (int i = 0; i < 9; i++) f[i] = (float) r[i / 3][i % 3];
        return f;
    }
}
