package org.ftcsim;

/**
 * Ceasul OpMode-ului: ca System.nanoTime(), dar stă pe loc cât timp simulatorul e pe PAUZĂ (Esc).
 * Așa cronometrele (ElapsedTime, getRuntime, cele 30 s de AUTO) nu merg mai departe cât jocul e înghețat.
 */
public final class SimClock {
    private static boolean paused = false;
    private static long pausedAt = 0;
    private static long offset = 0;

    private SimClock() {}

    public static synchronized long nanoTime() {
        return (paused ? pausedAt : System.nanoTime()) - offset;
    }

    public static long millis() {
        return nanoTime() / 1_000_000L;
    }

    public static synchronized boolean isPaused() {
        return paused;
    }

    static synchronized void setPaused(boolean p) {
        long now = System.nanoTime();
        if (p && !paused) {
            paused = true;
            pausedAt = now;
        } else if (!p && paused) {
            paused = false;
            offset += now - pausedAt;
        }
    }

    /** sleep(ms) pe ceasul simulării: pe pauză, așteaptă până se reia jocul. */
    public static void sleep(long ms) throws InterruptedException {
        long end = nanoTime() + ms * 1_000_000L;
        long left;
        while ((left = end - nanoTime()) > 0) {
            Thread.sleep(Math.max(1L, Math.min(left / 1_000_000L, 5L)));
        }
    }
}
