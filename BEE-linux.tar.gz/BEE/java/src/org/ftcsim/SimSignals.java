package org.ftcsim;

import java.util.concurrent.CountDownLatch;

/** START și STOP venite de la simulator (ca butoanele de pe Driver Station). */
public final class SimSignals {
    private static final CountDownLatch start = new CountDownLatch(1);
    private static volatile boolean stop = false;
    private static volatile boolean started = false;

    private SimSignals() {}

    static void start() {
        started = true;
        start.countDown();
    }

    static void stop() {
        stop = true;
        start.countDown();
    }

    public static boolean isStopped() { return stop; }
    public static boolean isStarted() { return started; }

    public static void awaitStart() {
        try {
            start.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
