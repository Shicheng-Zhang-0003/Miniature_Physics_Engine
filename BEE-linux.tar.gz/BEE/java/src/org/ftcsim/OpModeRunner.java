package org.ftcsim;

import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;
import java.io.File;
import java.util.Map;

/**
 * Control Hub-ul simulat: pornește un OpMode al echipei conectat la simulator.
 *   java -Dftcsim.build=<clase> org.ftcsim.OpModeRunner NumeOpMode [port]
 * Merge cu LinearOpMode (runOpMode) și cu OpMode iterativ (init / init_loop / start / loop / stop).
 */
public class OpModeRunner {
    /** Caută clasa după numele simplu (ex. "MyAuto") în toate pachetele compilate. */
    static String resolve(String name) {
        if (name.contains(".")) return name;
        String build = System.getProperty("ftcsim.build", "build");
        String found = find(new File(build), new File(build), name + ".class");
        return found != null ? found : "org.firstinspires.ftc.teamcode." + name;
    }

    private static String find(File root, File dir, String fileName) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (f.isDirectory()) {
                String r = find(root, f, fileName);
                if (r != null) return r;
            } else if (f.getName().equals(fileName)) {
                String rel = root.toURI().relativize(f.toURI()).getPath();
                return rel.substring(0, rel.length() - 6).replace('/', '.');
            }
        }
        return null;
    }

    static HardwareMap buildHardwareMap(SimClient sim) {
        HardwareMap hw = new HardwareMap();
        for (Map.Entry<String, String> e : sim.config.entrySet()) {
            String n = e.getKey();
            switch (e.getValue()) {
                case "fl": case "fr": case "bl": case "br": case "intake": case "launcher":
                    hw.put(n, new SimMotor(sim, n, false)); break;
                case "motor": hw.put(n, new SimMotor(sim, n, true)); break;  // braț, glisieră: simulat local
                case "intake_servo": case "crservo": hw.put(n, new SimCRServo(sim, n)); break;
                case "servo": hw.put(n, new SimServo(sim, n)); break;
                case "imu": hw.put(n, new SimImu(sim, n)); break;
                case "odo": hw.put(n, new SimMotor(sim, n, false)); break;  // roată de odometrie (doar encoder)
                case "pinpoint": hw.put(n, new com.qualcomm.hardware.gobilda.GoBildaPinpointDriver(() -> sim.value(n))); break;
                case "distance": hw.put(n, new SimSensors.Distance(sim, n)); break;
                case "color": hw.put(n, new SimSensors.Color(sim, n)); break;
                case "touch": hw.put(n, new SimSensors.Touch(sim, n)); break;
                case "limelight3a": hw.put(n, new SimLimelight(sim, n)); break;
                case "webcam": hw.put(n, new SimWebcam(sim, n)); break;
                case "voltage": {
                    // ca pe robot: senzorul de tensiune al hub-ului are numele hub-ului („Control Hub”)
                    hw.put("Control Hub", new LynxModule(() -> sim.value("voltage")[0]));
                    hw.put("Control Hub", new SimSensors.Voltage(sim));
                    break;
                }
                default: System.err.println("Rol necunoscut pentru " + n + ": " + e.getValue());
            }
        }
        return hw;
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Folosire: OpModeRunner <NumeOpMode> [port]");
            System.exit(1);
        }
        String className = resolve(args[0]);
        int port = args.length > 1 ? Integer.parseInt(args[1]) : 7777;

        OpMode opMode = (OpMode) Class.forName(className).getDeclaredConstructor().newInstance();
        SimClient sim;
        try {
            sim = new SimClient("127.0.0.1", port);
        } catch (java.io.IOException e) {
            System.err.println("Nu ma pot conecta la simulator pe portul " + port + ". Ai pornit jocul in Godot?");
            System.exit(2);
            return;
        }
        sim.hello(opMode.getClass().getSimpleName());

        opMode.hardwareMap = buildHardwareMap(sim);
        opMode.telemetry = new SimTelemetry(sim);
        opMode.gamepad1 = sim.gamepad1;
        opMode.gamepad2 = sim.gamepad2;

        // dacă simulatorul se închide, OpMode-ul se oprește (ca la STOP pe Driver Station)
        Thread watcher = new Thread(() -> {
            while (sim.isConnected()) {
                try { Thread.sleep(50); } catch (InterruptedException e) { return; }
            }
            opMode.requestOpModeStop();
        });
        watcher.setDaemon(true);
        watcher.start();

        System.out.println("OpMode " + className + " pornit. Hardware: " + sim.config.keySet());
        try {
            if (opMode instanceof LinearOpMode) {
                ((LinearOpMode) opMode).runOpMode();
            } else {
                runIterative(opMode);
            }
        } catch (OpMode.ForceStopException stopNow) {
            System.out.println("terminateOpModeNow()");  // oprire cerută de cod, nu o eroare
        } catch (Throwable t) {
            // ca pe Driver Station: excepția apare în telemetrie
            sim.send("TELEM ERROR: " + t.toString().replace("\n", " "));
            t.printStackTrace();
        } finally {
            ((SimTelemetry) opMode.telemetry).flush();
            for (Map.Entry<String, String> e : sim.config.entrySet()) {
                String role = e.getValue();
                if (role.equals("fl") || role.equals("fr") || role.equals("bl") || role.equals("br")
                        || role.equals("intake") || role.equals("launcher") || role.equals("intake_servo")) {
                    sim.send("POWER " + SimClient.esc(e.getKey()) + " 0");
                }
            }
            sim.close();
            System.out.println("OpMode terminat.");
        }
    }

    /** OpMode iterativ: init, init_loop până la START, start, loop până la STOP, stop. */
    static void runIterative(OpMode op) throws InterruptedException {
        op.init();
        op.telemetry.update();
        while (!SimSignals.isStarted() && !SimSignals.isStopped()) {
            op.init_loop();
            op.telemetry.update();
            Thread.sleep(20);
        }
        if (SimSignals.isStopped()) return;
        op.start();  // ca în SDK: getRuntime() numără de la INIT, nu de la START
        // ca LinearOpMode: o autonomie se oprește singură după 30 s
        long deadline = op.getClass().isAnnotationPresent(com.qualcomm.robotcore.eventloop.opmode.Autonomous.class)
                ? SimClock.millis() + 30_000 : Long.MAX_VALUE;
        while (!SimSignals.isStopped() && sim_ok(op) && SimClock.millis() <= deadline) {
            op.time = op.getRuntime();
            if (SimClock.isPaused()) {  // jocul e pe pauză: loop() nu rulează
                Thread.sleep(10);
                continue;
            }
            op.loop();
            op.telemetry.update();
            Thread.sleep(10);
        }
        op.stop();
    }

    private static boolean sim_ok(OpMode op) {
        try {
            java.lang.reflect.Field f = OpMode.class.getDeclaredField("stopRequested");
            f.setAccessible(true);
            return !f.getBoolean(op);
        } catch (Exception e) {
            return true;
        }
    }
}
