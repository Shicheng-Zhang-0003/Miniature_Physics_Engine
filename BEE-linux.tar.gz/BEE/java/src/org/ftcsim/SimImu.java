package org.ftcsim;

import com.qualcomm.robotcore.hardware.IMU;
import org.firstinspires.ftc.robotcore.external.navigation.*;

/** IMU-ul din simulator: yaw-ul vine din rotația robotului în Godot (fără zgomot sau drift). */
public class SimImu implements IMU {
    private final SimClient sim;
    private final String name;
    private double yawOffset = 0;
    private boolean initialized = false;

    public SimImu(SimClient sim, String name) {
        this.sim = sim;
        this.name = name;
    }

    @Override public boolean initialize(Parameters parameters) { initialized = true; return true; }
    @Override public void resetYaw() { yawOffset = sim.value(name)[0]; }

    private double yawRad() {
        return AngleUnit.RADIANS.normalize(sim.value(name)[0] - yawOffset);
    }

    @Override
    public YawPitchRollAngles getRobotYawPitchRollAngles() {
        if (!initialized) System.err.println("ATENTIE: imu.initialize(...) nu a fost apelat");
        return new YawPitchRollAngles(AngleUnit.DEGREES, Math.toDegrees(yawRad()), 0, 0, System.nanoTime());
    }

    @Override
    public AngularVelocity getRobotAngularVelocity(AngleUnit unit) {
        float z = (float) unit.getUnnormalized().fromRadians(sim.value(name)[1]);  // o viteză nu se normalizează
        return new AngularVelocity(unit, 0f, 0f, z, System.nanoTime());
    }

    @Override
    public Orientation getRobotOrientation(AxesReference reference, AxesOrder order, AngleUnit unit) {
        float yaw = (float) unit.fromRadians(yawRad());
        // pe teren plat doar yaw-ul e nenul; îl punem pe axa Z din ordinea cerută
        String o = order.name();
        float[] a = new float[3];
        a[o.indexOf('Z')] = yaw;
        return new Orientation(reference, order, unit, a[0], a[1], a[2], System.nanoTime());
    }

    @Override
    public Quaternion getRobotOrientationAsQuaternion() {
        double yaw = yawRad();
        return new Quaternion((float) Math.cos(yaw / 2), 0f, 0f, (float) Math.sin(yaw / 2), System.nanoTime());
    }

    @Override public String getDeviceName() { return "BHI260AP IMU"; }
}
