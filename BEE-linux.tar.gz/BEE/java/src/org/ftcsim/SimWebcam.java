package org.ftcsim;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraManager;
import org.firstinspires.ftc.robotcore.external.hardware.camera.CameraName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.hardware.camera.controls.ExposureControl;
import org.firstinspires.ftc.robotcore.external.hardware.camera.controls.GainControl;
import org.firstinspires.ftc.robotcore.internal.camera.delegating.SwitchableCameraName;

/**
 * Webcam-ul simulat (rolul "webcam" din configurație). Simulatorul îi trimite la fiecare pas ce vede (linia WEBCAM):
 * tag-urile și piesele din câmpul vizual, cu poza lor față de cameră. Imaginea propriu-zisă nu există.
 */
public class SimWebcam implements WebcamName {
    static final List<SimWebcam> ALL = new CopyOnWriteArrayList<>();

    private final SimClient sim;
    private final String name;
    final Controls controls = new Controls();

    public SimWebcam(SimClient sim, String name) {
        this.sim = sim;
        this.name = name;
        ALL.add(this);
    }

    /** Ultimul cadru (null până la primul). */
    SimClient.WebcamFrame frame() { return sim.webcam(name); }

    @Override public boolean isWebcam() { return true; }
    @Override public boolean isCameraDirection() { return false; }
    @Override public boolean isSwitchable() { return false; }
    @Override public boolean isUnknown() { return false; }
    @Override public String getUsbDeviceNameIfAttached() { return "/dev/bus/usb/001/00" + (ALL.indexOf(this) + 2); }
    @Override public boolean isAttached() { return true; }
    @Override public String getDeviceName() { return "Webcam"; }
    @Override public String getConnectionInfo() { return "USB (simulated) " + name; }
    @Override public String toString() { return "Webcam(" + name + ")"; }

    /** Webcam-urile unei camere: el însuși, membrii uneia comutabile, nimic pentru camera telefonului. */
    static List<SimWebcam> membersOf(CameraName camera) {
        List<SimWebcam> out = new ArrayList<>();
        if (camera instanceof SimWebcam) out.add((SimWebcam) camera);
        if (camera.isSwitchable() && camera instanceof SwitchableCameraName) {
            for (CameraName c : ((SwitchableCameraName) camera).getMembers()) if (c instanceof SimWebcam) out.add((SimWebcam) c);
        }
        return out;
    }

    /** Ca un webcam UVC (Logitech C920): expunere manuală 1..204 ms, gain 0..255; aici doar se țin minte. */
    static class Controls implements ExposureControl, GainControl {
        private Mode mode = Mode.AperturePriority;
        private long exposureUs = 33_000;
        private int gain = 0;

        @Override public synchronized Mode getMode() { return mode; }
        @Override public synchronized boolean setMode(Mode m) {
            if (!isModeSupported(m)) return false;
            mode = m;
            return true;
        }
        @Override public boolean isModeSupported(Mode m) { return m == Mode.Manual || m == Mode.AperturePriority; }
        @Override public long getMinExposure(TimeUnit unit) { return unit.convert(1_000, TimeUnit.MICROSECONDS); }
        @Override public long getMaxExposure(TimeUnit unit) { return unit.convert(204_000, TimeUnit.MICROSECONDS); }
        @Override public synchronized long getExposure(TimeUnit unit) { return unit.convert(exposureUs, TimeUnit.MICROSECONDS); }
        @Override public synchronized boolean setExposure(long duration, TimeUnit unit) {
            long us = TimeUnit.MICROSECONDS.convert(duration, unit);
            if (us < 1_000 || us > 204_000) return false;
            exposureUs = us;
            return true;
        }
        @Override public boolean isExposureSupported() { return true; }
        @Override public boolean getAePriority() { return false; }
        @Override public boolean setAePriority(boolean priority) { return false; }
        @Override public int getMinGain() { return 0; }
        @Override public int getMaxGain() { return 255; }
        @Override public synchronized int getGain() { return gain; }
        @Override public synchronized boolean setGain(int g) {
            if (g < 0 || g > 255) return false;
            gain = g;
            return true;
        }
    }

    /** O cameră care nu e un webcam (a telefonului, necunoscută) sau una comutabilă. */
    private static class Name implements SwitchableCameraName {
        private final String text;
        private final boolean direction;
        private final CameraName[] members;

        Name(String text, boolean direction, CameraName[] members) {
            this.text = text;
            this.direction = direction;
            this.members = members;
        }
        @Override public boolean isWebcam() { return false; }
        @Override public boolean isCameraDirection() { return direction; }
        @Override public boolean isSwitchable() { return members != null; }
        @Override public boolean isUnknown() { return !direction && members == null; }
        @Override public CameraName[] getMembers() { return members == null ? new CameraName[0] : members.clone(); }
        @Override public boolean allMembersAreWebcams() {
            for (CameraName c : getMembers()) if (!c.isWebcam()) return false;
            return true;
        }
        @Override public String toString() { return text; }
    }

    public static final CameraManager MANAGER = new CameraManager() {
        @Override public List<WebcamName> getAllWebcams() { return new ArrayList<>(ALL); }
        @Override public CameraName nameFromCameraDirection(BuiltinCameraDirection d) { return new Name("BuiltinCamera(" + d + ")", true, null); }
        @Override public CameraName nameForUnknownCamera() { return new Name("UnknownCamera", false, null); }
        @Override public SwitchableCameraName nameForSwitchableCamera(CameraName... names) { return new Name("SwitchableCamera", false, names.clone()); }
    };
}
