package org.ftcsim;

import com.qualcomm.robotcore.exception.TargetPositionNotSetException;
import com.qualcomm.robotcore.hardware.DcMotorController;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.PIDCoefficients;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;
import java.util.Locale;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;

/**
 * Un motor pe Control Hub-ul simulat. Motoarele de tracțiune și mecanismele (intake, lansator)
 * își trimit puterea la sim și citesc encoderul de acolo. Motoarele „generice” (braț, glisieră...)
 * sunt simulate aici: viteza urmează puterea, iar encoderul se integrează.
 * RUN_TO_POSITION și RUN_USING_ENCODER (setVelocity) rulează un regulator ca firmware-ul hub-ului.
 * Ca pe Control Hub: în STOP_AND_RESET_ENCODER motorul nu se mișcă; RUN_TO_POSITION fără setTargetPosition()
 * aruncă TargetPositionNotSetException; toleranța implicită a isBusy() e 5 ticks.
 */
public class SimMotor implements DcMotorEx {
    static final double STALL_AMPS = 9.2;

    private final SimClient sim;
    private final String name;
    private final boolean simulatedHere;
    private Direction direction = Direction.FORWARD;
    private RunMode mode = RunMode.RUN_WITHOUT_ENCODER;
    private ZeroPowerBehavior zeroPower = ZeroPowerBehavior.BRAKE;
    private volatile double power = 0, sentPower = Double.NaN;
    // ce aplică update() după regulator: curentul vine din asta, nu din power (în RUN_TO_POSITION power e doar limita)
    private volatile double applied = 0;
    private volatile double targetVelocity = Double.NaN;
    private volatile int targetPosition = 0;
    private boolean targetSet = false;
    private int tolerance = 5;  // ca DcMotorImplEx
    private MotorConfigurationType motorType = new MotorConfigurationType();
    private PIDFCoefficients velocityPidf = new PIDFCoefficients(10, 3, 0, 0), positionPidf = new PIDFCoefficients(10, 0, 0, 0);
    private double currentAlertAmps = 8;
    private double encoderOffset = 0;
    private boolean enabled = true;
    private double kpVel = 0.0004;
    // pentru motoarele generice
    private double localPos = 0, localVel = 0, lastTime = -1;

    public SimMotor(SimClient sim, String name, boolean simulatedHere) {
        this.sim = sim;
        this.name = name;
        this.simulatedHere = simulatedHere;
        sim.onState(this::onState);
    }

    private double sign() { return direction == Direction.REVERSE ? -1 : 1; }
    /** Viteza maximă (ticks/s) a tipului de motor (implicit goBILDA 5203 312 rpm). */
    private double maxTps() { return motorType.getTicksPerRev() * motorType.getMaxRPM() / 60.0; }

    private double rawPos() {
        if (simulatedHere) return localPos;
        double[] v = sim.value(name);
        return v[0] + (v.length > 1 ? v[1] * sim.sinceState() : 0);  // continuu între cadre, ca un encoder real
    }
    private double rawVel() { return simulatedHere ? localVel : sim.value(name).length > 1 ? sim.value(name)[1] : 0; }

    /** La fiecare pas al simulării (~60 Hz): regulatoarele și motoarele generice. */
    private static final long MIN_SEND_NS = 4_000_000;
    private long lastSendNs = 0;
    private boolean fromState = false;

    private void onState() {
        fromState = true;
        update();
        fromState = false;
    }

    private void update() {
        double out = power;
        // ca pe hub: în RUN_TO_POSITION P-ul de poziție dă viteza țintă (ticks/s pe tick de eroare) a buclei de viteză,
        // iar puterea e limita; așa motorul frânează înainte de țintă, nu trece de ea după ce isBusy() e false
        if (!enabled || mode == RunMode.STOP_AND_RESET_ENCODER) out = 0;  // ca pe hub: în reset motorul stă
        else if (mode == RunMode.RUN_TO_POSITION) out = velocityLoop(positionPidf.p * (targetPosition - pos()), Math.abs(power));
        else if (mode == RunMode.RUN_USING_ENCODER && !Double.isNaN(targetVelocity)) out = velocityLoop(targetVelocity, 1);
        applied = out;
        if (simulatedHere) {
            double t = sim.simTime;
            double dt = lastTime < 0 ? 0 : Math.max(0, t - lastTime);
            lastTime = t;
            double target = out * sign() * maxTps();
            localVel += (target - localVel) * Math.min(1, dt / 0.08);  // inerția mecanismului
            localPos += localVel * dt;
        } else if (out != sentPower) {
            // ca pe hub: o scriere durează ~2 ms, deci o buclă fără sleep nu poate trimite mii de comenzi pe secundă.
            // Comenzile prea dese se strâng; ultima pleacă la următorul pas al simulării (onState -> update).
            long now = System.nanoTime();
            if (fromState || now - lastSendNs >= MIN_SEND_NS) {
                lastSendNs = now;
                sentPower = out;
                sim.send(String.format(Locale.ROOT, "POWER %s %.4f", SimClient.esc(name), out * sign()));
            }
        }
    }

    private double velocityLoop(double tps, double max) {
        return Math.max(-max, Math.min(max, tps / maxTps() + (tps - vel()) * kpVel));
    }

    @Override public void setDirection(Direction d) { direction = d; sentPower = Double.NaN; }
    @Override public Direction getDirection() { return direction; }

    @Override
    public void setPower(double p) {
        if (mode == RunMode.RUN_TO_POSITION && !targetSet && p != 0) throw new TargetPositionNotSetException();
        power = Math.max(-1, Math.min(1, p));
        targetVelocity = Double.NaN;
        if (mode != RunMode.RUN_TO_POSITION) update();
    }

    @Override public double getPower() { return power; }

    @Override
    public void setMode(RunMode m) {
        m = m.migrate();  // RESET_ENCODERS -> STOP_AND_RESET_ENCODER, ca în SDK
        if (m == RunMode.RUN_TO_POSITION && !targetSet && power != 0) throw new TargetPositionNotSetException();
        if (m == RunMode.STOP_AND_RESET_ENCODER) {
            encoderOffset = rawPos();
            power = 0;
            targetVelocity = Double.NaN;
            update();
        }
        mode = m;
    }

    @Override public RunMode getMode() { return mode; }
    @Override public void setZeroPowerBehavior(ZeroPowerBehavior b) { zeroPower = b; }
    @Override public ZeroPowerBehavior getZeroPowerBehavior() { return zeroPower; }

    // pos() / vel(): ce știe firmware-ul hub-ului (regulatoarele), fără timpul unei citiri
    private int pos() { return (int) Math.round((rawPos() - encoderOffset) * sign()); }
    private double vel() { return rawVel() * sign(); }

    @Override
    public int getCurrentPosition() {
        SimHub.read(this);
        return pos();
    }

    @Override public void setTargetPosition(int position) { targetPosition = position; targetSet = true; }
    @Override public int getTargetPosition() { return targetPosition; }

    @Override
    public boolean isBusy() {
        SimHub.read(this);
        return mode == RunMode.RUN_TO_POSITION && Math.abs(targetPosition - pos()) > tolerance;
    }

    @Override public double getVelocity() { SimHub.read(this); return vel(); }
    // ca în SDK: o viteză unghiulară nu se normalizează (poate depăși 180°/s)
    @Override public double getVelocity(AngleUnit unit) { return unit.getUnnormalized().fromRadians(getVelocity() / motorType.getTicksPerRev() * 2 * Math.PI); }
    @Override public void setVelocity(double tps) {
        targetVelocity = tps; power = Math.signum(tps);
        if (!simulatedHere) sim.send(String.format(Locale.ROOT, "VELOCITY %s %.2f", SimClient.esc(name), tps * sign()));  // lansatorul: viteza o face simulatorul
        update();
    }
    @Override public void setVelocity(double rate, AngleUnit unit) { setVelocity(unit.getUnnormalized().toRadians(rate) / (2 * Math.PI) * motorType.getTicksPerRev()); }

    @Override
    public double getCurrent(CurrentUnit unit) {
        double load = Math.abs(applied) - Math.abs(getVelocity()) / maxTps();  // o citire, ca pe hub
        double amps = 0.25 + STALL_AMPS * Math.max(0, Math.min(1, load));
        return unit == CurrentUnit.MILLIAMPS ? amps * 1000 : amps;
    }

    @Override public void setTargetPositionTolerance(int t) { tolerance = t; }
    @Override public int getTargetPositionTolerance() { return tolerance; }
    @Override public void setMotorEnable() { enabled = true; }
    @Override public void setMotorDisable() { enabled = false; update(); }
    @Override public boolean isMotorEnabled() { return enabled; }
    @Override public void setVelocityPIDFCoefficients(double p, double i, double d, double f) {
        velocityPidf = new PIDFCoefficients(p, i, d, f);
        kpVel = p * 0.00004;  // P-ul implicit al hub-ului (10) dă câștigul implicit; o scară mai mare face bucla instabilă la 60 Hz
    }
    @Override public void setPositionPIDFCoefficients(double p) { positionPidf = new PIDFCoefficients(p, 0, 0, 0); }
    @Override public void setPIDFCoefficients(RunMode m, PIDFCoefficients c) {
        if (m.migrate() == RunMode.RUN_TO_POSITION) setPositionPIDFCoefficients(c.p);
        else setVelocityPIDFCoefficients(c.p, c.i, c.d, c.f);
    }
    @Override public void setPIDCoefficients(RunMode m, PIDCoefficients c) { setPIDFCoefficients(m, new PIDFCoefficients(c)); }
    @Override public PIDFCoefficients getPIDFCoefficients(RunMode m) {
        return new PIDFCoefficients(m.migrate() == RunMode.RUN_TO_POSITION ? positionPidf : velocityPidf);
    }
    @Override public PIDCoefficients getPIDCoefficients(RunMode m) {
        PIDFCoefficients c = getPIDFCoefficients(m);
        return new PIDCoefficients(c.p, c.i, c.d);
    }
    @Override public double getCurrentAlert(CurrentUnit unit) { return unit == CurrentUnit.MILLIAMPS ? currentAlertAmps * 1000 : currentAlertAmps; }
    @Override public void setCurrentAlert(double current, CurrentUnit unit) { currentAlertAmps = unit == CurrentUnit.MILLIAMPS ? current / 1000 : current; }
    @Override public boolean isOverCurrent() { return getCurrent(CurrentUnit.AMPS) > currentAlertAmps; }
    @Override public MotorConfigurationType getMotorType() { return motorType; }
    @Override public void setMotorType(MotorConfigurationType t) { motorType = t; }
    @Override public int getPortNumber() { return 0; }
    @Override public void setPowerFloat() { zeroPower = ZeroPowerBehavior.FLOAT; setPower(0); }
    @Override public boolean getPowerFloat() { return zeroPower == ZeroPowerBehavior.FLOAT && power == 0; }

    /** Ca în SDK: motor.getController() (aici, un controller cu un singur port: acest motor). */
    @Override public DcMotorController getController() {
        final SimMotor m = this;
        return new DcMotorController() {
            @Override public void setMotorType(int port, MotorConfigurationType t) { m.setMotorType(t); }
            @Override public MotorConfigurationType getMotorType(int port) { return m.getMotorType(); }
            @Override public void setMotorMode(int port, RunMode mode) { m.setMode(mode); }
            @Override public RunMode getMotorMode(int port) { return m.getMode(); }
            @Override public void setMotorPower(int port, double p) { m.setPower(p); }
            @Override public double getMotorPower(int port) { return m.getPower(); }
            @Override public boolean isBusy(int port) { return m.isBusy(); }
            @Override public void setMotorZeroPowerBehavior(int port, ZeroPowerBehavior b) { m.setZeroPowerBehavior(b); }
            @Override public ZeroPowerBehavior getMotorZeroPowerBehavior(int port) { return m.getZeroPowerBehavior(); }
            @Override public boolean getMotorPowerFloat(int port) { return m.getPowerFloat(); }
            @Override public void setMotorTargetPosition(int port, int position) { m.setTargetPosition(position); }
            @Override public int getMotorTargetPosition(int port) { return m.getTargetPosition(); }
            @Override public int getMotorCurrentPosition(int port) { return m.getCurrentPosition(); }
            @Override public void resetDeviceConfigurationForOpMode(int port) {}
            @Override public String getDeviceName() { return "Control Hub (simulated)"; }
        };
    }
    @Override public String getDeviceName() { return "goBILDA 5203 (" + name + ")"; }
}
