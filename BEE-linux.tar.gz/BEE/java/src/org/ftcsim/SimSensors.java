package org.ftcsim;

import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import com.qualcomm.hardware.rev.RevColorSensorV3;
import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

/** Senzorii simulați: valorile vin de la sim la fiecare pas (raycast, contact, baterie). */
public final class SimSensors {
    private SimSensors() {}

    public static class Distance extends Rev2mDistanceSensor {
        private final SimClient sim;
        private final String name;
        public Distance(SimClient sim, String name) { this.sim = sim; this.name = name; }
        @Override public double getDistance(DistanceUnit unit) { return unit.fromInches(sim.value(name)[0]); }
    }

    public static class Color extends RevColorSensorV3 {
        private final SimClient sim;
        private final String name;
        private float gain = 1;
        public Color(SimClient sim, String name) { this.sim = sim; this.name = name; }

        @Override public NormalizedRGBA getNormalizedColors() {
            double[] v = sim.value(name);
            NormalizedRGBA c = new NormalizedRGBA();
            c.red = (float) Math.min(1, v[0] * gain);
            c.green = (float) Math.min(1, v[1] * gain);
            c.blue = (float) Math.min(1, v[2] * gain);
            c.alpha = (float) Math.min(1, v[3] * gain);
            return c;
        }
        @Override public float getGain() { return gain; }
        @Override public void setGain(float g) { gain = g; }
        @Override public int red() { return (int) (sim.value(name)[0] * 1000); }
        @Override public int green() { return (int) (sim.value(name)[1] * 1000); }
        @Override public int blue() { return (int) (sim.value(name)[2] * 1000); }
        @Override public int alpha() { return (int) (sim.value(name)[3] * 1000); }
        @Override public int argb() { return getNormalizedColors().toColor(); }
        @Override public void enableLed(boolean enable) {}
        @Override public double getDistance(DistanceUnit unit) { return unit.fromInches(sim.value(name)[4]); }
    }

    public static class Touch extends RevTouchSensor {
        private final SimClient sim;
        private final String name;
        private Mode mode = Mode.INPUT;
        public Touch(SimClient sim, String name) { this.sim = sim; this.name = name; }
        @Override public boolean isPressed() { return sim.value(name)[0] > 0.5; }
        @Override public double getValue() { return isPressed() ? 1 : 0; }
        @Override public Mode getMode() { return mode; }
        @Override public void setMode(Mode m) { mode = m; }
        @Override public boolean getState() { return !isPressed(); }  // ca butonul REV pe port digital
        @Override public void setState(boolean s) {}
    }

    public static class Voltage implements VoltageSensor {
        private final SimClient sim;
        public Voltage(SimClient sim) { this.sim = sim; }
        @Override public double getVoltage() { return sim.value("voltage")[0]; }
        @Override public String getDeviceName() { return "Control Hub voltage"; }
    }
}
