package org.ftcsim;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import java.util.ArrayList;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.navigation.*;

/**
 * Limelight 3A simulată. Coordonatele de teren (botpose) sunt în METRI, ca la Limelight în modul FTC:
 * originea în centrul terenului, X spre alianța albastră, Y spre peretele din spate, Z în sus;
 * yaw în grade, 0 = spre +X, pozitiv trigonometric.
 */
public class SimLimelight extends Limelight3A {
    private final SimClient sim;
    private final String name;
    private boolean running = false;
    private int pipeline = 0;

    public SimLimelight(SimClient sim, String name) { this.sim = sim; this.name = name; }

    @Override public void start() { running = true; }
    @Override public void pause() { running = false; }
    @Override public void stop() { running = false; }
    @Override public boolean pipelineSwitch(int index) { pipeline = index; return true; }
    @Override public boolean isConnected() { return sim.isConnected(); }
    @Override public boolean isRunning() { return running; }

    private static Pose3D pose(double xIn, double yIn, double zIn, double yawDeg) {
        return new Pose3D(new Position(DistanceUnit.METER, xIn * 0.0254, yIn * 0.0254, zIn * 0.0254, System.nanoTime()),
                new YawPitchRollAngles(AngleUnit.DEGREES, yawDeg, 0, 0, System.nanoTime()));
    }

    @Override
    public LLResult getLatestResult() {
        SimClient.VisionFrame f = sim.vision(name);
        if (!running || f == null) return null;
        noteUpdate();
        // detecția pieselor (ca un pipeline cu rețea neurală pe Limelight): clase pollen / nectar_red / nectar_blue
        List<LLResultTypes.DetectorResult> det = new ArrayList<>();
        for (SimClient.Detection d : sim.detections(name)) {
            int id = d.cls.equals("pollen") ? 0 : d.cls.equals("nectar_red") ? 1 : 2;
            det.add(new LLResultTypes.DetectorResult(d.cls, id, 0.92, d.tx, d.ty, d.ta));
        }
        Pose3D bot = pose(f.botpose[0], f.botpose[1], 0, f.botpose[2]);
        List<LLResultTypes.FiducialResult> list = new ArrayList<>();
        double bestTa = -1, tx = 0, ty = 0, ta = 0;
        for (double[] t : f.tags) {
            // față de cameră, ca Limelight: x dreapta, y jos, z înainte
            Pose3D camSpace = new Pose3D(new Position(DistanceUnit.METER, t[4] * 0.0254, -t[6] * 0.0254, t[5] * 0.0254, 0),
                    new YawPitchRollAngles(AngleUnit.DEGREES, 0, 0, 0, 0));
            list.add(new LLResultTypes.FiducialResult((int) t[0], t[1], t[2], t[3], bot, camSpace));
            if (t[3] > bestTa) { bestTa = t[3]; tx = t[1]; ty = t[2]; ta = t[3]; }
        }
        if (!f.valid && !det.isEmpty()) { tx = det.get(0).getTargetXDegrees(); ty = det.get(0).getTargetYDegrees(); ta = det.get(0).getTargetArea(); }
        return new LLResult(f.valid || !det.isEmpty(), tx, ty, ta, f.valid ? bot : null, list, det, f.timeMs, pipeline);
    }
}
