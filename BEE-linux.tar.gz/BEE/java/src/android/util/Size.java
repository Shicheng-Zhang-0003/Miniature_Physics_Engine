package android.util;

/** Ca în Android: o rezoluție (lățime x înălțime, pixeli), ex. new Size(640, 480) pentru camera. */
public final class Size {
    private final int width, height;

    public Size(int width, int height) { this.width = width; this.height = height; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }

    /** "640x480" sau "640*480", ca în Android. */
    public static Size parseSize(String string) throws NumberFormatException {
        if (string == null) throw new NullPointerException("string must not be null");
        int sep = string.indexOf('*');
        if (sep < 0) sep = string.indexOf('x');
        if (sep < 0) throw new NumberFormatException("Invalid Size: \"" + string + "\"");
        try {
            return new Size(Integer.parseInt(string.substring(0, sep)), Integer.parseInt(string.substring(sep + 1)));
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Invalid Size: \"" + string + "\"");
        }
    }

    @Override public boolean equals(Object o) { return o instanceof Size && ((Size) o).width == width && ((Size) o).height == height; }
    @Override public int hashCode() { return height ^ ((width << 16) | (width >>> 16)); }
    @Override public String toString() { return width + "x" + height; }
}
