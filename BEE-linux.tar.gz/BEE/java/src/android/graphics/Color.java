package android.graphics;

/**
 * Ca în Android: culorile ca int ARGB și conversia RGB <-> HSV (același algoritm ca Android / Skia).
 * Codul echipelor o folosește la senzorul de culoare: Color.RGBToHSV(r, g, b, hsv) -> hsv[0] = nuanța (0..360).
 */
public class Color {
    public static final int BLACK = 0xFF000000, DKGRAY = 0xFF444444, GRAY = 0xFF888888, LTGRAY = 0xFFCCCCCC, WHITE = 0xFFFFFFFF,
            RED = 0xFFFF0000, GREEN = 0xFF00FF00, BLUE = 0xFF0000FF, YELLOW = 0xFFFFFF00, CYAN = 0xFF00FFFF, MAGENTA = 0xFFFF00FF,
            TRANSPARENT = 0;

    public static int alpha(int color) { return color >>> 24; }
    public static int red(int color) { return (color >> 16) & 0xFF; }
    public static int green(int color) { return (color >> 8) & 0xFF; }
    public static int blue(int color) { return color & 0xFF; }
    public static int rgb(int red, int green, int blue) { return 0xFF000000 | (red << 16) | (green << 8) | blue; }
    public static int argb(int alpha, int red, int green, int blue) { return (alpha << 24) | (red << 16) | (green << 8) | blue; }

    /** hsv[0] = nuanța 0..360, hsv[1] = saturația 0..1, hsv[2] = valoarea 0..1 (canalele RGB 0..255). */
    public static void RGBToHSV(int red, int green, int blue, float[] hsv) {
        int r = clamp(red), g = clamp(green), b = clamp(blue);
        int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), delta = max - min;
        hsv[2] = max / 255f;
        if (delta == 0) {  // gri
            hsv[0] = 0;
            hsv[1] = 0;
            return;
        }
        hsv[1] = (float) delta / max;
        float h;
        if (r == max) h = (float) (g - b) / delta;
        else if (g == max) h = 2 + (float) (b - r) / delta;
        else h = 4 + (float) (r - g) / delta;
        h *= 60;
        if (h < 0) h += 360;
        hsv[0] = h;
    }

    public static void colorToHSV(int color, float[] hsv) { RGBToHSV(red(color), green(color), blue(color), hsv); }

    public static int HSVToColor(float[] hsv) { return HSVToColor(0xFF, hsv); }

    public static int HSVToColor(int alpha, float[] hsv) {
        float s = Math.max(0, Math.min(1, hsv[1])), v = Math.max(0, Math.min(1, hsv[2]));
        int vb = Math.round(v * 255);
        if (s < 1e-6f) return argb(alpha, vb, vb, vb);
        float hx = (hsv[0] < 0 || hsv[0] >= 360) ? 0 : hsv[0] / 60;
        float w = (float) Math.floor(hx), f = hx - w;
        int p = Math.round((1 - s) * v * 255), q = Math.round((1 - s * f) * v * 255), t = Math.round((1 - s * (1 - f)) * v * 255);
        switch ((int) w) {
            case 0: return argb(alpha, vb, t, p);
            case 1: return argb(alpha, q, vb, p);
            case 2: return argb(alpha, p, vb, t);
            case 3: return argb(alpha, p, q, vb);
            case 4: return argb(alpha, t, p, vb);
            default: return argb(alpha, vb, p, q);
        }
    }

    private static int clamp(int c) { return Math.max(0, Math.min(255, c)); }
}
