package com.acmerobotics.roadrunner.ftc;

import com.qualcomm.robotcore.hardware.DcMotorSimple;

/** Road Runner FTC (simulated in BEE): an encoder with a direction. */
public interface Encoder {
    PositionVelocityPair getPositionAndVelocity();
    DcMotorSimple.Direction getDirection();
    void setDirection(DcMotorSimple.Direction direction);
}
