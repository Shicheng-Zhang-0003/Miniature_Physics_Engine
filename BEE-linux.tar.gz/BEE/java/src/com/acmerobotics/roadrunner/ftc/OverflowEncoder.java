package com.acmerobotics.roadrunner.ftc;

import com.qualcomm.robotcore.hardware.DcMotorSimple;

/** Road Runner FTC (simulated in BEE): fixes the 16-bit velocity overflow of the hub. The simulator has none: it just delegates. */
public class OverflowEncoder implements Encoder {
    public final RawEncoder encoder;

    public OverflowEncoder(RawEncoder e) { encoder = e; }

    @Override public PositionVelocityPair getPositionAndVelocity() { return encoder.getPositionAndVelocity(); }
    @Override public DcMotorSimple.Direction getDirection() { return encoder.getDirection(); }
    @Override public void setDirection(DcMotorSimple.Direction d) { encoder.setDirection(d); }
}
