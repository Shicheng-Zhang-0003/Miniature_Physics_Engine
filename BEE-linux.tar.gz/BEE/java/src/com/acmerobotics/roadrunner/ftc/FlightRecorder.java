package com.acmerobotics.roadrunner.ftc;

/** Road Runner FTC (simulated in BEE): logs messages to a file on the robot. In BEE: ignored. */
public final class FlightRecorder {
    private FlightRecorder() {}
    public static void write(String channel, Object message) {}
}
