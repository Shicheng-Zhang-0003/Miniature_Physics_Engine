package com.acmerobotics.roadrunner.ftc;

import com.qualcomm.robotcore.hardware.IMU;

/** Road Runner FTC (simulated in BEE): an IMU initialized the first time it is used. */
public interface LazyImu {
    IMU get();
}
