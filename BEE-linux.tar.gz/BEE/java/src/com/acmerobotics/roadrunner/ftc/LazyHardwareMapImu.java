package com.acmerobotics.roadrunner.ftc;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.ImuOrientationOnRobot;

/** Road Runner FTC (simulated in BEE): the IMU from the hardware map, initialized on first use. */
public class LazyHardwareMapImu implements LazyImu {
    private final HardwareMap hardwareMap;
    private final String name;
    private final ImuOrientationOnRobot orientation;
    private IMU imu;

    public LazyHardwareMapImu(HardwareMap hardwareMap, String name, ImuOrientationOnRobot orientation) {
        this.hardwareMap = hardwareMap;
        this.name = name;
        this.orientation = orientation;
    }

    @Override public IMU get() {
        if (imu == null) {
            imu = hardwareMap.get(IMU.class, name);
            imu.initialize(new IMU.Parameters(orientation));
        }
        return imu;
    }
}
