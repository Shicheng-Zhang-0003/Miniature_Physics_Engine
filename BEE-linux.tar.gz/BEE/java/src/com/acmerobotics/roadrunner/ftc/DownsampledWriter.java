package com.acmerobotics.roadrunner.ftc;

/** Road Runner FTC (simulated in BEE): a FlightRecorder channel written at most every maxPeriod ns. In BEE: ignored. */
public final class DownsampledWriter {
    public DownsampledWriter(String channel, long maxPeriod) {}
    public void write(Object message) {}
}
