package com.acmerobotics.roadrunner.ftc;

import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

/**
 * Road Runner FTC (simulated in BEE, same behavior as road-runner-ftc): reads a motor's encoder port.
 * The motor's direction is undone and the encoder's own direction applied, so the two are independent.
 */
public class RawEncoder implements Encoder {
    private final DcMotorEx m;
    private DcMotorSimple.Direction direction = DcMotorSimple.Direction.FORWARD;

    public RawEncoder(DcMotorEx m) { this.m = m; }

    private int applyDirection(int x) {
        if (m.getDirection() == DcMotorSimple.Direction.REVERSE) x = -x;
        if (direction == DcMotorSimple.Direction.REVERSE) x = -x;
        return x;
    }

    @Override public PositionVelocityPair getPositionAndVelocity() {
        int rawPosition = m.getCurrentPosition();
        int rawVelocity = (int) m.getVelocity();
        return new PositionVelocityPair(applyDirection(rawPosition), applyDirection(rawVelocity), rawPosition, rawVelocity);
    }
    @Override public DcMotorSimple.Direction getDirection() { return direction; }
    @Override public void setDirection(DcMotorSimple.Direction d) { direction = d; }
}
