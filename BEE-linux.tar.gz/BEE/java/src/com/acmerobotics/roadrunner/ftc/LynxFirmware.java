package com.acmerobotics.roadrunner.ftc;

import com.qualcomm.robotcore.hardware.HardwareMap;

/** Road Runner FTC (simulated in BEE): checks the hub firmware. The simulated hubs are always up to date. */
public final class LynxFirmware {
    private LynxFirmware() {}
    public static void throwIfModulesAreOutdated(HardwareMap hardwareMap) {}
}
