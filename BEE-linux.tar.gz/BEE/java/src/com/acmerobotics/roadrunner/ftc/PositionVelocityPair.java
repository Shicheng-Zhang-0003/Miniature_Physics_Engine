package com.acmerobotics.roadrunner.ftc;

/** Road Runner FTC (simulated in BEE, same API as road-runner-ftc 0.1.x): an encoder reading. */
public final class PositionVelocityPair {
    public final int position, velocity, rawPosition, rawVelocity;

    public PositionVelocityPair(int position, int velocity, int rawPosition, int rawVelocity) {
        this.position = position;
        this.velocity = velocity;
        this.rawPosition = rawPosition;
        this.rawVelocity = rawVelocity;
    }

    public PositionVelocityPair(int position, int velocity) { this(position, velocity, position, velocity); }
}
