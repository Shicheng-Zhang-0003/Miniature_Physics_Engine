package com.acmerobotics.dashboard.config;

import java.lang.annotation.*;

/** FTC Dashboard: marks a class whose static fields can be edited live from the dashboard. In BEE: no effect. */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Config {
    String value() default "";
}
