package com.qualcomm.robotcore.hardware;

import com.qualcomm.hardware.lynx.LynxModule;
import java.util.*;

/**
 * Ca în SDK-ul FTC: hardwareMap.get(DcMotorEx.class, "left_front_drive"), hardwareMap.dcMotor.get(...),
 * hardwareMap.getAll(LynxModule.class), hardwareMap.voltageSensor.iterator().next() ...
 * Numele vin din configurația robotului din garaj (ca „Configure Robot” de pe Driver Station).
 */
public class HardwareMap implements Iterable<HardwareDevice> {
    public class DeviceMapping<T> implements Iterable<T> {
        private final Class<T> type;
        DeviceMapping(Class<T> type) { this.type = type; }

        public T get(String deviceName) { return HardwareMap.this.get(type, deviceName); }
        public boolean contains(String deviceName) { return find(type, deviceName) != null; }
        public int size() { return entrySet().size(); }
        public Set<Map.Entry<String, T>> entrySet() {
            Map<String, T> m = new LinkedHashMap<>();
            for (String n : devices.keySet()) {
                T d = find(type, n);
                if (d != null) m.put(n, d);
            }
            return m.entrySet();
        }
        @Override public Iterator<T> iterator() {
            List<T> l = new ArrayList<>();
            for (Map.Entry<String, T> e : entrySet()) l.add(e.getValue());
            return l.iterator();
        }
    }

    // ca în SDK: același nume poate avea dispozitive de tipuri diferite („Control Hub” = LynxModule + senzorul de tensiune)
    private final Map<String, List<Object>> devices = new LinkedHashMap<>();
    public final DeviceMapping<DcMotor> dcMotor = new DeviceMapping<>(DcMotor.class);
    public final DeviceMapping<Servo> servo = new DeviceMapping<>(Servo.class);
    public final DeviceMapping<CRServo> crservo = new DeviceMapping<>(CRServo.class);
    public final DeviceMapping<TouchSensor> touchSensor = new DeviceMapping<>(TouchSensor.class);
    public final DeviceMapping<ColorSensor> colorSensor = new DeviceMapping<>(ColorSensor.class);
    public final DeviceMapping<DigitalChannel> digitalChannel = new DeviceMapping<>(DigitalChannel.class);
    public final DeviceMapping<VoltageSensor> voltageSensor = new DeviceMapping<>(VoltageSensor.class);
    public final DeviceMapping<OpticalDistanceSensor> opticalDistanceSensor = new DeviceMapping<>(OpticalDistanceSensor.class);
    public final DeviceMapping<AnalogInput> analogInput = new DeviceMapping<>(AnalogInput.class);
    public final DeviceMapping<LED> led = new DeviceMapping<>(LED.class);
    public final DeviceMapping<LightSensor> lightSensor = new DeviceMapping<>(LightSensor.class);
    public final DeviceMapping<DcMotorController> dcMotorController = new DeviceMapping<>(DcMotorController.class);
    public final DeviceMapping<ServoController> servoController = new DeviceMapping<>(ServoController.class);

    public void put(String name, Object device) {
        devices.computeIfAbsent(name, k -> new ArrayList<>()).add(device);
    }

    private <T> T find(Class<? extends T> type, String name) {
        for (Object d : devices.getOrDefault(name, Collections.emptyList())) if (type.isInstance(d)) return type.cast(d);
        return null;
    }

    public <T> T get(Class<? extends T> classOrInterface, String deviceName) {
        T d = find(classOrInterface, deviceName);
        if (d == null) {
            throw new IllegalArgumentException(String.format(
                "Unable to find a hardware device with name \"%s\" and type %s",
                deviceName, classOrInterface.getSimpleName()));
        }
        return d;
    }

    public Object get(String deviceName) {
        List<Object> l = devices.get(deviceName);
        if (l == null) throw new IllegalArgumentException("Unable to find a hardware device with name \"" + deviceName + "\"");
        return l.get(0);
    }

    public <T> T tryGet(Class<? extends T> classOrInterface, String deviceName) {
        return find(classOrInterface, deviceName);
    }

    public <T> List<T> getAll(Class<? extends T> classOrInterface) {
        List<T> out = new ArrayList<>();
        for (List<Object> l : devices.values()) for (Object d : l) if (classOrInterface.isInstance(d)) out.add(classOrInterface.cast(d));
        return out;
    }

    /** Ca în SDK: numele tuturor dispozitivelor de un anumit tip, sortate. */
    public SortedSet<String> getAllNames(Class<? extends HardwareDevice> classOrInterface) {
        SortedSet<String> out = new TreeSet<>();
        for (String n : devices.keySet()) if (find(classOrInterface, n) != null) out.add(n);
        return out;
    }

    public int size() {
        int n = 0;
        for (List<Object> l : devices.values()) n += l.size();
        return n;
    }

    public Set<String> getNamesOf(HardwareDevice device) {
        Set<String> s = new HashSet<>();
        for (Map.Entry<String, List<Object>> e : devices.entrySet()) if (e.getValue().contains(device)) s.add(e.getKey());
        return s;
    }

    @Override public Iterator<HardwareDevice> iterator() {
        List<HardwareDevice> l = new ArrayList<>();
        for (List<Object> ds : devices.values()) for (Object d : ds) if (d instanceof HardwareDevice) l.add((HardwareDevice) d);
        return l.iterator();
    }
}
