package com.qualcomm.robotcore.hardware;

import java.util.Locale;

/** Ca în SDK-ul FTC. */
public class PIDCoefficients {
    public double p, i, d;

    public PIDCoefficients() {}
    public PIDCoefficients(double p, double i, double d) { this.p = p; this.i = i; this.d = d; }

    @Override public String toString() { return String.format(Locale.ROOT, "%s(p=%f i=%f d=%f)", getClass().getSimpleName(), p, i, d); }
}
