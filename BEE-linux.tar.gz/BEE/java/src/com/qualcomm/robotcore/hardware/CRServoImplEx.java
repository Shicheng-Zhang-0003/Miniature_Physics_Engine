package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: un servo continuu cu control PWM (setPwmRange / setPwmDisable). */
public abstract class CRServoImplEx extends CRServoImpl implements PwmControl {
    protected PwmRange pwmRange = PwmRange.defaultRange;

    @Override public void setPwmRange(PwmRange range) { pwmRange = range; }
    @Override public PwmRange getPwmRange() { return pwmRange; }
}
