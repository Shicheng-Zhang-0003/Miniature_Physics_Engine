package com.qualcomm.robotcore.hardware.configuration.typecontainers;

/**
 * Ca în SDK-ul FTC: tipul de motor din configurație (ticks / rotație, turație). Codul Road Runner 0.5 și multe
 * clase de drivetrain fac motor.getMotorType().clone() ... setAchieveableMaxRPMFraction(1.0) ... setMotorType(...).
 * În simulator: goBILDA 5203 312 rpm, dacă motorul nu spune altfel.
 */
public final class MotorConfigurationType implements Cloneable {
    private double ticksPerRev = 537.7, gearing = 19.2, maxRPM = 312, achieveableMaxRPMFraction = 0.85;
    private String name = "goBILDA 5203 series";

    public MotorConfigurationType() {}

    public static MotorConfigurationType getUnspecifiedMotorType() {
        MotorConfigurationType t = new MotorConfigurationType();
        t.name = "Unspecified";
        t.ticksPerRev = 28;
        t.gearing = 1;
        t.maxRPM = 6000;
        return t;
    }

    public double getTicksPerRev() { return ticksPerRev; }
    public void setTicksPerRev(double v) { ticksPerRev = v; }
    public double getGearing() { return gearing; }
    public void setGearing(double v) { gearing = v; }
    public double getMaxRPM() { return maxRPM; }
    public void setMaxRPM(double v) { maxRPM = v; }
    public double getAchieveableMaxRPMFraction() { return achieveableMaxRPMFraction; }
    public void setAchieveableMaxRPMFraction(double v) { achieveableMaxRPMFraction = v; }
    public double getAchieveableMaxTicksPerSecond() { return ticksPerRev * maxRPM * achieveableMaxRPMFraction / 60.0; }
    public int getAchieveableMaxTicksPerSecondRounded() { return (int) Math.round(getAchieveableMaxTicksPerSecond()); }
    public String getName() { return name; }

    @Override public MotorConfigurationType clone() {
        try {
            return (MotorConfigurationType) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    @Override public String toString() { return name; }
}
