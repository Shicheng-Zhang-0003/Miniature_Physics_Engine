package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: clasa servo-urilor continue din hardwareMap (în simulator: org.ftcsim.SimCRServo). */
public abstract class CRServoImpl implements CRServo {
}
