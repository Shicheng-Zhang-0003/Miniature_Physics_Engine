package com.qualcomm.robotcore.hardware;

import java.util.ArrayList;

/**
 * Ca în SDK-ul FTC. În simulator: controllerul conectat la Mac sau tastatura
 * (W/S, săgeți, A/D, J/K/U/I = a/b/x/y, Q/E = bumpere, Z/X = triggere, Enter = start).
 */
public class Gamepad {
    public enum Type { UNKNOWN, LOGITECH_F310, XBOX_360, SONY_PS4, SONY_PS4_SUPPORTED_BY_KERNEL }

    public static final int ID_UNASSOCIATED = -1;
    public static final int ID_SYNTHETIC = -2;
    public static final int RUMBLE_DURATION_CONTINUOUS = -1;
    public static final int LED_DURATION_CONTINUOUS = -1;

    public volatile float left_stick_x, left_stick_y, right_stick_x, right_stick_y, left_trigger, right_trigger;
    public volatile boolean a, b, x, y, dpad_up, dpad_down, dpad_left, dpad_right, left_bumper, right_bumper,
            start, back, guide, left_stick_button, right_stick_button;
    // aliasuri PlayStation
    public volatile boolean cross, circle, square, triangle, share, options, ps;
    // touchpad-ul PS4 / PS5 (tastatura nu are: rămân false / 0)
    public volatile boolean touchpad, touchpad_finger_1, touchpad_finger_2;
    public volatile float touchpad_finger_1_x, touchpad_finger_1_y, touchpad_finger_2_x, touchpad_finger_2_y;
    public volatile int id = ID_UNASSOCIATED;
    public volatile long timestamp = 0;
    public Type type = Type.UNKNOWN;

    /** Ca în SDK: apăsarea / eliberarea se reține când vin date noi și se șterge la citire (nu se pierde un tap scurt). */
    private static final class Edge {
        boolean last, pressed, released;
        void update(boolean now) {
            if (!last && now) pressed = true;
            if (last && !now) released = true;
            last = now;
        }
        boolean takePressed() { boolean r = pressed; pressed = false; return r; }
        boolean takeReleased() { boolean r = released; released = false; return r; }
    }
    // ordinea: a b x y du dd dl dr lb rb start back guide lsb rsb touchpad
    private final Edge[] edges = new Edge[16];
    { for (int i = 0; i < edges.length; i++) edges[i] = new Edge(); }

    private synchronized void updateEdges() {
        boolean[] v = {a, b, x, y, dpad_up, dpad_down, dpad_left, dpad_right, left_bumper, right_bumper,
                start, back, guide, left_stick_button, right_stick_button, touchpad};
        for (int i = 0; i < v.length; i++) edges[i].update(v[i]);
    }
    private synchronized boolean pressed(int i) { return edges[i].takePressed(); }
    private synchronized boolean released(int i) { return edges[i].takeReleased(); }

    public boolean atRest() {
        return Math.abs(left_stick_x) < 0.05 && Math.abs(left_stick_y) < 0.05 && Math.abs(right_stick_x) < 0.05
                && Math.abs(right_stick_y) < 0.05 && left_trigger < 0.05 && right_trigger < 0.05;
    }

    public Type type() { return type; }
    public int getGamepadId() { return id; }
    public void setGamepadId(int id) { this.id = id; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public void refreshTimestamp() { timestamp = System.nanoTime(); }

    /** Ca în SDK: copiază starea (folosit pentru „previousGamepad1.copy(currentGamepad1)”). */
    public void copy(Gamepad g) {
        left_stick_x = g.left_stick_x; left_stick_y = g.left_stick_y; right_stick_x = g.right_stick_x; right_stick_y = g.right_stick_y;
        left_trigger = g.left_trigger; right_trigger = g.right_trigger;
        a = g.a; b = g.b; x = g.x; y = g.y; dpad_up = g.dpad_up; dpad_down = g.dpad_down; dpad_left = g.dpad_left; dpad_right = g.dpad_right;
        left_bumper = g.left_bumper; right_bumper = g.right_bumper; start = g.start; back = g.back; guide = g.guide;
        left_stick_button = g.left_stick_button; right_stick_button = g.right_stick_button;
        cross = g.cross; circle = g.circle; square = g.square; triangle = g.triangle; share = g.share; options = g.options; ps = g.ps;
        touchpad = g.touchpad; touchpad_finger_1 = g.touchpad_finger_1; touchpad_finger_2 = g.touchpad_finger_2;
        touchpad_finger_1_x = g.touchpad_finger_1_x; touchpad_finger_1_y = g.touchpad_finger_1_y;
        touchpad_finger_2_x = g.touchpad_finger_2_x; touchpad_finger_2_y = g.touchpad_finger_2_y;
        id = g.id; timestamp = g.timestamp; type = g.type;
        updateEdges();
    }

    public void reset() { copy(new Gamepad()); }
    public synchronized void resetEdgeDetection() { for (Edge e : edges) { e.pressed = false; e.released = false; } }

    // vibrația și LED-ul: controllerul simulat nu le are, dar codul trebuie să compileze și să ruleze
    public static class RumbleEffect {
        public static class Step { public int large, small, duration; }
        public int user;
        public final ArrayList<Step> steps;
        private RumbleEffect(ArrayList<Step> steps) { this.steps = steps; }
        public String serialize() { return ""; }
        public static RumbleEffect deserialize(String s) { return new RumbleEffect(new ArrayList<Step>()); }
        public static class Builder {
            private final ArrayList<Step> steps = new ArrayList<>();
            public Builder addStep(double rumble1, double rumble2, int durationMs) {
                Step s = new Step();
                s.large = (int) Math.round(Math.max(0, Math.min(1, rumble1)) * 255);
                s.small = (int) Math.round(Math.max(0, Math.min(1, rumble2)) * 255);
                s.duration = durationMs;
                steps.add(s);
                return this;
            }
            public RumbleEffect build() { return new RumbleEffect(steps); }
        }
    }

    public static class LedEffect {
        public static class Step { public int r, g, b, duration; }
        public final ArrayList<Step> steps;
        public final boolean repeating;
        public int user;
        private LedEffect(ArrayList<Step> steps, boolean repeating) { this.steps = steps; this.repeating = repeating; }
        public String serialize() { return ""; }
        public static LedEffect deserialize(String s) { return new LedEffect(new ArrayList<Step>(), false); }
        public static class Builder {
            private final ArrayList<Step> steps = new ArrayList<>();
            private boolean repeating;
            public Builder addStep(double r, double g, double b, int durationMs) {
                Step s = new Step();
                s.r = (int) Math.round(r * 255); s.g = (int) Math.round(g * 255); s.b = (int) Math.round(b * 255);
                s.duration = durationMs;
                steps.add(s);
                return this;
            }
            public Builder setRepeating(boolean repeating) { this.repeating = repeating; return this; }
            public LedEffect build() { return new LedEffect(steps, repeating); }
        }
    }

    private long rumbleUntil = 0;
    public void rumble(int durationMs) { rumbleUntil = durationMs < 0 ? Long.MAX_VALUE : System.currentTimeMillis() + durationMs; }
    public void rumble(double rumble1, double rumble2, int durationMs) { rumble(durationMs); }
    public void rumbleBlips(int count) { rumble(count * 300); }
    public void runRumbleEffect(RumbleEffect effect) {
        int total = 0;
        for (RumbleEffect.Step s : effect.steps) total += s.duration;
        rumble(total);
    }
    public boolean isRumbling() { return System.currentTimeMillis() < rumbleUntil; }
    public void stopRumble() { rumbleUntil = 0; }
    public void setLedColor(double r, double g, double b, int durationMs) {}
    public void runLedEffect(LedEffect effect) {}

    // ca în SDK 10.1+: true o singură dată pentru fiecare apăsare / eliberare
    public boolean aWasPressed() { return pressed(0); }
    public boolean aWasReleased() { return released(0); }
    public boolean bWasPressed() { return pressed(1); }
    public boolean bWasReleased() { return released(1); }
    public boolean xWasPressed() { return pressed(2); }
    public boolean xWasReleased() { return released(2); }
    public boolean yWasPressed() { return pressed(3); }
    public boolean yWasReleased() { return released(3); }
    public boolean crossWasPressed() { return pressed(0); }
    public boolean crossWasReleased() { return released(0); }
    public boolean circleWasPressed() { return pressed(1); }
    public boolean circleWasReleased() { return released(1); }
    public boolean squareWasPressed() { return pressed(2); }
    public boolean squareWasReleased() { return released(2); }
    public boolean triangleWasPressed() { return pressed(3); }
    public boolean triangleWasReleased() { return released(3); }
    public boolean dpadUpWasPressed() { return pressed(4); }
    public boolean dpadUpWasReleased() { return released(4); }
    public boolean dpadDownWasPressed() { return pressed(5); }
    public boolean dpadDownWasReleased() { return released(5); }
    public boolean dpadLeftWasPressed() { return pressed(6); }
    public boolean dpadLeftWasReleased() { return released(6); }
    public boolean dpadRightWasPressed() { return pressed(7); }
    public boolean dpadRightWasReleased() { return released(7); }
    public boolean leftBumperWasPressed() { return pressed(8); }
    public boolean leftBumperWasReleased() { return released(8); }
    public boolean rightBumperWasPressed() { return pressed(9); }
    public boolean rightBumperWasReleased() { return released(9); }
    public boolean startWasPressed() { return pressed(10); }
    public boolean startWasReleased() { return released(10); }
    public boolean optionsWasPressed() { return pressed(10); }
    public boolean optionsWasReleased() { return released(10); }
    public boolean backWasPressed() { return pressed(11); }
    public boolean backWasReleased() { return released(11); }
    public boolean shareWasPressed() { return pressed(11); }
    public boolean shareWasReleased() { return released(11); }
    public boolean guideWasPressed() { return pressed(12); }
    public boolean guideWasReleased() { return released(12); }
    public boolean psWasPressed() { return pressed(12); }
    public boolean psWasReleased() { return released(12); }
    public boolean leftStickButtonWasPressed() { return pressed(13); }
    public boolean leftStickButtonWasReleased() { return released(13); }
    public boolean rightStickButtonWasPressed() { return pressed(14); }
    public boolean rightStickButtonWasReleased() { return released(14); }
    public boolean touchpadWasPressed() { return pressed(15); }
    public boolean touchpadWasReleased() { return released(15); }

    /** Folosit de simulator. */
    public void setFromSim(float[] axes, int buttons) {
        left_stick_x = axes[0]; left_stick_y = axes[1]; right_stick_x = axes[2]; right_stick_y = axes[3];
        left_trigger = axes[4]; right_trigger = axes[5];
        boolean[] v = new boolean[15];
        for (int i = 0; i < 15; i++) v[i] = (buttons & (1 << i)) != 0;
        a = v[0]; b = v[1]; x = v[2]; y = v[3]; dpad_up = v[4]; dpad_down = v[5]; dpad_left = v[6]; dpad_right = v[7];
        left_bumper = v[8]; right_bumper = v[9]; start = v[10]; back = v[11]; guide = v[12];
        left_stick_button = v[13]; right_stick_button = v[14];
        cross = a; circle = b; square = x; triangle = y; options = start; share = back; ps = guide;
        timestamp = System.nanoTime();
        updateEdges();
    }

    @Override public String toString() {
        return String.format(java.util.Locale.ROOT, "ID: %d user: 1 lx: % 1.2f ly: % 1.2f rx: % 1.2f ry: % 1.2f lt: %1.2f rt: %1.2f",
                id, left_stick_x, left_stick_y, right_stick_x, right_stick_y, left_trigger, right_trigger);
    }
}
