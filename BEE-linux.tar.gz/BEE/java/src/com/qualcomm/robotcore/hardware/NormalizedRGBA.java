package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: culori normalizate 0..1. */
public class NormalizedRGBA {
    public float red, green, blue, alpha;

    public int toColor() {
        int r = Math.min(255, (int) (red * 255)), g = Math.min(255, (int) (green * 255)), b = Math.min(255, (int) (blue * 255));
        int a = Math.min(255, (int) (alpha * 255));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
