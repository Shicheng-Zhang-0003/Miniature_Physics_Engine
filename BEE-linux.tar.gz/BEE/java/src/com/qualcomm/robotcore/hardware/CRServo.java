package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: servo cu rotație continuă (putere -1..1). */
public interface CRServo extends DcMotorSimple {
    ServoController getController();
    int getPortNumber();
}
