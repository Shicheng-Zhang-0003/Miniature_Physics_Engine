package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: o lumină care se poate stinge (ex. LED-ul unor senzori de culoare). */
public interface SwitchableLight extends Light {
    void enableLight(boolean enable);
}
