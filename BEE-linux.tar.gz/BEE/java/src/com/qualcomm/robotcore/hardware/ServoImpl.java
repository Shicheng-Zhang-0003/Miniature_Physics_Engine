package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: clasa servo-urilor din hardwareMap (în simulator: org.ftcsim.SimServo). */
public abstract class ServoImpl implements Servo {
}
