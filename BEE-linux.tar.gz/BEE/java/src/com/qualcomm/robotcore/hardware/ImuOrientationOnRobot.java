package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: cum e montat IMU-ul pe robot. */
public interface ImuOrientationOnRobot {}
