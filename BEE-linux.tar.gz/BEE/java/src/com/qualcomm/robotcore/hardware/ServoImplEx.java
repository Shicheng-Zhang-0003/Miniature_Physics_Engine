package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: un servo cu control PWM — ((ServoImplEx) servo).setPwmRange(new PwmControl.PwmRange(500, 2500)). */
public abstract class ServoImplEx extends ServoImpl implements PwmControl {
    protected PwmRange pwmRange = PwmRange.defaultRange;

    @Override public void setPwmRange(PwmRange range) { pwmRange = range; }
    @Override public PwmRange getPwmRange() { return pwmRange; }
}
