package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: hardwareMap.get(ColorRangeSensor.class, ...) pe un senzor REV Color V3. */
public interface ColorRangeSensor extends ColorSensor, NormalizedColorSensor, DistanceSensor, OpticalDistanceSensor, LightSensor {}
