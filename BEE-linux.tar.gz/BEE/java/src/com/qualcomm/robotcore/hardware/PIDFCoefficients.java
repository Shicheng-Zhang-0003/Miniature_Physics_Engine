package com.qualcomm.robotcore.hardware;

import java.util.Locale;

/** Ca în SDK-ul FTC (ex. regulatorul de viteză al unui flywheel: setPIDFCoefficients(RUN_USING_ENCODER, ...)). */
public class PIDFCoefficients {
    public double p, i, d, f;
    public MotorControlAlgorithm algorithm = MotorControlAlgorithm.PIDF;

    public PIDFCoefficients() {}
    public PIDFCoefficients(double p, double i, double d, double f, MotorControlAlgorithm algorithm) {
        this.p = p; this.i = i; this.d = d; this.f = f; this.algorithm = algorithm;
    }
    public PIDFCoefficients(double p, double i, double d, double f) { this(p, i, d, f, MotorControlAlgorithm.PIDF); }
    public PIDFCoefficients(PIDFCoefficients other) { this(other.p, other.i, other.d, other.f, other.algorithm); }
    public PIDFCoefficients(PIDCoefficients other) { this(other.p, other.i, other.d, 0, MotorControlAlgorithm.LegacyPID); }

    @Override public String toString() {
        return String.format(Locale.ROOT, "%s(p=%f i=%f d=%f f=%f alg=%s)", getClass().getSimpleName(), p, i, d, f, algorithm);
    }
}
