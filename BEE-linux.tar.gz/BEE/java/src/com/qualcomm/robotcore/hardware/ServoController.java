package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: servo.getController().pwmDisable() lasă servo-urile libere. */
public interface ServoController extends HardwareDevice {
    enum PwmStatus { ENABLED, DISABLED, MIXED }

    void pwmEnable();
    void pwmDisable();
    PwmStatus getPwmStatus();
    void setServoPosition(int servo, double position);
    double getServoPosition(int servo);
}
