package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC. */
public interface OpticalDistanceSensor extends LightSensor {}
