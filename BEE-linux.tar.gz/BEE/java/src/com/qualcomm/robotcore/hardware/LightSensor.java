package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC. */
public interface LightSensor extends HardwareDevice {
    double getLightDetected();
    double getRawLightDetected();
    double getRawLightDetectedMax();
    void enableLed(boolean enable);
    String status();
}
