package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC. */
public interface NormalizedColorSensor extends HardwareDevice {
    NormalizedRGBA getNormalizedColors();
    float getGain();
    void setGain(float newGain);
}
