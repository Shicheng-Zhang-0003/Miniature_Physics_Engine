package com.qualcomm.robotcore.hardware;

import org.firstinspires.ftc.robotcore.external.navigation.*;

/** Ca în SDK-ul FTC (subset). */
public interface IMU extends HardwareDevice {
    class Parameters {
        public ImuOrientationOnRobot imuOrientationOnRobot;

        public Parameters(ImuOrientationOnRobot imuOrientationOnRobot) {
            this.imuOrientationOnRobot = imuOrientationOnRobot;
        }

        public Parameters copy() { return new Parameters(imuOrientationOnRobot); }
    }

    boolean initialize(Parameters parameters);
    void resetYaw();
    YawPitchRollAngles getRobotYawPitchRollAngles();
    AngularVelocity getRobotAngularVelocity(AngleUnit angleUnit);
    Orientation getRobotOrientation(AxesReference reference, AxesOrder order, AngleUnit angleUnit);
    Quaternion getRobotOrientationAsQuaternion();
}
