package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: tensiunea bateriei. */
public interface VoltageSensor extends HardwareDevice {
    double getVoltage();
}
