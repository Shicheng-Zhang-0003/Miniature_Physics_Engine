package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC. */
public interface TouchSensor extends HardwareDevice {
    double getValue();
    boolean isPressed();
}
