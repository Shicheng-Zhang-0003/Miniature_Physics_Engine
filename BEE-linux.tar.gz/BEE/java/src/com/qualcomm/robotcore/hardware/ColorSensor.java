package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: valori brute 0..~1000. */
public interface ColorSensor extends HardwareDevice {
    int red();
    int green();
    int blue();
    int alpha();
    int argb();
    void enableLed(boolean enable);
    default void setI2cAddress(Object address) {}
}
