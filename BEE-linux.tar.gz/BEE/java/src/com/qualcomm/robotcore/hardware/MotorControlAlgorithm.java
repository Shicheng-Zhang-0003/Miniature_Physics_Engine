package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC. */
public enum MotorControlAlgorithm { Unknown, LegacyPID, PIDF }
