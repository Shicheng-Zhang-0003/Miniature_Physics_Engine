package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC. Un buton REV pe port digital dă getState() == false când e APĂSAT. */
public interface DigitalChannel extends HardwareDevice {
    enum Mode { INPUT, OUTPUT }

    Mode getMode();
    void setMode(Mode mode);
    boolean getState();
    void setState(boolean state);
}
