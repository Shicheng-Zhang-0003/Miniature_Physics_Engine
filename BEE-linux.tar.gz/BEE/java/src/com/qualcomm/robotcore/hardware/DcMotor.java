package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;

/** Ca în SDK-ul FTC. RUN_TO_POSITION și RUN_USING_ENCODER sunt simulate ca pe Control Hub. */
public interface DcMotor extends DcMotorSimple {
    enum RunMode {
        RUN_WITHOUT_ENCODER, RUN_USING_ENCODER, RUN_TO_POSITION, STOP_AND_RESET_ENCODER,
        /** @deprecated ca în SDK: folosește RUN_WITHOUT_ENCODER */ @Deprecated RUN_WITHOUT_ENCODERS,
        /** @deprecated ca în SDK: folosește RUN_USING_ENCODER */ @Deprecated RUN_USING_ENCODERS,
        /** @deprecated ca în SDK: folosește STOP_AND_RESET_ENCODER */ @Deprecated RESET_ENCODERS;

        /** Ca în SDK: numele vechi devin cele noi. */
        public RunMode migrate() {
            switch (this) {
                case RUN_WITHOUT_ENCODERS: return RUN_WITHOUT_ENCODER;
                case RUN_USING_ENCODERS: return RUN_USING_ENCODER;
                case RESET_ENCODERS: return STOP_AND_RESET_ENCODER;
                default: return this;
            }
        }

        public boolean isPIDMode() { return this == RUN_USING_ENCODER || this == RUN_USING_ENCODERS || this == RUN_TO_POSITION; }
    }
    enum ZeroPowerBehavior { UNKNOWN, BRAKE, FLOAT }

    MotorConfigurationType getMotorType();
    void setMotorType(MotorConfigurationType motorType);
    DcMotorController getController();
    int getPortNumber();
    void setZeroPowerBehavior(ZeroPowerBehavior zeroPowerBehavior);
    ZeroPowerBehavior getZeroPowerBehavior();
    /** @deprecated ca în SDK: folosește setZeroPowerBehavior(FLOAT) + setPower(0) */
    @Deprecated void setPowerFloat();
    boolean getPowerFloat();
    void setTargetPosition(int position);
    int getTargetPosition();
    boolean isBusy();
    int getCurrentPosition();
    void setMode(RunMode mode);
    RunMode getMode();
}
