package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC (subset). */
public interface HardwareDevice {
    enum Manufacturer { Unknown, Other, Lynx, ModernRobotics, Adafruit, Matrix, Lego, HiTechnic, Broadcom, AMS, STMicroelectronics, DFRobot, LimelightVision }

    default Manufacturer getManufacturer() { return Manufacturer.Other; }
    default String getDeviceName() { return "Simulated device"; }
    default String getConnectionInfo() { return "ftc-sim"; }
    default int getVersion() { return 1; }
    default void resetDeviceConfigurationForOpMode() {}
    default void close() {}
}
