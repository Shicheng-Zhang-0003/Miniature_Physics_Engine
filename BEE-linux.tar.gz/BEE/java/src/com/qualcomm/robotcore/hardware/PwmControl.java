package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: intervalul impulsului PWM al unui servo (ex. Axon: 500..2500 µs) și pornirea / oprirea semnalului. */
public interface PwmControl {
    void setPwmRange(PwmRange range);
    PwmRange getPwmRange();
    void setPwmEnable();
    void setPwmDisable();
    boolean isPwmEnabled();

    class PwmRange {
        public static final double usFrameDefault = 20000.0;
        public static final double usPulseUpperDefault = 2400.0;
        public static final double usPulseLowerDefault = 600.0;
        public static final PwmRange defaultRange = new PwmRange(usPulseLowerDefault, usPulseUpperDefault);

        public final double usPulseLower;
        public final double usPulseUpper;
        public final double usFrame;

        public PwmRange(double usPulseLower, double usPulseUpper) { this(usPulseLower, usPulseUpper, usFrameDefault); }

        public PwmRange(double usPulseLower, double usPulseUpper, double usFrame) {
            this.usPulseLower = usPulseLower;
            this.usPulseUpper = usPulseUpper;
            this.usFrame = usFrame;
        }

        @Override public boolean equals(Object o) {
            if (!(o instanceof PwmRange)) return false;
            PwmRange r = (PwmRange) o;
            return usPulseLower == r.usPulseLower && usPulseUpper == r.usPulseUpper && usFrame == r.usFrame;
        }

        @Override public int hashCode() { return Double.hashCode(usPulseLower) * 31 * 31 + Double.hashCode(usPulseUpper) * 31 + Double.hashCode(usFrame); }
    }
}
