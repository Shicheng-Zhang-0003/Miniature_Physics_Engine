package com.qualcomm.robotcore.hardware;

/** Ca în SDK-ul FTC: un LED pe un port digital (ex. LED-urile REV). În simulator doar își ține starea. */
public class LED implements HardwareDevice, SwitchableLight {
    private final String name;
    private boolean on = false;

    public LED(String name) { this.name = name; }

    public void enable(boolean set) { on = set; }
    public void on() { on = true; }
    public void off() { on = false; }
    @Override public boolean isLightOn() { return on; }
    @Override public void enableLight(boolean enable) { on = enable; }
    @Override public String getDeviceName() { return "LED (" + name + ")"; }
}
