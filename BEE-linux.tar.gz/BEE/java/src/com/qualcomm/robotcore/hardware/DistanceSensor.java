package com.qualcomm.robotcore.hardware;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

/** Ca în SDK-ul FTC. */
public interface DistanceSensor extends HardwareDevice {
    double distanceOutOfRange = 8190.0 / 25.4;  // inch, ca senzorul REV fără țintă
    double getDistance(DistanceUnit unit);
}
