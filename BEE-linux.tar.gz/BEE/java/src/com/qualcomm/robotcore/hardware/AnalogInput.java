package com.qualcomm.robotcore.hardware;

/** Ca în SDK: o intrare analogică (0..3.3 V). În simulator citește 0 dacă nu e simulată. */
public class AnalogInput implements HardwareDevice {
    private final String name;
    private volatile double voltage = 0;

    public AnalogInput(String name) { this.name = name; }
    public double getVoltage() { return voltage; }
    public double getMaxVoltage() { return 3.3; }
    public void simSetVoltage(double v) { voltage = v; }
    @Override public Manufacturer getManufacturer() { return Manufacturer.Other; }
    @Override public String getDeviceName() { return "Analog Input (" + name + ")"; }
}
