package com.qualcomm.robotcore.util;

/** Ca în SDK-ul FTC. */
public final class Range {
    private Range() {}
    public static double clip(double number, double min, double max) { return Math.max(min, Math.min(max, number)); }
    public static float clip(float number, float min, float max) { return Math.max(min, Math.min(max, number)); }
    public static int clip(int number, int min, int max) { return Math.max(min, Math.min(max, number)); }
    public static short clip(short number, short min, short max) { return (short) Math.max(min, Math.min(max, number)); }
    public static byte clip(byte number, byte min, byte max) { return (byte) Math.max(min, Math.min(max, number)); }
    public static double scale(double n, double x1, double x2, double y1, double y2) {
        return y1 + (n - x1) * (y2 - y1) / (x2 - x1);
    }
    public static void throwIfRangeIsInvalid(int number, int min, int max) {
        if (number < min || number > max) throw new IllegalArgumentException("number " + number + " is invalid; valid range is " + min + ".." + max);
    }
    public static void throwIfRangeIsInvalid(double number, double min, double max) {
        if (number < min || number > max) throw new IllegalArgumentException("number " + number + " is invalid; valid range is " + min + ".." + max);
    }
}
