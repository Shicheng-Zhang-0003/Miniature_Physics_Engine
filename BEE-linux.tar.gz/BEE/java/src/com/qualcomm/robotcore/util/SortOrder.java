package com.qualcomm.robotcore.util;

/** Ca în SDK-ul FTC. */
public enum SortOrder { ASCENDING, DESCENDING }
