package com.qualcomm.robotcore.util;

import java.util.concurrent.TimeUnit;

/** Ca în SDK-ul FTC: cronometru. */
public class ElapsedTime {
    public enum Resolution { SECONDS, MILLISECONDS }

    public static final long SECOND_IN_NANO = 1000000000L;
    public static final long MILLIS_IN_NANO = 1000000L;
    private long start;
    private final Resolution resolution;

    public ElapsedTime() { this(Resolution.SECONDS); }
    public ElapsedTime(Resolution r) { resolution = r; reset(); }
    public ElapsedTime(long startNanos) { resolution = Resolution.SECONDS; start = startNanos; }

    public void reset() { start = org.ftcsim.SimClock.nanoTime(); }
    public double startTime() { return start / 1e9; }
    public long startTimeNanoseconds() { return start; }
    public long nanoseconds() { return org.ftcsim.SimClock.nanoTime() - start; }
    public double seconds() { return nanoseconds() / 1e9; }
    public double milliseconds() { return nanoseconds() / 1e6; }
    public double time() { return resolution == Resolution.SECONDS ? seconds() : milliseconds(); }
    public long time(TimeUnit unit) { return unit.convert(nanoseconds(), TimeUnit.NANOSECONDS); }
    public long now(TimeUnit unit) { return unit.convert(org.ftcsim.SimClock.nanoTime(), TimeUnit.NANOSECONDS); }
    public Resolution getResolution() { return resolution; }
    /** Ca în SDK: scrie timpul în jurnal (aici, în terminal / last_run.log). */
    public void log(String label) { System.out.println(String.format(java.util.Locale.ROOT, "timer: %s %s", label, this)); }
    @Override public String toString() { return String.format(java.util.Locale.ROOT, "%.4f seconds", seconds()); }
}
