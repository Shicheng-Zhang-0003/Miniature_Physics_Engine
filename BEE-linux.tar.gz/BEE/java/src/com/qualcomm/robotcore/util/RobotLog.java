package com.qualcomm.robotcore.util;

import java.util.Locale;

/**
 * Ca în SDK-ul FTC: jurnalul robotului (logcat pe Control Hub). În simulator merge în jurnalul rulării
 * (user://last_run.log), cu nivelul și tag-ul, ca să-l vezi după Test in sim.
 *   v / d / i / w / e (mesaj, args...)   vv / dd / ii / ww / ee (tag, [Throwable,] mesaj, args...)
 */
public class RobotLog {
    public static final String TAG = "RobotCore";
    public static final String OPMODE_START_TAG = "******************** START - OPMODE %s ********************";
    public static final String OPMODE_STOP_TAG = "******************** STOP - OPMODE %s ********************";
    private static String globalError = "";

    private RobotLog() {}

    private static String fmt(String msg, Object... args) {
        return args == null || args.length == 0 ? msg : String.format(Locale.ROOT, msg, args);
    }

    private static void log(String level, String tag, Throwable t, String msg) {
        System.out.println(level + "/" + tag + ": " + msg);
        if (t != null) t.printStackTrace(System.out);
    }

    public static void a(String msg, Object... args) { log("A", TAG, null, fmt(msg, args)); }
    public static void a(String msg) { log("A", TAG, null, msg); }
    public static void aa(String tag, String msg, Object... args) { log("A", tag, null, fmt(msg, args)); }
    public static void aa(String tag, String msg) { log("A", tag, null, msg); }
    public static void aa(String tag, Throwable t, String msg, Object... args) { log("A", tag, t, fmt(msg, args)); }
    public static void aa(String tag, Throwable t, String msg) { log("A", tag, t, msg); }
    public static void v(String msg, Object... args) { log("V", TAG, null, fmt(msg, args)); }
    public static void v(String msg) { log("V", TAG, null, msg); }
    public static void vv(String tag, String msg, Object... args) { log("V", tag, null, fmt(msg, args)); }
    public static void vv(String tag, String msg) { log("V", tag, null, msg); }
    public static void vv(String tag, Throwable t, String msg, Object... args) { log("V", tag, t, fmt(msg, args)); }
    public static void vv(String tag, Throwable t, String msg) { log("V", tag, t, msg); }
    public static void d(String msg, Object... args) { log("D", TAG, null, fmt(msg, args)); }
    public static void d(String msg) { log("D", TAG, null, msg); }
    public static void dd(String tag, String msg, Object... args) { log("D", tag, null, fmt(msg, args)); }
    public static void dd(String tag, String msg) { log("D", tag, null, msg); }
    public static void dd(String tag, Throwable t, String msg, Object... args) { log("D", tag, t, fmt(msg, args)); }
    public static void dd(String tag, Throwable t, String msg) { log("D", tag, t, msg); }
    public static void i(String msg, Object... args) { log("I", TAG, null, fmt(msg, args)); }
    public static void i(String msg) { log("I", TAG, null, msg); }
    public static void ii(String tag, String msg, Object... args) { log("I", tag, null, fmt(msg, args)); }
    public static void ii(String tag, String msg) { log("I", tag, null, msg); }
    public static void ii(String tag, Throwable t, String msg, Object... args) { log("I", tag, t, fmt(msg, args)); }
    public static void ii(String tag, Throwable t, String msg) { log("I", tag, t, msg); }
    public static void w(String msg, Object... args) { log("W", TAG, null, fmt(msg, args)); }
    public static void w(String msg) { log("W", TAG, null, msg); }
    public static void ww(String tag, String msg, Object... args) { log("W", tag, null, fmt(msg, args)); }
    public static void ww(String tag, String msg) { log("W", tag, null, msg); }
    public static void ww(String tag, Throwable t, String msg, Object... args) { log("W", tag, t, fmt(msg, args)); }
    public static void ww(String tag, Throwable t, String msg) { log("W", tag, t, msg); }
    public static void e(String msg, Object... args) { log("E", TAG, null, fmt(msg, args)); }
    public static void e(String msg) { log("E", TAG, null, msg); }
    public static void ee(String tag, String msg, Object... args) { log("E", tag, null, fmt(msg, args)); }
    public static void ee(String tag, String msg) { log("E", tag, null, msg); }
    public static void ee(String tag, Throwable t, String msg, Object... args) { log("E", tag, t, fmt(msg, args)); }
    public static void ee(String tag, Throwable t, String msg) { log("E", tag, t, msg); }
    public static void logStacktrace(Throwable t) { log("E", TAG, t, "stack trace"); }
    public static void logStackTrace(Throwable t) { log("E", TAG, t, "stack trace"); }
    public static void logStackTrace(String tag, Throwable t) { log("E", tag, t, "stack trace"); }
    public static void logExceptionHeader(Exception e, String msg, Object... args) { log("E", TAG, null, "exception " + e + ": " + fmt(msg, args)); }
    public static void logExceptionHeader(String tag, Exception e, String msg, Object... args) { log("E", tag, null, "exception " + e + ": " + fmt(msg, args)); }

    /** Ca pe Driver Station: mesajul de eroare global (aici, în jurnal). */
    public static boolean setGlobalErrorMsg(String msg) {
        boolean first = globalError.isEmpty();
        if (first) {
            globalError = msg;
            log("E", TAG, null, "global error: " + msg);
        }
        return first;
    }
    public static void setGlobalErrorMsg(String fmt, Object... args) { setGlobalErrorMsg(fmt(fmt, args)); }
    public static String getGlobalErrorMsg() { return globalError; }
    public static void clearGlobalErrorMsg() { globalError = ""; }
    public static void addGlobalWarningMessage(String msg) { log("W", TAG, null, "warning: " + msg); }
    public static void addGlobalWarningMessage(String fmt, Object... args) { addGlobalWarningMessage(fmt(fmt, args)); }
    public static void clearGlobalWarningMsg() {}
}
