package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import java.util.HashMap;
import org.firstinspires.ftc.robotcore.external.Telemetry;

/** Ca în SDK-ul FTC: OpMode iterativ (init, init_loop, start, loop, stop). */
public abstract class OpMode {
    /** Ca în SDK 10+: date care rămân între OpMode-uri (ex. poziția de la finalul autonomiei, pentru TeleOp). */
    public static final HashMap<String, Object> blackboard = new HashMap<>();

    public HardwareMap hardwareMap;
    public Telemetry telemetry;
    public Gamepad gamepad1 = new Gamepad();
    public Gamepad gamepad2 = new Gamepad();
    public volatile double time = 0;
    // ca în SDK (simulatorul nu oprește un OpMode blocat, dar codul care le setează trebuie să compileze)
    public int msStuckDetectInit = 5000;
    public int msStuckDetectInitLoop = 5000;
    public int msStuckDetectStart = 5000;
    public int msStuckDetectLoop = 5000;
    public int msStuckDetectStop = 900;
    private long startNanos = org.ftcsim.SimClock.nanoTime();
    protected volatile boolean stopRequested = false;

    /** Aruncată de terminateOpModeNow(): oprește OpMode-ul pe loc, ca STOP de pe Driver Station. */
    public static final class ForceStopException extends RuntimeException {
        public ForceStopException() { super("terminateOpModeNow()"); }
    }

    public abstract void init();
    public void init_loop() {}
    public void start() {}
    public abstract void loop();
    public void stop() {}

    /** Ca în SDK: secundele de la INIT (Control Hub-ul îl resetează doar înainte de init()). */
    public double getRuntime() {
        return (org.ftcsim.SimClock.nanoTime() - startNanos) / 1e9;
    }

    public void resetRuntime() {
        startNanos = org.ftcsim.SimClock.nanoTime();
    }

    public final void requestOpModeStop() {
        stopRequested = true;
    }

    /** Ca în SDK: nu mai rulează nimic din OpMode după apel. */
    public final void terminateOpModeNow() {
        stopRequested = true;
        throw new ForceStopException();
    }

    public void updateTelemetry(Telemetry telemetry) {
        telemetry.update();
    }
}
