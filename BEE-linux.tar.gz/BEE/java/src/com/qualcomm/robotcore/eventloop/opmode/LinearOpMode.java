package com.qualcomm.robotcore.eventloop.opmode;

/** Ca în SDK-ul FTC. waitForStart() așteaptă START de la simulator (ceasul meciului). */
public abstract class LinearOpMode extends OpMode {
    private volatile boolean started = false;
    private long deadlineMs = Long.MAX_VALUE;

    public abstract void runOpMode() throws InterruptedException;

    @Override public final void init() {}
    @Override public final void loop() {}

    public void waitForStart() {
        org.ftcsim.SimSignals.awaitStart();
        started = true;
        // ca în SDK: getRuntime() NU se resetează la START (doar la INIT) — codul care vrea timpul de la START
        // apelează resetRuntime() după waitForStart(), cum face codul generat de BEE
        if (getClass().isAnnotationPresent(Autonomous.class)) {
            deadlineMs = org.ftcsim.SimClock.millis() + 30_000;  // AUTO durează 30 s
        }
    }

    // ca în SDK: activ de la START, chiar fără waitForStart() (exemplele de culoare buclează cu opModeIsActive() || opModeInInit())
    public final boolean opModeIsActive() {
        boolean active = isStarted() && !isStopRequested();
        if (active) Thread.yield();
        return active;
    }

    public final boolean opModeInInit() {
        return !started && !isStopRequested() && !org.ftcsim.SimSignals.isStarted();
    }

    public final boolean isStarted() {
        return started || org.ftcsim.SimSignals.isStarted();
    }

    public final boolean isStopRequested() {
        return stopRequested || org.ftcsim.SimSignals.isStopped()
                || org.ftcsim.SimClock.millis() > deadlineMs || Thread.currentThread().isInterrupted();
    }

    public final void sleep(long milliseconds) {
        try {
            org.ftcsim.SimClock.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public final void idle() {
        Thread.yield();
    }
}
