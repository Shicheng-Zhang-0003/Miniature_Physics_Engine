package com.qualcomm.robotcore.exception;

/** Ca pe Control Hub: setMode(RUN_TO_POSITION) înainte de setTargetPosition(). */
public class TargetPositionNotSetException extends RuntimeException {
    public TargetPositionNotSetException() {
        super("Failed to set to mode RUN_TO_POSITION. Call setTargetPosition() before switching to RUN_TO_POSITION.");
    }
}
