package com.qualcomm.hardware.limelightvision;

import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;

/** Ca în SDK-ul FTC: starea camerei (valori tipice pentru o Limelight 3A). */
public class LLStatus {
    public LLStatus() {}
    public Quaternion getCameraQuat() { return Quaternion.identityQuaternion(); }
    public int getCid() { return 0; }
    public double getCpu() { return 35; }
    public double getFinalYaw() { return 0; }
    public double getFps() { return 90; }
    public int getHwType() { return 0; }
    public String getName() { return "limelight"; }
    public int getPipeImgCount() { return 0; }
    public int getPipelineIndex() { return 0; }
    public String getPipelineType() { return "pipe_fiducial"; }
    public double getRam() { return 40; }
    public int getSnapshotMode() { return 0; }
    public double getTemp() { return 40; }
    @Override public String toString() { return "LLStatus{fps=90.0, temp=40.0, cpu=35.0, ram=40.0}"; }
}
