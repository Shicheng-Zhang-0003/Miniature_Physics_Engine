package com.qualcomm.hardware.limelightvision;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

/** Ca în SDK-ul FTC. Simulatorul umple tag-urile (FiducialResult) și piesele (DetectorResult); restul vin goale. */
public class LLResultTypes {
    /** Cele 4 colțuri ale țintei (pixeli), dintr-un dreptunghi în jurul centrului. */
    static List<List<Double>> corners(double cx, double cy, double area) {
        double half = Math.sqrt(Math.max(0, area) / 100.0 * 640 * 480) / 2;
        List<List<Double>> out = new ArrayList<>();
        double[][] c = {{cx - half, cy - half}, {cx + half, cy - half}, {cx + half, cy + half}, {cx - half, cy + half}};
        for (double[] p : c) {
            List<Double> pt = new ArrayList<>();
            pt.add(p[0]);
            pt.add(p[1]);
            out.add(pt);
        }
        return out;
    }
    static double px(double tx) { return 320 + tx / 27.25 * 320; }
    static double py(double ty) { return 240 - ty / 21.0 * 240; }

    public static class FiducialResult {
        private final int id;
        private final double tx, ty, ta;
        private final Pose3D robotField, targetCamera;

        public FiducialResult(int id, double tx, double ty, double ta, Pose3D robotField, Pose3D targetCamera) {
            this.id = id; this.tx = tx; this.ty = ty; this.ta = ta; this.robotField = robotField; this.targetCamera = targetCamera;
        }
        public int getFiducialId() { return id; }
        public String getFamily() { return "36H11C"; }
        public double getTargetXDegrees() { return tx; }
        public double getTargetYDegrees() { return ty; }
        public double getTargetXDegreesNoCrosshair() { return tx; }
        public double getTargetYDegreesNoCrosshair() { return ty; }
        public double getTargetArea() { return ta; }
        public Pose3D getRobotPoseFieldSpace() { return robotField; }
        /** Tag-ul față de cameră (metri): x dreapta, y jos, z înainte, ca la Limelight. */
        public Pose3D getTargetPoseCameraSpace() { return targetCamera; }
        public Pose3D getCameraPoseTargetSpace() { return targetCamera; }
        public Pose3D getRobotPoseTargetSpace() { return targetCamera; }
        public Pose3D getTargetPoseRobotSpace() { return targetCamera; }
        public double getSkew() { return 0; }
        public double getTargetXPixels() { return px(tx); }
        public double getTargetYPixels() { return py(ty); }
        public List<List<Double>> getTargetCorners() { return corners(px(tx), py(ty), ta); }
    }

    /** Un obiect găsit de un pipeline de detecție (rețea neurală), ca la Limelight 3A: clasa, unghiurile, aria. */
    public static class DetectorResult {
        private final String className;
        private final int classId;
        private final double confidence, tx, ty, ta;

        public DetectorResult(String className, int classId, double confidence, double tx, double ty, double ta) {
            this.className = className; this.classId = classId; this.confidence = confidence; this.tx = tx; this.ty = ty; this.ta = ta;
        }
        public String getClassName() { return className; }
        public int getClassId() { return classId; }
        public double getConfidence() { return confidence; }
        /** Unghiul orizontal (grade) față de centrul imaginii: + = obiectul e în dreapta. */
        public double getTargetXDegrees() { return tx; }
        /** Unghiul vertical (grade): + = mai sus în imagine (la obiectele de pe podea: mai departe). */
        public double getTargetYDegrees() { return ty; }
        public double getTargetXDegreesNoCrosshair() { return tx; }
        public double getTargetYDegreesNoCrosshair() { return ty; }
        /** Cât din imagine ocupă (procente): mai mare = mai aproape. */
        public double getTargetArea() { return ta; }
        public double getTargetXPixels() { return px(tx); }
        public double getTargetYPixels() { return py(ty); }
        public List<List<Double>> getTargetCorners() { return corners(px(tx), py(ty), ta); }
    }

    /** Un pipeline de culoare (ca la Limelight); simulatorul nu are, dar codul trebuie să compileze. */
    public static class ColorResult {
        private final double tx, ty, ta;
        public ColorResult(double tx, double ty, double ta) { this.tx = tx; this.ty = ty; this.ta = ta; }
        public List<List<Double>> getTargetCorners() { return corners(px(tx), py(ty), ta); }
        public Pose3D getCameraPoseTargetSpace() { return null; }
        public Pose3D getRobotPoseFieldSpace() { return null; }
        public Pose3D getRobotPoseTargetSpace() { return null; }
        public Pose3D getTargetPoseCameraSpace() { return null; }
        public Pose3D getTargetPoseRobotSpace() { return null; }
        public double getTargetArea() { return ta; }
        public double getTargetXPixels() { return px(tx); }
        public double getTargetYPixels() { return py(ty); }
        public double getTargetXDegrees() { return tx; }
        public double getTargetYDegrees() { return ty; }
        public double getTargetXDegreesNoCrosshair() { return tx; }
        public double getTargetYDegreesNoCrosshair() { return ty; }
    }

    public static class BarcodeResult {
        private final String family, data;
        private final double tx, ty, ta;
        public BarcodeResult(String family, String data, double tx, double ty, double ta) { this.family = family; this.data = data; this.tx = tx; this.ty = ty; this.ta = ta; }
        public String getFamily() { return family; }
        public String getData() { return data; }
        public double getTargetXPixels() { return px(tx); }
        public double getTargetYPixels() { return py(ty); }
        public double getTargetXDegrees() { return tx; }
        public double getTargetYDegrees() { return ty; }
        public double getTargetXDegreesNoCrosshair() { return tx; }
        public double getTargetYDegreesNoCrosshair() { return ty; }
        public double getTargetArea() { return ta; }
        public List<List<Double>> getTargetCorners() { return corners(px(tx), py(ty), ta); }
    }

    public static class ClassifierResult {
        private final String className;
        private final int classId;
        private final double confidence;
        public ClassifierResult(String className, int classId, double confidence) { this.className = className; this.classId = classId; this.confidence = confidence; }
        public String getClassName() { return className; }
        public int getClassId() { return classId; }
        public double getConfidence() { return confidence; }
    }

    public static class CalibrationResult {
        public int getResX() { return 640; }
        public int getResY() { return 480; }
        public double[] getCamMatrix() { return new double[] {600, 0, 320, 0, 600, 240, 0, 0, 1}; }
        public double[] getDistortionCoefficients() { return new double[5]; }
        public double getReprojectionError() { return 0.2; }
        public boolean isValid() { return true; }
        @Override public String toString() { return "CalibrationResult(simulated 640x480)"; }
    }

    static <T> List<T> none() { return Collections.emptyList(); }
}
