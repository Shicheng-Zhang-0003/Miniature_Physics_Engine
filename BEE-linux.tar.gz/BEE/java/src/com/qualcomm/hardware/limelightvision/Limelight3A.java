package com.qualcomm.hardware.limelightvision;

import com.qualcomm.robotcore.hardware.HardwareDevice;

/** Ca în SDK-ul FTC: Limelight 3A (simulată de org.ftcsim.SimLimelight). */
public abstract class Limelight3A implements HardwareDevice {
    private long lastUpdateMs = System.currentTimeMillis();

    public abstract void start();
    public abstract void pause();
    public abstract void stop();
    public abstract boolean isRunning();
    public abstract boolean isConnected();
    public abstract boolean pipelineSwitch(int index);
    public abstract LLResult getLatestResult();

    public void setPollRateHz(int rateHz) {}
    public long getTimeSinceLastUpdate() { return System.currentTimeMillis() - lastUpdateMs; }
    protected void noteUpdate() { lastUpdateMs = System.currentTimeMillis(); }
    public LLStatus getStatus() { return new LLStatus(); }
    public boolean reloadPipeline() { return true; }
    public boolean captureSnapshot(String snapname) { return true; }
    public boolean deleteSnapshots() { return true; }
    public boolean deleteSnapshot(String snapname) { return true; }
    public boolean updatePythonInputs(double d1, double d2, double d3, double d4, double d5, double d6, double d7, double d8) { return true; }
    public boolean updatePythonInputs(double[] inputs) { return inputs != null && inputs.length <= 32; }
    public boolean updateRobotOrientation(double yaw) { return true; }
    public boolean uploadPipeline(String jsonString, Integer index) { return true; }
    public boolean uploadPython(String pythonString, Integer index) { return true; }
    public LLResultTypes.CalibrationResult getCalDefault() { return new LLResultTypes.CalibrationResult(); }
    public LLResultTypes.CalibrationResult getCalFile() { return new LLResultTypes.CalibrationResult(); }
    public LLResultTypes.CalibrationResult getCalEEPROM() { return new LLResultTypes.CalibrationResult(); }
    public LLResultTypes.CalibrationResult getCalLatest() { return new LLResultTypes.CalibrationResult(); }
    public void shutdown() { stop(); }
    @Override public Manufacturer getManufacturer() { return Manufacturer.LimelightVision; }
    @Override public String getDeviceName() { return "Limelight 3A"; }
}
