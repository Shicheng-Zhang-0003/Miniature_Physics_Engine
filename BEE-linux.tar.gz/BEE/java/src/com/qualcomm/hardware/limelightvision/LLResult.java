package com.qualcomm.hardware.limelightvision;

import java.util.Collections;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

/** Ca în SDK-ul FTC (subset): rezultatul unui cadru Limelight. */
public class LLResult {
    private final boolean valid;
    private final double tx, ty, ta;
    private final Pose3D botpose;
    private final List<LLResultTypes.FiducialResult> fiducials;
    private final long timestampMs;
    private final int pipeline;
    private final List<LLResultTypes.DetectorResult> detectors;

    public LLResult(boolean valid, double tx, double ty, double ta, Pose3D botpose,
                    List<LLResultTypes.FiducialResult> fiducials, long timestampMs, int pipeline) {
        this(valid, tx, ty, ta, botpose, fiducials, Collections.<LLResultTypes.DetectorResult>emptyList(), timestampMs, pipeline);
    }

    public LLResult(boolean valid, double tx, double ty, double ta, Pose3D botpose, List<LLResultTypes.FiducialResult> fiducials,
                    List<LLResultTypes.DetectorResult> detectors, long timestampMs, int pipeline) {
        this.valid = valid; this.tx = tx; this.ty = ty; this.ta = ta; this.botpose = botpose;
        this.fiducials = fiducials; this.detectors = detectors; this.timestampMs = timestampMs; this.pipeline = pipeline;
    }
    public boolean isValid() { return valid; }
    public double getTx() { return tx; }
    public double getTy() { return ty; }
    public double getTa() { return ta; }
    public double getTxNC() { return tx; }
    public double getTyNC() { return ty; }
    public Pose3D getBotpose() { return botpose; }
    public Pose3D getBotpose_MT2() { return botpose; }
    public int getBotposeTagCount() { return fiducials.size(); }
    public double getBotposeAvgDist() { return 0; }
    public List<LLResultTypes.FiducialResult> getFiducialResults() { return fiducials; }
    public List<LLResultTypes.ColorResult> getColorResults() { return LLResultTypes.<LLResultTypes.ColorResult>none(); }
    public List<LLResultTypes.BarcodeResult> getBarcodeResults() { return LLResultTypes.<LLResultTypes.BarcodeResult>none(); }
    public List<LLResultTypes.ClassifierResult> getClassifierResults() { return LLResultTypes.<LLResultTypes.ClassifierResult>none(); }
    public List<LLResultTypes.DetectorResult> getDetectorResults() { return detectors; }
    public long getStaleness() { return System.currentTimeMillis() - timestampMs; }
    public double getCaptureLatency() { return 12; }
    public double getTargetingLatency() { return 8; }
    public int getPipelineIndex() { return pipeline; }
    public long getControlHubTimeStamp() { return timestampMs; }
    public long getControlHubTimeStampNanos() { return timestampMs * 1_000_000L; }
    public double getTimestamp() { return timestampMs; }
    public double getParseLatency() { return 0.5; }
    public double getFocusMetric() { return 0; }
    public double[] getStddevMt1() { return new double[6]; }
    public double[] getStddevMt2() { return new double[6]; }
    public double getBotposeSpan() { return 0; }
    public double getBotposeAvgArea() { return fiducials.isEmpty() ? 0 : ta; }
    public double[] getPythonOutput() { return new double[8]; }
    public String getPipelineType() { return detectors.isEmpty() ? "pipe_fiducial" : "pipe_neuraldetector"; }
    @Override public String toString() {
        return String.format(java.util.Locale.ROOT, "LLResult{valid=%s, tx=%.2f, ty=%.2f, ta=%.2f, tags=%d, detections=%d}", valid, tx, ty, ta, fiducials.size(), detectors.size());
    }
}
