package com.qualcomm.hardware.gobilda;

import com.qualcomm.robotcore.hardware.HardwareDevice;
import java.util.function.Supplier;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;

/**
 * goBILDA Pinpoint (ca în SDK-ul FTC 10.2+), simulat: poziția vine direct din simulator,
 * fără zgomot (ca două roți de odometrie bine montate). Coordonatele: X = înainte, Y = stânga,
 * heading pozitiv = rotire spre stânga, toate față de locul în care s-a apelat resetPosAndIMU().
 */
public class GoBildaPinpointDriver implements HardwareDevice {
    public enum GoBildaOdometryPods { goBILDA_SWINGARM_POD, goBILDA_4_BAR_POD }
    public enum EncoderDirection { FORWARD, REVERSED }
    public enum DeviceStatus { NOT_READY, READY, CALIBRATING, FAULT_X_POD_NOT_DETECTED, FAULT_Y_POD_NOT_DETECTED, FAULT_NO_PODS_DETECTED, FAULT_IMU_RUNAWAY, FAULT_BAD_READ }
    public enum ReadData { ONLY_UPDATE_HEADING }

    /** {x_in, y_in, heading_rad} pe teren (x spre dreapta, y în sus, heading în sens trigonometric). */
    private final Supplier<double[]> world;
    private double[] origin = {0, 0, 0};
    private double x, y, h, vx, vy, vh;
    private double hTotal = 0;  // heading that keeps counting full turns
    private double lastX, lastY, lastH;
    private long lastNs = 0;
    private double ticksPerMm = 19.89436789;

    public GoBildaPinpointDriver(Supplier<double[]> worldPose) {
        this.world = worldPose;
        origin = worldPose.get().clone();
    }

    public void update() {
        double[] w = world.get();
        double dx = w[0] - origin[0], dy = w[1] - origin[1];
        double c = Math.cos(origin[2]), s = Math.sin(origin[2]);
        double nx = dx * c + dy * s;
        double ny = -dx * s + dy * c;
        double nh = AngleUnit.RADIANS.normalize(w[2] - origin[2]);
        if (w.length >= 6) {
            // viteza măsurată (ca Pinpoint-ul real), rotită în același sistem ca poziția
            vx = w[3] * c + w[4] * s;
            vy = -w[3] * s + w[4] * c;
            vh = w[5];
        } else {
            long now = org.ftcsim.SimClock.nanoTime();
            if (lastNs != 0) {
                double dt = (now - lastNs) / 1e9;
                if (dt > 1e-4) {
                    vx = (nx - lastX) / dt;
                    vy = (ny - lastY) / dt;
                    vh = AngleUnit.RADIANS.normalize(nh - lastH) / dt;
                }
            }
            lastNs = now;
        }
        hTotal += AngleUnit.RADIANS.normalize(nh - h);
        lastX = x = nx;
        lastY = y = ny;
        lastH = h = nh;
    }

    public void update(ReadData data) { update(); }

    public void resetPosAndIMU() {
        origin = world.get().clone();
        x = y = h = vx = vy = vh = 0;
        hTotal = 0;
        lastX = lastY = lastH = 0;
        lastNs = 0;
    }

    public void recalibrateIMU() {}

    public void setPosition(Pose2D pos) {
        // mută originea astfel încât poziția curentă să fie pos
        update();
        double tx = pos.getX(DistanceUnit.INCH), ty = pos.getY(DistanceUnit.INCH), th = pos.getHeading(AngleUnit.RADIANS);
        double[] w = world.get();
        double oh = w[2] - th;
        double c = Math.cos(oh), s = Math.sin(oh);
        origin = new double[] {w[0] - (tx * c - ty * s), w[1] - (tx * s + ty * c), oh};
        h = th;
        hTotal = th;
        update();
    }

    public void setHeading(double heading, AngleUnit unit) {
        setPosition(new Pose2D(DistanceUnit.INCH, getPosX(DistanceUnit.INCH), getPosY(DistanceUnit.INCH), unit, heading));
    }

    // poziția simulată e chiar centrul robotului, deci offset-urile doar se rețin (getXOffset / getYOffset)
    private double xOffsetMm = 0, yOffsetMm = 0, yawScalar = 1;
    public void setOffsets(double xOffset, double yOffset, DistanceUnit unit) { xOffsetMm = unit.toMm(xOffset); yOffsetMm = unit.toMm(yOffset); }
    public void setEncoderResolution(GoBildaOdometryPods pods) {
        ticksPerMm = pods == GoBildaOdometryPods.goBILDA_SWINGARM_POD ? 13.26291192 : 19.89436789;
    }
    public void setEncoderResolution(double ticksPerUnit, DistanceUnit unit) { ticksPerMm = unit.toMm(1) > 0 ? ticksPerUnit / unit.toMm(1) : ticksPerMm; }
    public void setEncoderDirections(EncoderDirection xEncoder, EncoderDirection yEncoder) {}
    public void setYawScalar(double yawScalar) { this.yawScalar = yawScalar; }

    public Pose2D getPosition() { return new Pose2D(DistanceUnit.INCH, x, y, AngleUnit.RADIANS, h); }
    public double getPosX(DistanceUnit unit) { return unit.fromInches(x); }
    public double getPosY(DistanceUnit unit) { return unit.fromInches(y); }
    public double getHeading(AngleUnit unit) { return unit.fromRadians(h); }
    /** Heading without wrapping to ±180° (like the real driver: it keeps counting turns). */
    public double getHeading(org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit unit) { return unit.fromRadians(hTotal); }
    public double getVelX(DistanceUnit unit) { return unit.fromInches(vx); }
    public double getVelY(DistanceUnit unit) { return unit.fromInches(vy); }
    public double getHeadingVelocity(org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit unit) { return unit.fromRadians(vh); }
    public int getEncoderX() { return (int) Math.round(x * 25.4 * ticksPerMm); }
    public int getEncoderY() { return (int) Math.round(y * 25.4 * ticksPerMm); }
    public DeviceStatus getDeviceStatus() { return DeviceStatus.READY; }
    public double getFrequency() { return 1500; }
    public int getLoopTime() { return 666; }  // µs, ca driverul din SDK 11
    public int getDeviceID() { return 2; }
    public int getDeviceVersion() { return 3; }
    public float getYawScalar() { return (float) yawScalar; }
    public float getXOffset(DistanceUnit unit) { return (float) unit.fromMm(xOffsetMm); }
    public float getYOffset(DistanceUnit unit) { return (float) unit.fromMm(yOffsetMm); }
    public void setPosX(double posX, DistanceUnit unit) { setPosition(new Pose2D(DistanceUnit.INCH, unit.toInches(posX), getPosY(DistanceUnit.INCH), AngleUnit.RADIANS, h)); }
    public void setPosY(double posY, DistanceUnit unit) { setPosition(new Pose2D(DistanceUnit.INCH, getPosX(DistanceUnit.INCH), unit.toInches(posY), AngleUnit.RADIANS, h)); }

    @Override public Manufacturer getManufacturer() { return Manufacturer.Other; }
    @Override public String getDeviceName() { return "goBILDA Pinpoint Odometry Computer"; }
}
