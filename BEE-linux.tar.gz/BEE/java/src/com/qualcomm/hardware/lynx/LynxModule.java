package com.qualcomm.hardware.lynx;

import com.qualcomm.robotcore.hardware.HardwareDevice;
import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.robotcore.external.navigation.VoltageUnit;

/** Ca în SDK-ul FTC: Control Hub-ul. Bulk caching schimbă cât durează citirile (vezi org.ftcsim.SimHub). */
public class LynxModule implements HardwareDevice {
    public enum BulkCachingMode { OFF, AUTO, MANUAL }

    private BulkCachingMode mode = BulkCachingMode.OFF;
    private final java.util.function.DoubleSupplier voltage;

    public LynxModule(java.util.function.DoubleSupplier voltage) { this.voltage = voltage; }

    public void setBulkCachingMode(BulkCachingMode m) { mode = m; org.ftcsim.SimHub.setMode(m); }
    public BulkCachingMode getBulkCachingMode() { return mode; }
    public void clearBulkCache() { org.ftcsim.SimHub.clearCache(); }
    public boolean isParent() { return true; }
    public double getInputVoltage(VoltageUnit unit) { return unit == VoltageUnit.MILLIVOLTS ? voltage.getAsDouble() * 1000 : voltage.getAsDouble(); }
    public double getCurrent(CurrentUnit unit) { return 0; }
    public void setConstant(int color) {}
    @Override public String getDeviceName() { return "Control Hub"; }
    @Override public Manufacturer getManufacturer() { return Manufacturer.Lynx; }
}
