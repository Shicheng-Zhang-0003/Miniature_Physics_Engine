package com.qualcomm.hardware.rev;

import com.qualcomm.robotcore.hardware.DistanceSensor;

/** Ca în SDK-ul FTC: senzorul REV 2m (Time-of-Flight). */
public abstract class Rev2mDistanceSensor implements DistanceSensor {
    public boolean didTimeoutOccur() { return false; }
    public byte getModelID() { return (byte) 0xEE; }  // ca VL53L0X (ID-ul de model al senzorului)
    @Override public String getDeviceName() { return "REV 2M ToF Distance Sensor"; }
}
