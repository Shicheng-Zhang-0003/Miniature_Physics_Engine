package com.qualcomm.hardware.rev;

import com.qualcomm.robotcore.hardware.ColorRangeSensor;
import com.qualcomm.robotcore.hardware.Light;

/** Ca în SDK-ul FTC: senzorul de culoare REV V3 (are și distanță/proximitate; LED-ul e mereu aprins). */
public abstract class RevColorSensorV3 implements ColorRangeSensor, Light {
    @Override public double getLightDetected() { return getNormalizedColors().alpha; }
    @Override public double getRawLightDetected() { return alpha(); }
    @Override public double getRawLightDetectedMax() { return 65535; }
    @Override public String status() { return "REV Color Sensor V3 (simulated)"; }
    @Override public boolean isLightOn() { return true; }
    @Override public Manufacturer getManufacturer() { return Manufacturer.Broadcom; }
    @Override public String getDeviceName() { return "REV Color Sensor V3"; }
}
