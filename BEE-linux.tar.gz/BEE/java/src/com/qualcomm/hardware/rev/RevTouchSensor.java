package com.qualcomm.hardware.rev;

import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.TouchSensor;

/** Ca în SDK-ul FTC: butonul REV (merge ca TouchSensor sau ca DigitalChannel). */
public abstract class RevTouchSensor implements TouchSensor, DigitalChannel {
    @Override public String getDeviceName() { return "REV Touch Sensor"; }
}
