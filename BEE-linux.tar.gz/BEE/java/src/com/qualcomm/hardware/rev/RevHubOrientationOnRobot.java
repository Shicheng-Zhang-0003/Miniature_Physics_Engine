package com.qualcomm.hardware.rev;

import com.qualcomm.robotcore.hardware.ImuOrientationOnRobot;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;

/**
 * Ca în SDK-ul FTC. Simulatorul e 2D și dă direct yaw-ul robotului, deci orientarea hub-ului nu schimbă yaw-ul;
 * o păstrăm (și o verificăm ca SDK-ul) ca același cod să compileze și să ruleze și pe robotul real.
 */
public class RevHubOrientationOnRobot implements ImuOrientationOnRobot {
    public enum LogoFacingDirection { UP, DOWN, FORWARD, BACKWARD, LEFT, RIGHT }
    public enum UsbFacingDirection { UP, DOWN, FORWARD, BACKWARD, LEFT, RIGHT }

    private final Quaternion rotation;

    public RevHubOrientationOnRobot(LogoFacingDirection logo, UsbFacingDirection usb) {
        // ca în SDK: logo și USB trebuie să fie pe axe diferite (nu aceeași direcție și nici opuse)
        if (axis(logo.name()) == axis(usb.name())) {
            throw new IllegalArgumentException("The Logo Facing Direction and USB Facing Direction cannot be on the same axis (" + logo + ", " + usb + ")");
        }
        rotation = Quaternion.identityQuaternion();
    }

    public RevHubOrientationOnRobot(Orientation rotation) { this.rotation = Quaternion.identityQuaternion(); }
    public RevHubOrientationOnRobot(Quaternion rotation) { this.rotation = rotation; }

    private static int axis(String dir) {
        switch (dir) {
            case "UP": case "DOWN": return 2;
            case "FORWARD": case "BACKWARD": return 1;
            default: return 0;
        }
    }

    /** Ca în SDK: rotirea hub-ului (în grade) față de poziția „logo sus, USB în față”, în jurul X, apoi Y, apoi Z. */
    public static Orientation xyzOrientation(double x, double y, double z) {
        return new Orientation(AxesReference.INTRINSIC, AxesOrder.XYZ, AngleUnit.DEGREES, (float) x, (float) y, (float) z, 0);
    }

    public static Orientation zyxOrientation(double z, double y, double x) {
        return new Orientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES, (float) z, (float) y, (float) x, 0);
    }

    public Quaternion imuRotationOffset() { return rotation; }
    public Quaternion angularVelocityTransform() { return rotation; }
    public Quaternion imuCoordinateSystemOrientationFromPerspectiveOfRobot() { return rotation; }
}
