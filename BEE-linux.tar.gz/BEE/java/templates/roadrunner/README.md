# Road Runner quickstart files (templates)

From https://github.com/acmerobotics/road-runner-quickstart (commit 6e63a7792e9bb6958798bf46fc03d84765b50c51), TeamCode files, unchanged.
BEE fills them in for your robot (motor / encoder names, directions, localizer, PARAMS) when it
generates code that drives with Road Runner. Library versions: road-runner core / actions 1.0.1, ftc 0.1.25,
FTC Dashboard 0.5.1 (see the quickstart's TeamCode/build.gradle).
