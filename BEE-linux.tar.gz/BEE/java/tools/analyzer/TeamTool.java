import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Launcher for BEE's team-code tool (run like RunOpMode.java, with the single-file source launcher):
 *
 *   java TeamTool.java [--home <this folder>] analyze  <project dir|zip> <model.json> [--garage profile.json]
 *   java TeamTool.java generate <model.json> <answers.json> <path.json> <out dir>
 *
 * Compiles src/ into build/ once (again only when a source changed), then runs org.beesim.team.Main.
 */
public class TeamTool {
    public static void main(String[] args) throws Exception {
        // the folder of this file: --home <dir> (what BEE passes), else the source launcher's file, else the working directory
        String self = System.getProperty("jdk.launcher.sourcefile");
        Path home = self != null ? Path.of(self).toAbsolutePath().getParent() : Path.of("").toAbsolutePath();
        if (args.length >= 2 && args[0].equals("--home")) {
            home = Path.of(args[1]);
            args = java.util.Arrays.copyOfRange(args, 2, args.length);
        }
        Path src = home.resolve("src"), build = home.resolve("build");
        if (args.length >= 2 && args[0].equals("--work")) {  // home may be read-only (the exported game)
            build = Path.of(args[1]);
            args = java.util.Arrays.copyOfRange(args, 2, args.length);
        }
        List<Path> files;
        try (Stream<Path> s = Files.walk(src)) {
            files = s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        }
        long newest = 0;
        for (Path f : files) newest = Math.max(newest, Files.getLastModifiedTime(f).toMillis());
        Path stamp = build.resolve(".stamp");
        if (!Files.exists(stamp) || Files.getLastModifiedTime(stamp).toMillis() < newest) {
            Files.createDirectories(build);
            JavaCompiler jc = ToolProvider.getSystemJavaCompiler();
            if (jc == null) {
                System.err.println("A JDK (with javac) is needed.");
                System.exit(4);
            }
            List<String> a = new ArrayList<>(List.of("-nowarn", "-d", build.toString()));
            for (Path f : files) a.add(f.toString());
            if (jc.run(null, null, null, a.toArray(new String[0])) != 0) System.exit(4);
            Files.writeString(stamp, String.valueOf(newest));
        }
        System.setProperty("bee.pedroApi", home.resolve("resources/pedro-api").toString());
        try (URLClassLoader cl = new URLClassLoader(new URL[]{build.toUri().toURL()}, TeamTool.class.getClassLoader())) {
            cl.loadClass("org.beesim.team.Main").getMethod("main", String[].class).invoke(null, (Object) args);
        }
    }
}
