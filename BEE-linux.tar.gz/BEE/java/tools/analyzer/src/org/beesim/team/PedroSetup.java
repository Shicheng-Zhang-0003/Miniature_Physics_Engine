package org.beesim.team;

import com.sun.source.tree.BlockTree;
import com.sun.source.tree.ExpressionStatementTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.LambdaExpressionTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.ReturnTree;
import com.sun.source.tree.StatementTree;
import com.sun.source.tree.Tree;
import org.beesim.team.JavaIndex.ClassInfo;
import org.beesim.team.JavaIndex.FieldInfo;
import org.beesim.team.JavaIndex.MethodInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The team's existing Pedro setup: the constants class, its package, the factory that returns a Follower
 * (Constants.createFollower(hardwareMap)), the drivetrain / localizer it builds, and every tuned value in it.
 *
 * 2.x: builder chains  new FollowerConstants().mass(12.8).forwardZeroPowerAcceleration(-61.3)...
 *      factory         new FollowerBuilder(followerConstants, hardwareMap).pinpointLocalizer(..).mecanumDrivetrain(..).build()
 * 3.x: config lambdas  new ForesightConfig(c -> { c.maxAchievableForwardVelocity.set(72.7); ... })
 *      factory         new Follower(localizer, new Mecanum(h, drivetrainConfig), new Foresight(foresightConfig))
 */
public final class PedroSetup {
    private final JavaIndex ix;
    private final Eval ev;
    public Map<String, Object> json;                 // null when the team has no constants class / factory
    public ClassInfo constantsClass;
    public MethodInfo factory;
    public final List<Map<String, Object>> warnings = new ArrayList<>();
    /** "FollowerConstants.mass" -> Val, "MecanumConstants.xVelocity" -> Val, "PathConstraints.<init>" -> OBJ, "ForesightConfig.coast" ... */
    public final Map<String, Val> values = new LinkedHashMap<>();
    public final Map<String, String> builderTypes = new LinkedHashMap<>();  // field name -> builder type (followerConstants -> FollowerConstants)

    public PedroSetup(JavaIndex ix, Eval ev) { this.ix = ix; this.ev = ev; }

    public void run() {
        // every static method returning Follower; prefer the one in a class called Constants
        List<MethodInfo> factories = new ArrayList<>();
        for (ClassInfo c : ix.classes())
            for (MethodInfo m : c.methods)
                if (m.isStatic && JavaIndex.simpleName(m.returnType).equals("Follower")) factories.add(m);
        factories.sort((a, b) -> Boolean.compare(!a.owner.simple.equals("Constants"), !b.owner.simple.equals("Constants")));
        if (factories.isEmpty()) {
            // 3.x teams sometimes only keep the configs and build the Follower in the OpMode
            for (ClassInfo c : ix.classes())
                for (FieldInfo f : c.fields.values())
                    if (f.isStatic && (f.type.endsWith("FollowerConstants") || f.type.endsWith("ForesightConfig") || f.type.endsWith("MecanumConstants") || f.type.endsWith("MecanumConfig"))) {
                        constantsClass = c;
                        break;
                    }
            if (constantsClass == null) return;
        } else {
            factory = factories.get(0);
            constantsClass = factory.owner;
            if (factories.size() > 1) {
                List<String> where = new ArrayList<>();
                for (MethodInfo m : factories) where.add(m.owner.fqn + "." + m.name + " (" + m.owner.src.path + ":" + m.line + ")");
                warnings.add(Json.obj("kind", "multiple_factories", "message", "Several methods return a Follower: " + String.join(", ", where) + ". BEE uses the first; confirm it.",
                        "candidates", where));
            }
        }
        ClassInfo c = constantsClass;
        for (FieldInfo f : c.fields.values()) {
            if (!f.isStatic || f.init == null) continue;
            String type = JavaIndex.simpleName(f.type);
            builderTypes.put(f.name, type);
            collect(type, f.init, c);
        }
        Map<String, Object> j = new LinkedHashMap<>();
        j.put("class", c.fqn);
        j.put("ref", c.ref());
        j.put("import", c.importName());
        j.put("package", c.pkg);
        j.put("file", c.src.path);
        j.put("line", c.line);
        if (factory != null) {
            List<String> params = new ArrayList<>();
            for (var p : factory.params) params.add(JavaIndex.simpleName(p.getType().toString()));
            j.put("factory", Json.obj("name", factory.name, "params", params, "line", factory.line, "call", c.ref() + "." + factory.name + "(" + String.join(", ", argNames(params)) + ")"));
            j.put("drivetrain", Fact.of(drivetrain(), c.src.path, factory.line, Fact.HIGH, "factory body"));
            j.put("localizer", Fact.of(localizer(), c.src.path, factory.line, Fact.HIGH, "factory body"));
        } else {
            j.put("factory", null);
        }
        Map<String, Object> vals = new LinkedHashMap<>();
        for (Map.Entry<String, Val> e : values.entrySet()) vals.put(e.getKey(), e.getValue() == null ? null : e.getValue().json());
        j.put("values", vals);
        j.put("builders", builderTypes);
        json = j;
    }

    private static List<String> argNames(List<String> types) {
        List<String> out = new ArrayList<>();
        for (String t : types) out.add(t.equals("HardwareMap") ? "hardwareMap" : Character.toLowerCase(t.charAt(0)) + t.substring(1));
        return out;
    }

    /** new X().a(1).b(2)  /  new X(c -> { c.a.set(1); })  /  new PathConstraints(0.99, 100, 0.8, 1.5) */
    private void collect(String type, ExpressionTree init, ClassInfo ctx) {
        List<MethodInvocationTree> chain = new ArrayList<>();
        ExpressionTree e = init;
        while (e instanceof MethodInvocationTree) {
            chain.add((MethodInvocationTree) e);
            ExpressionTree sel = ((MethodInvocationTree) e).getMethodSelect();
            e = sel instanceof MemberSelectTree ? ((MemberSelectTree) sel).getExpression() : null;
        }
        Collections.reverse(chain);
        if (e instanceof NewClassTree) {
            NewClassTree n = (NewClassTree) e;
            String t = JavaIndex.simpleName(n.getIdentifier().toString().replaceAll("<.*>", ""));
            if (!n.getArguments().isEmpty() && n.getArguments().get(0) instanceof LambdaExpressionTree) {
                lambdaConfig(t, (LambdaExpressionTree) n.getArguments().get(0), ctx);
            } else if (!n.getArguments().isEmpty()) {
                Val v = ev.eval(n, ctx);
                values.put(t + ".<init>/" + n.getArguments().size(), v);
            }
            for (MethodInvocationTree m : chain) {
                String name = Walk.methodName(m);
                if (m.getArguments().size() == 1) values.put(t + "." + name, ev.eval(m.getArguments().get(0), ctx));
                else {
                    Val obj = new Val();
                    obj.kind = Val.K.OBJ;
                    obj.type = name;
                    for (ExpressionTree a : m.getArguments()) obj.args.add(ev.eval(a, ctx));
                    values.put(t + "." + name, obj);
                }
            }
        }
    }

    /** 3.x: c -> { c.frontLeftName.set("FL"); c.coast.set(Controller.proportionalFeedforward(0.01)); } */
    private void lambdaConfig(String type, LambdaExpressionTree l, ClassInfo ctx) {
        if (!(l.getBody() instanceof BlockTree)) return;
        for (StatementTree st : ((BlockTree) l.getBody()).getStatements()) {
            if (!(st instanceof ExpressionStatementTree)) continue;
            ExpressionTree ex = ((ExpressionStatementTree) st).getExpression();
            if (!(ex instanceof MethodInvocationTree) || !Walk.methodName((MethodInvocationTree) ex).equals("set")) continue;
            MethodInvocationTree set = (MethodInvocationTree) ex;
            ExpressionTree target = ((MemberSelectTree) set.getMethodSelect()).getExpression();
            if (!(target instanceof MemberSelectTree) || set.getArguments().isEmpty()) continue;
            String field = ((MemberSelectTree) target).getIdentifier().toString();
            ExpressionTree arg = set.getArguments().get(0);
            Val v = ev.eval(arg, ctx);
            if (v == null && arg instanceof MethodInvocationTree) {
                // Controller.proportional(5.2), Vector2D.cartesian(a, b), Matrix.diag(a, b)
                MethodInvocationTree mi = (MethodInvocationTree) arg;
                v = new Val();
                v.kind = Val.K.OBJ;
                v.type = JavaIndex.dotted(mi.getMethodSelect());
                for (ExpressionTree a : mi.getArguments()) v.args.add(ev.eval(a, ctx));
            }
            values.put(type + "." + field, v);
        }
    }

    /** The factory body, plus the helpers of the constants class it calls (localizer(h)...). */
    private String factoryText() {
        if (factory == null || factory.body == null) return "";
        StringBuilder sb = new StringBuilder(factory.body.toString());
        for (MethodInfo m : constantsClass.methods) if (m != factory && m.body != null && m.isStatic) sb.append('\n').append(m.body);
        return sb.toString();
    }

    private String drivetrain() {
        String t = factoryText();
        for (String[] k : new String[][]{{"mecanumExDrivetrain", "mecanum_ex"}, {"mecanumDrivetrain", "mecanum"}, {"swerveDrivetrain", "swerve"}, {"new Mecanum(", "mecanum"},
                {"new Swerve(", "swerve"}, {"tankDrivetrain", "tank"}, {"setDrivetrain", "custom"}})
            if (t.contains(k[0])) return k[1];
        return "unknown";
    }

    private String localizer() {
        String t = factoryText();
        for (String[] k : new String[][]{{"pinpointLocalizer", "pinpoint"}, {"PinpointLocalizer", "pinpoint"}, {"threeWheelIMULocalizer", "three_wheel_imu"},
                {"ThreeWheelIMULocalizer", "three_wheel_imu"}, {"threeWheelLocalizer", "three_wheel"}, {"ThreeWheelLocalizer", "three_wheel"},
                {"twoWheelLocalizer", "two_wheel"}, {"TwoWheelLocalizer", "two_wheel"}, {"OTOSLocalizer", "otos"}, {"OTOSLocalizer".toLowerCase(), "otos"},
                {"oTOSLocalizer", "otos"}, {"driveEncoderLocalizer", "drive_encoders"}, {"octoQuadLocalizer", "octoquad"}, {"setLocalizer", "custom"}})
            if (t.contains(k[0])) return k[1];
        return "unknown";
    }

    /** True when the expression `x` refers to a Follower created by the team's factory. */
    public boolean isFactoryCall(Tree t) {
        return factory != null && t instanceof MethodInvocationTree && Walk.methodName((MethodInvocationTree) t).equals(factory.name)
                && t.toString().contains(constantsClass.simple);
    }

    static boolean returns(MethodInfo m, String type) {
        if (m.body == null) return false;
        for (StatementTree s : m.body.getStatements()) if (s instanceof ReturnTree && String.valueOf(((ReturnTree) s).getExpression()).contains(type)) return true;
        return false;
    }
}
