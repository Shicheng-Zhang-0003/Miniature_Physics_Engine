package org.beesim.team;

import com.sun.source.tree.AssignmentTree;
import com.sun.source.tree.CaseTree;
import com.sun.source.tree.CompoundAssignmentTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.IdentifierTree;
import com.sun.source.tree.LambdaExpressionTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.SwitchTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.UnaryTree;
import com.sun.source.util.TreePath;
import org.beesim.team.Hardware.Device;
import org.beesim.team.JavaIndex.ClassInfo;
import org.beesim.team.JavaIndex.FieldInfo;
import org.beesim.team.JavaIndex.MethodInfo;
import org.beesim.team.Walk.Hit;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The team's subsystems (Flywheel, Intake, Indexer, Turret, Lift...) and the wrapper that holds them (Robot):
 * public API, what each method DOES to the hardware (with the team's constants), which methods must run every loop,
 * and fields that must be set before a method works (Flywheel.velocity before startFlywheel()).
 */
public final class Subsystems {

    public static final class Effect {
        public String target;      // device field (rightServo), subsystem field (indexer), or own field (targetVelocity)
        public String op;          // setPosition / setPower / setVelocity / setTargetPosition / call:<name> / assign
        public Val value;
        public String text;
        public Integer caseLabel;  // inside switch (param) { case 1: ... }
        public int line;
        public Device device;

        Map<String, Object> json() {
            Map<String, Object> m = Json.obj("target", target, "op", op, "value", value == null ? null : value.json(), "text", text, "line", line);
            if (caseLabel != null) m.put("case", caseLabel);
            if (device != null) m.put("device", device.name);
            return m;
        }
    }

    public static final class Api {
        public MethodInfo mi;
        public String kind;       // action / command / sync / query / blocking
        public final List<Effect> effects = new ArrayList<>();
        public boolean blocking;  // sleep() / while loops inside: never call it from a loop
        public String switchParam;
        public final Set<String> reads = new LinkedHashSet<>();
        public String fixedSpeed;  // flywheel: the speed is a constant written inside this method (test shots cannot scale it)

        Map<String, Object> json() {
            List<Object> eff = new ArrayList<>();
            for (Effect e : effects) eff.add(e.json());
            List<String> ps = new ArrayList<>();
            for (var p : mi.params) ps.add(p.getType() + " " + p.getName());
            return Json.obj("name", mi.name, "params", ps, "returns", mi.returnType, "kind", kind, "blocking", blocking, "static", mi.isStatic,
                    "switch_param", switchParam, "effects", eff, "line", mi.line, "fixed_speed", fixedSpeed);
        }
    }

    public static final class Sub {
        public ClassInfo cls;
        public String role, roleConfidence, roleEvidence;
        public final List<Device> devices = new ArrayList<>();
        public final Map<String, ClassInfo> subFields = new LinkedHashMap<>();
        public final List<Api> api = new ArrayList<>();
        public final List<Map<String, Object>> constants = new ArrayList<>();
        public Map<String, Object> update;          // {method, required, evidence, line, params}
        public final List<Map<String, Object>> preconditions = new ArrayList<>();
        public final List<Map<String, Object>> servoStates = new ArrayList<>(); // per servo device: open/closed positions

        public Api method(String name, int nparams) {
            for (Api a : api) if (a.mi.name.equals(name) && (nparams < 0 || a.mi.params.size() == nparams)) return a;
            return null;
        }
    }

    public static final class Wrapper {
        public ClassInfo cls;
        public final Map<String, ClassInfo> subsystems = new LinkedHashMap<>();
        public String followerField, hubsField;
        public MethodInfo ctor, update;
        public final List<String> updateCalls = new ArrayList<>();
        public boolean updateCallsFollower;
    }

    private final JavaIndex ix;
    private final Eval ev;
    private final Hardware hw;
    public final Map<ClassInfo, Sub> subs = new LinkedHashMap<>();
    public Wrapper wrapper;
    public final List<Map<String, Object>> warnings = new ArrayList<>();

    static final String[] OPMODE_BASES = {"OpMode", "LinearOpMode", "CommandOpMode", "SelectableOpMode", "NextFTCOpMode", "PedroOpMode"};

    public Subsystems(JavaIndex ix, Eval ev, Hardware hw) { this.ix = ix; this.ev = ev; this.hw = hw; }

    public Hardware hardware() { return hw; }

    public boolean isOpMode(ClassInfo c) {
        return ix.isA(c, OPMODE_BASES) || c.annotations.contains("Autonomous") || c.annotations.contains("TeleOp");
    }

    public void run() {
        // 1. classes that own hardware or are framework subsystems
        for (ClassInfo c : ix.classes()) {
            if (isOpMode(c)) continue;
            boolean framework = ix.isA(c, "SubsystemBase", "Subsystem");
            List<Device> own = new ArrayList<>();
            for (Device d : hw.devices) if (d.owner == c && !"hub".equals(d.kind)) own.add(d);
            if (own.isEmpty() && !framework) continue;
            Sub s = new Sub();
            s.cls = c;
            s.devices.addAll(own);
            subs.put(c, s);
        }
        // 2. subsystem-typed fields (Robot.flywheel : Flywheel) and the wrapper
        List<Wrapper> candidates = new ArrayList<>();
        for (ClassInfo c : ix.classes()) {
            if (isOpMode(c)) continue;
            Map<String, ClassInfo> held = new LinkedHashMap<>();
            String follower = null, hubs = null;
            for (FieldInfo f : c.fields.values()) {
                if (f.isStatic) continue;
                ClassInfo t = ix.resolveType(f.type, c);
                if (t != null && subs.containsKey(t) && t != c) held.put(f.name, t);
                if (JavaIndex.simpleName(f.type).equals("Follower")) follower = f.name;
                if (f.type.contains("LynxModule")) hubs = f.name;
            }
            if (subs.containsKey(c)) subs.get(c).subFields.putAll(held);
            if (held.size() >= 2 || (held.size() >= 1 && follower != null)) {
                Wrapper w = new Wrapper();
                w.cls = c;
                w.subsystems.putAll(held);
                w.followerField = follower;
                w.hubsField = hubs;
                candidates.add(w);
            }
        }
        // the outermost holder: Indexer (3 servos + 4 sensors) sits inside Robot, so it is a subsystem, not the robot;
        // then the one that holds the Follower, then the one that holds the most
        Set<ClassInfo> heldByOther = new HashSet<>();
        for (Wrapper w : candidates) for (ClassInfo t : w.subsystems.values()) if (t != w.cls) heldByOther.add(t);
        for (Wrapper w : candidates) {
            if (heldByOther.contains(w.cls)) continue;
            if (wrapper == null) { wrapper = w; continue; }
            boolean wf = w.followerField != null, cf = wrapper.followerField != null;
            if (wf != cf ? wf : w.subsystems.size() > wrapper.subsystems.size()) wrapper = w;
        }
        if (wrapper != null) {
            if (!subs.containsKey(wrapper.cls)) {
                Sub s = new Sub();
                s.cls = wrapper.cls;
                s.subFields.putAll(wrapper.subsystems);
                subs.put(wrapper.cls, s);
            }
            wrapper.ctor = wrapper.cls.ctors().isEmpty() ? null : wrapper.cls.ctors().get(0);
        }
        for (Sub s : subs.values()) analyze(s);
        if (wrapper != null) {
            Sub ws = subs.get(wrapper.cls);
            Api up = null;
            for (Api a : ws.api) if (a.mi.name.equals("update") || a.mi.name.equals("periodic")) up = a;
            if (up != null) {
                wrapper.update = up.mi;
                for (Hit h : Walk.find(wrapper.cls, up.mi, t -> t instanceof MethodInvocationTree)) {
                    MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
                    String r = Walk.receiver(mi);
                    if (r == null) continue;
                    String call = r + "." + Walk.methodName(mi);
                    wrapper.updateCalls.add(call);
                    if (r.equals(wrapper.followerField) && Walk.methodName(mi).equals("update")) wrapper.updateCallsFollower = true;
                }
            }
        }
    }

    // ---------------- one subsystem ----------------

    private void analyze(Sub s) {
        ClassInfo c = s.cls;
        guessRole(s);
        for (MethodInfo m : c.methods) {
            if (m.isCtor || m.isPrivate || m.body == null) continue;
            Api a = new Api();
            a.mi = m;
            String rt = JavaIndex.simpleName(m.returnType);
            a.kind = rt.equals("Action") ? "action" : rt.contains("Command") ? "command" : rt.equals("void") ? "sync" : "query";
            effects(s, a);
            s.api.add(a);
        }
        // also private helpers named like actions are useful for flattening (openAndCloseServos)
        for (MethodInfo m : c.methods) {
            if (!m.isPrivate || m.body == null) continue;
            Api a = new Api();
            a.mi = m;
            String rt = JavaIndex.simpleName(m.returnType);
            a.kind = rt.equals("Action") ? "action" : rt.contains("Command") ? "command" : rt.equals("void") ? "sync" : "query";
            effects(s, a);
            s.api.add(a);
        }
        constants(s);
        if ("flywheel".equals(s.role)) for (Api a : s.api) a.fixedSpeed = fixedSpeed(a, s.cls);
        servoStates(s);
        updateRequirement(s);
        preconditions(s);
    }

    private static final String[][] ROLE_WORDS = {
            {"flywheel", "fly", "shoot", "launch", "outtake", "cannon"},
            {"intake", "intake", "roller", "sweeper", "collector"},
            {"indexer", "index", "gate", "feeder", "kicker", "transfer", "loader", "spindexer", "hopper"},
            {"turret", "turret", "yaw"},
            {"hood", "hood"},
            {"lift", "lift", "slide", "elevator"},
            {"arm", "arm", "pivot", "wrist"},
            {"claw", "claw", "grabber", "gripper"},
            {"drive", "drivetrain", "chassis", "mecanum"},
            {"vision", "limelight", "camera", "vision"},
    };

    private void guessRole(Sub s) {
        if (wrapper != null && s.cls == wrapper.cls) {
            s.role = "robot";
            s.roleConfidence = Fact.HIGH;
            s.roleEvidence = "holds " + wrapper.subsystems.keySet();
            return;
        }
        String cls = s.cls.simple.toLowerCase(Locale.ROOT);
        for (String[] r : ROLE_WORDS)
            for (int i = 1; i < r.length; i++)
                if (cls.contains(r[i])) {
                    s.role = r[0];
                    s.roleConfidence = cls.equals(r[i]) || cls.equals(r[0]) ? Fact.HIGH : Fact.MEDIUM;
                    s.roleEvidence = "class name " + s.cls.simple;
                    return;
                }
        StringBuilder names = new StringBuilder();
        for (Device d : s.devices) names.append(' ').append(String.valueOf(d.name).toLowerCase(Locale.ROOT)).append(' ').append(d.field.toLowerCase(Locale.ROOT));
        for (String[] r : ROLE_WORDS)
            for (int i = 1; i < r.length; i++)
                if (names.toString().contains(r[i])) {
                    s.role = r[0];
                    s.roleConfidence = Fact.LOW;
                    s.roleEvidence = "device names" + names;
                    return;
                }
        s.role = "other";
        s.roleConfidence = Fact.LOW;
        s.roleEvidence = "no recognizable name";
    }

    static final String[] DEVICE_OPS = {"setPosition", "setPower", "setVelocity", "setTargetPosition", "set"};

    /** What the method does: device writes, calls into other subsystems, field assignments. Grouped by switch case when it switches on a parameter. */
    private void effects(Sub s, Api a) {
        ClassInfo c = s.cls;
        MethodInfo m = a.mi;
        for (Hit h : Walk.find(c, m, t -> t instanceof MethodInvocationTree || t instanceof AssignmentTree || t instanceof CompoundAssignmentTree
                || t instanceof SwitchTree || t instanceof UnaryTree)) {
            Tree t = h.leaf();
            if (t instanceof SwitchTree) {
                String sel = ((SwitchTree) t).getExpression().toString().replaceAll("[()]", "").trim();
                if (m.paramIndex(sel) >= 0) a.switchParam = sel;
                continue;
            }
            Integer label = caseOf(h.path, m);
            if (t instanceof MethodInvocationTree) {
                MethodInvocationTree mi = (MethodInvocationTree) t;
                String fn = Walk.methodName(mi);
                String r = Walk.receiver(mi);
                if (fn.equals("sleep") || fn.equals("idle") || (r != null && r.equals("Thread") && fn.equals("sleep"))) a.blocking = true;
                if (r == null) continue;
                String root = r.split("\\.")[0];
                Effect e = new Effect();
                e.target = r;
                e.text = ix.text(c.src, mi);
                e.line = h.line(ix);
                e.caseLabel = label;
                Device d = hw.byField(c, root);
                if (d != null) {
                    boolean op = false;
                    for (String x : DEVICE_OPS) op |= x.equals(fn);
                    if (!op) continue;
                    e.device = d;
                    e.op = fn;
                    e.value = mi.getArguments().isEmpty() ? null : ev.eval(mi.getArguments().get(0), c);
                    a.effects.add(e);
                } else if (s.subFields.containsKey(root) || (wrapper != null && root.equals(wrapper.followerField) && c == wrapper.cls)) {
                    e.op = "call:" + fn;
                    a.effects.add(e);
                }
            } else if (t instanceof AssignmentTree || t instanceof CompoundAssignmentTree || t instanceof UnaryTree) {
                ExpressionTree var = t instanceof AssignmentTree ? ((AssignmentTree) t).getVariable()
                        : t instanceof CompoundAssignmentTree ? ((CompoundAssignmentTree) t).getVariable() : ((UnaryTree) t).getExpression();
                String target = JavaIndex.dotted(var);
                if (target == null) continue;
                if (target.startsWith("this.")) target = target.substring(5);
                if (target.contains(".") || ix.field(c, target) == null || m.paramIndex(target) >= 0 && !JavaIndex.dotted(var).startsWith("this.")) continue;
                Effect e = new Effect();
                e.target = target;
                e.op = "assign";
                e.value = t instanceof AssignmentTree ? ev.eval(((AssignmentTree) t).getExpression(), c) : null;
                e.text = ix.text(c.src, t);
                e.line = h.line(ix);
                e.caseLabel = label;
                a.effects.add(e);
            }
        }
        // fields the method reads (for preconditions); a local with the same name hides the field
        Set<String> localNames = new LinkedHashSet<>();
        for (Hit h : Walk.find(c, m, t -> t instanceof com.sun.source.tree.VariableTree)) localNames.add(((com.sun.source.tree.VariableTree) h.leaf()).getName().toString());
        for (Hit h : Walk.find(c, m, t -> t instanceof IdentifierTree || t instanceof MemberSelectTree)) {
            String n = h.leaf() instanceof IdentifierTree ? ((IdentifierTree) h.leaf()).getName().toString()
                    : (JavaIndex.dotted((ExpressionTree) h.leaf()) != null && JavaIndex.dotted((ExpressionTree) h.leaf()).startsWith("this.") ? ((MemberSelectTree) h.leaf()).getIdentifier().toString() : null);
            if (n != null && c.fields.containsKey(n) && m.paramIndex(n) < 0 && (!localNames.contains(n) || h.leaf() instanceof MemberSelectTree)) a.reads.add(n);
        }
        if (!a.blocking) {
            for (Hit h : Walk.find(c, m, t -> t.getKind() == Tree.Kind.WHILE_LOOP)) {
                String cond = ((com.sun.source.tree.WhileLoopTree) h.leaf()).getCondition().toString();
                if (cond.contains("opModeIsActive") || cond.contains("isBusy") || cond.contains("Busy")) a.blocking = true;
            }
        }
        if (a.blocking) a.kind = "blocking";
    }

    /** The case label (an int constant) the node sits under, when the method switches on one of its parameters. */
    private Integer caseOf(TreePath p, MethodInfo m) {
        for (TreePath q = p; q != null; q = q.getParentPath()) {
            if (q.getLeaf() instanceof CaseTree) {
                CaseTree ct = (CaseTree) q.getLeaf();
                TreePath sp = q.getParentPath();
                if (sp == null || !(sp.getLeaf() instanceof SwitchTree)) return null;
                String sel = ((SwitchTree) sp.getLeaf()).getExpression().toString().replaceAll("[()]", "").trim();
                if (m.paramIndex(sel) < 0 || ct.getExpressions().isEmpty()) return null;
                Val v = ev.eval(ct.getExpressions().get(0), m.owner);
                return v != null && v.isNum() ? (int) v.num : null;
            }
            if (q.getLeaf() instanceof LambdaExpressionTree && q != p) continue;
        }
        return null;
    }

    // ---------------- constants and their meaning ----------------

    static final String[][] TAGS = {
            {"open", "OPEN", "RELEASE"}, {"closed", "CLOSED", "CLOSE", "SHUT", "HOLD", "LOCK"}, {"up", "UP", "RAISED", "HIGH"}, {"down", "DOWN", "LOWERED", "LOW"},
            {"in", "IN", "INTAKE"}, {"out", "OUT", "OUTTAKE", "EJECT", "REVERSE"}, {"idle", "IDLE", "OFF", "STOP", "REST", "ZERO", "HOME", "STOW", "STOWED", "RETRACT", "RETRACTED"},
            {"push", "PUSH", "KICK", "FIRE", "FEED", "EXTEND", "EXTENDED", "OUT_POSITION"}, {"max", "MAX"}, {"min", "MIN"}, {"limit", "LIMIT"}, {"left", "LEFT"}, {"right", "RIGHT"},
            {"center", "CENTER", "MIDDLE", "MID"}, {"velocity", "VELOCITY", "VEL", "RPM", "SPEED"}, {"power", "POWER"}, {"position", "POSITION", "POS"},
            {"delay", "DELAY", "WAIT", "TIME", "TIMEOUT"}, {"fallback", "FALLBACK", "DEFAULT"}, {"angle", "ANGLE", "DEG", "DEGREES"},
            {"tolerance", "TOLERANCE", "TOL"}, {"seconds", "SECONDS", "SEC", "S"}, {"millis", "MS", "MILLIS", "MILLISECONDS"}, {"count", "COUNT", "CAPACITY", "PIECES", "BALLS", "ARTIFACTS"},
    };

    static List<String> tags(String name) { return tags(name, null); }

    /**
     * Meaning of a constant from its name. Tokens that only repeat the device's own name do not count:
     * for the servo "kicker", KICK_REST means "rest" (KICK is the device), KICK_PUSH means "push".
     */
    static List<String> tags(String name, String device) {
        List<String> out = new ArrayList<>();
        String[] all = name.replaceAll("([a-z])([A-Z])", "$1_$2").toUpperCase(Locale.ROOT).split("_+");
        List<String> keep = new ArrayList<>();
        String dev = device == null ? "" : device.toUpperCase(Locale.ROOT);
        for (String t : all) if (dev.isEmpty() || t.length() < 3 || !dev.startsWith(t)) keep.add(t);
        if (keep.isEmpty()) keep.addAll(java.util.Arrays.asList(all));
        String[] toks = keep.toArray(new String[0]);
        for (String[] t : TAGS)
            for (int i = 1; i < t.length; i++)
                for (String tok : toks)
                    if (tok.equals(t[i]) && !out.contains(t[0])) out.add(t[0]);
        return out;
    }

    /** Numeric constants the subsystem uses (directly in its code, or in a config class named like it: Config.Indexer). */
    private void constants(Sub s) {
        Set<FieldInfo> seen = new LinkedHashSet<>();
        for (Hit h : Walk.find(s.cls, t -> t instanceof MemberSelectTree || t instanceof IdentifierTree)) {
            String d = JavaIndex.dotted((ExpressionTree) h.leaf());
            if (d == null) continue;
            FieldInfo f = staticField(d, s.cls);
            if (f != null) seen.add(f);
        }
        for (ClassInfo c : ix.classes()) {
            if (c.outer != null && c.simple.equals(s.cls.simple) && c != s.cls) seen.addAll(c.fields.values());
        }
        for (FieldInfo f : seen) {
            if (!f.isStatic) continue;
            Val v = ev.fieldValue(f, 0);
            if (v == null || !(v.isNum() || v.kind == Val.K.BOOL)) continue;
            s.constants.add(Json.obj("ref", f.owner.ref() + "." + f.name, "import", f.owner.importName(), "value", v.isNum() ? (Object) v.num : (Object) v.bool,
                    "tags", tags(f.name), "final", f.isFinal, "file", f.owner.src.path, "line", f.line));
        }
    }

    private FieldInfo staticField(String dotted, ClassInfo ctx) {
        int i = dotted.lastIndexOf('.');
        if (i < 0) {
            FieldInfo f = ix.field(ctx, dotted);
            return f != null && f.isStatic ? f : null;
        }
        ClassInfo c = ix.resolveType(dotted.substring(0, i), ctx);
        if (c == null) return null;
        FieldInfo f = c.fields.get(dotted.substring(i + 1));
        return f != null && f.isStatic ? f : null;
    }

    /** Per servo: which constant opens / closes it (from the tags of the constants it is set to), and its init position. */
    private void servoStates(Sub s) {
        for (Device d : s.devices) {
            if (!"servo".equals(d.kind)) continue;
            Map<String, Object> st = new LinkedHashMap<>();
            st.put("device", d.name);
            st.put("field", d.field);
            Map<String, Object> init = null;
            for (Map<String, Object> p : d.positions) {
                Map<String, Object> val = Json.map(p.get("value"));
                if (!"number".equals(val.get("kind"))) continue;
                String ref = (String) val.get("ref");
                String named = ref != null ? ref : (String) val.get("private_ref");
                List<String> tg = named == null ? List.of() : tags(JavaIndex.simpleName(named), d.field);
                for (String t : new String[]{"open", "closed", "up", "down", "push", "idle"})
                    if (tg.contains(t) && !st.containsKey(t))
                        st.put(t, Json.obj("ref", ref, "private_ref", val.get("private_ref"), "value", val.get("value"), "file", p.get("file"), "line", p.get("line"), "confidence", Fact.HIGH,
                                "evidence", JavaIndex.simpleName(named) + " in " + p.get("in")));
                if (Boolean.TRUE.equals(p.get("init")) && init == null) init = Json.obj("ref", ref, "value", val.get("value"), "file", p.get("file"), "line", p.get("line"));
            }
            st.put("init_position", init);
            if (init == null) {
                warnings.add(Json.obj("kind", "servo_not_initialized", "file", d.file, "line", d.line,
                        "message", "Servo \"" + d.name + "\" (" + s.cls.simple + "." + d.field + ") is never given a position when the robot initializes: it keeps whatever position it had."));
            }
            s.servoStates.add(st);
        }
    }

    /** update() / periodic(): required every loop when it drives a motor from a controller or advances a state machine. */
    private void updateRequirement(Sub s) {
        for (Api a : s.api) {
            String n = a.mi.name;
            if (!(n.equals("update") || n.equals("periodic") || n.equals("loop") || n.equals("run") && a.mi.params.isEmpty())) continue;
            String body = a.mi.body.toString();
            List<String> why = new ArrayList<>();
            if (body.contains(".calculate(")) why.add("computes motor power with a controller (calculate)");
            if (body.contains("switch") || body.contains("StateMachine") || body.contains("State")) why.add("advances a state machine");
            boolean writes = false;
            for (Effect e : a.effects) if (e.device != null && (e.op.equals("setPower") || e.op.equals("setVelocity"))) writes = true;
            if (writes) why.add("writes motor power");
            for (Effect e : a.effects) if (e.op.startsWith("call:update") || e.op.startsWith("call:periodic")) why.add("updates " + e.target);
            List<String> ps = new ArrayList<>();
            for (var p : a.mi.params) ps.add(JavaIndex.simpleName(p.getType().toString()));
            boolean required = !why.isEmpty();
            s.update = Json.obj("method", n, "params", ps, "required", required, "evidence", String.join("; ", why), "file", s.cls.src.path, "line", a.mi.line,
                    "confidence", required ? Fact.HIGH : Fact.MEDIUM);
            return;
        }
    }

    /**
     * A method reads an instance field that nothing sets before it is used (no initializer, not set in the constructor),
     * and only another public method sets it: Flywheel.startFlywheel() reads `velocity`, which only
     * setFlywheelParameters(velocity, angle) sets. Calling startFlywheel() first would spin to 0.
     */
    private void preconditions(Sub s) {
        ClassInfo c = s.cls;
        Set<String> setInCtor = new LinkedHashSet<>();
        for (MethodInfo ctor : c.ctors())
            for (Hit h : Walk.find(c, ctor, t -> t instanceof AssignmentTree)) {
                String tg = JavaIndex.dotted(((AssignmentTree) h.leaf()).getVariable());
                if (tg != null) setInCtor.add(tg.startsWith("this.") ? tg.substring(5) : tg);
            }
        for (Api a : s.api) {
            if (!a.mi.isPublic || a.mi.name.startsWith("set") || a.mi.name.startsWith("get") || a.mi.name.startsWith("is") || a.kind.equals("query")) continue;
            // the per-loop update runs with 0 on purpose (target 0 = off): only actions / commands that START something count
            if (s.update != null && a.mi.name.equals(s.update.get("method"))) continue;
            for (String f : a.reads) {
                FieldInfo fi = c.fields.get(f);
                if (fi == null || fi.isStatic || fi.isFinal || fi.init != null || setInCtor.contains(f)) continue;
                String t = JavaIndex.simpleName(fi.type);
                if (!(t.equals("double") || t.equals("int") || t.equals("float") || t.equals("long"))) continue;
                boolean selfAssigns = false;
                for (Effect e : a.effects) if (e.op.equals("assign") && e.target.equals(f)) selfAssigns = true;
                if (selfAssigns) continue;
                List<Map<String, Object>> setters = new ArrayList<>();
                for (Api b : s.api) {
                    if (b == a || !b.mi.isPublic) continue;
                    for (Effect e : b.effects)
                        if (e.op.equals("assign") && e.target.equals(f)) {
                            List<String> ps = new ArrayList<>();
                            for (var p : b.mi.params) ps.add(p.getName().toString());
                            setters.add(Json.obj("method", b.mi.name, "params", ps, "line", b.mi.line, "fallbacks", fallbacks(s, ps)));
                            break;
                        }
                }
                if (setters.isEmpty()) continue;
                s.preconditions.add(Json.obj("method", a.mi.name, "field", f, "default", 0, "setters", setters, "file", c.src.path, "line", a.mi.line,
                        "message", s.cls.simple + "." + a.mi.name + "() uses '" + f + "', which starts at 0 and is only set by " + setters.get(0).get("method") + "(...)."));
            }
        }
    }

    /** For each setter parameter (velocity, angle): a FALLBACK_ / DEFAULT_ constant of the same kind, if the team has one. */
    private List<Object> fallbacks(Sub s, List<String> params) {
        List<Object> out = new ArrayList<>();
        for (String p : params) {
            List<String> pt = tags(p);
            Map<String, Object> best = null;
            for (ClassInfo c : ix.classes()) {
                for (FieldInfo f : c.fields.values()) {
                    if (!f.isStatic) continue;
                    List<String> ft = tags(f.name);
                    if (!ft.contains("fallback")) continue;
                    boolean match = false;
                    for (String t : pt) if (ft.contains(t)) match = true;
                    if (!match && !(c.simple.toLowerCase(Locale.ROOT).contains(p.toLowerCase(Locale.ROOT)))) continue;
                    Val v = ev.fieldValue(f, 0);
                    if (v == null || !v.isNum()) continue;
                    // prefer the config class named like the subsystem (Config.Flywheel.FALLBACK_VELOCITY for Flywheel)
                    int score = (c.simple.equals(s.cls.simple) ? 2 : 0) + (match ? 1 : 0);
                    if (best == null || score > (int) best.get("score"))
                        best = Json.obj("param", p, "ref", c.ref() + "." + f.name, "import", c.importName(), "value", v.num, "score", score, "file", c.src.path, "line", f.line);
                }
            }
            out.add(best);
        }
        return out;
    }

    // ---------------- JSON ----------------

    public List<Object> json() {
        List<Object> out = new ArrayList<>();
        for (Sub s : subs.values()) {
            List<Object> api = new ArrayList<>();
            for (Api a : s.api) api.add(a.json());
            List<String> devs = new ArrayList<>();
            for (Device d : s.devices) devs.add(d.name);
            Map<String, Object> sub = new LinkedHashMap<>();
            for (Map.Entry<String, ClassInfo> e : s.subFields.entrySet()) sub.put(e.getKey(), e.getValue().fqn);
            out.add(Json.obj("class", s.cls.fqn, "ref", s.cls.ref(), "import", s.cls.importName(), "file", s.cls.src.path, "line", s.cls.line,
                    "role", Fact.of(s.role, s.cls.src.path, s.cls.line, s.roleConfidence, s.roleEvidence),
                    "devices", devs, "subsystem_fields", sub, "api", api, "constants", s.constants, "servos", s.servoStates,
                    "update", s.update, "preconditions", s.preconditions, "framework_subsystem", ix.isA(s.cls, "SubsystemBase", "Subsystem"),
                    "speed_setters", speedSetters(s)));
        }
        return out;
    }

    /** "setTargetVelocity(Config.SHOOT_VEL)" inside the method: a non-zero literal or a constant, not a field / parameter. */
    private static String fixedSpeed(Api a, ClassInfo c) {
        if (a.mi.body == null) return null;
        // target = Consts.SHOOT_VELOCITY; / target = 2000; (a field of the class, set to a constant)
        java.util.regex.Matcher as = java.util.regex.Pattern.compile("(?<![\\w.])(?:this\\.)?(\\w+)\\s*=\\s*(-?[0-9.]+[dDfF]?|[A-Z]\\w*(?:\\.[A-Za-z_]\\w*)+|[A-Z_][A-Z0-9_]+)\\s*[;),]").matcher(a.mi.body.toString());
        while (as.find()) {
            String v = as.group(2);
            if (!c.fields.containsKey(as.group(1)) || c.fields.get(as.group(1)).isStatic) continue;
            if (v.matches("-?[0-9.]+[dDfF]?") && Double.parseDouble(v.replaceAll("[dDfF]$", "")) == 0) continue;
            return as.group(1) + " = " + v;
        }
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b(set\\w*(?:Velocity|Power|Speed|RPM|Params|Parameters)\\w*)\\(\\s*([^,()]+)").matcher(a.mi.body.toString());
        while (m.find()) {
            String arg = m.group(2).trim();
            boolean constant = arg.matches("-?[0-9.]+[dDfF]?") ? Double.parseDouble(arg.replaceAll("[dDfF]$", "")) != 0 : arg.matches("[A-Z]\\w*(\\.\\w+)+|[A-Z_][A-Z0-9_]+");
            if (constant) return m.group(0) + ")";
        }
        return null;
    }

    /**
     * How the team sets the flywheel speed: public methods of a flywheel subsystem with a velocity / power / speed
     * parameter that the method stores or passes on (setTargetVelocity(velocity), setFlywheelParameters(velocity, angle)).
     * BEE's "test shots" scale exactly these arguments.
     */
    private List<Object> speedSetters(Sub s) {
        List<Object> out = new ArrayList<>();
        if (!"flywheel".equals(s.role)) return out;
        for (Api a : s.api) {
            if (!a.mi.isPublic || a.mi.isStatic) continue;
            for (int i = 0; i < a.mi.params.size(); i++) {
                String pn = a.mi.params.get(i).getName().toString();
                String low = pn.toLowerCase(Locale.ROOT);
                boolean speed = tags(pn).contains("velocity") || tags(pn).contains("power") || low.contains("vel") || low.contains("speed") || low.contains("rpm");
                if (!speed) continue;
                String body = a.mi.body == null ? "" : a.mi.body.toString();
                if (!java.util.regex.Pattern.compile("\\b" + pn + "\\b").matcher(body).find()) continue;
                out.add(Json.obj("method", a.mi.name, "param", pn, "index", i, "params", a.mi.params.size(), "line", a.mi.line));
            }
        }
        return out;
    }

    public Object wrapperJson() {
        if (wrapper == null) return null;
        Map<String, Object> sub = new LinkedHashMap<>();
        for (Map.Entry<String, ClassInfo> e : wrapper.subsystems.entrySet()) sub.put(e.getKey(), e.getValue().fqn);
        List<String> ctorParams = new ArrayList<>();
        if (wrapper.ctor != null) for (var p : wrapper.ctor.params) ctorParams.add(JavaIndex.simpleName(p.getType().toString()) + " " + p.getName());
        return Json.obj("class", wrapper.cls.fqn, "ref", wrapper.cls.ref(), "import", wrapper.cls.importName(), "file", wrapper.cls.src.path, "line", wrapper.cls.line,
                "subsystems", sub, "follower_field", wrapper.followerField, "hubs_field", wrapper.hubsField, "ctor_params", ctorParams,
                "update", wrapper.update == null ? null : Json.obj("method", wrapper.update.name, "params", paramTypes(wrapper.update), "calls", wrapper.updateCalls,
                        "calls_follower_update", wrapper.updateCallsFollower, "line", wrapper.update.line));
    }

    static List<String> paramTypes(MethodInfo m) {
        List<String> out = new ArrayList<>();
        for (var p : m.params) out.add(JavaIndex.simpleName(p.getType().toString()));
        return out;
    }

    /** NewClassTree helper used by others: is `t` a `new X(...)` of a subsystem class? */
    public Sub subOfNew(Tree t, ClassInfo ctx) {
        if (!(t instanceof NewClassTree)) return null;
        ClassInfo c = ix.resolveType(((NewClassTree) t).getIdentifier().toString(), ctx);
        return c == null ? null : subs.get(c);
    }
}
