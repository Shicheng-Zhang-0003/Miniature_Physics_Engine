package org.beesim.team.gen;

import org.beesim.team.Json;
import org.beesim.team.PedroApi;
import org.beesim.team.Version;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * robot model + answers + BEE path -> one autonomous OpMode that REUSES the team's code:
 *   1. the team's Robot wrapper (robot.shootAll(), robot.update(pose)), else its subsystems, else the hardware
 *      exactly as the team configures it;
 *   2. the team's framework for sequences (RR Actions / FTCLib commands / a plain step runner);
 *   3. the team's per-loop order (bulk cache clear, updates, runner), plus every update() the robot needs;
 *   4. the team's Pedro constants and factory (never a second Constants class), through a version adapter;
 *   5. BEE's path placed on the field from the team's start pose, with timeouts from distance and max velocity.
 * Anything it cannot do correctly is an error (no file), never a guess.
 */
public final class Generator {

    public static final class Result {
        public final Map<String, String> files = new LinkedHashMap<>();
        public final List<String> errors = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public final List<String> assumptions = new ArrayList<>();
        public final List<String> teamUsed = new ArrayList<>();
        public final List<String> notCopied = new ArrayList<>();
        public final Map<String, Object> facts = new LinkedHashMap<>();

        public boolean ok() { return errors.isEmpty(); }

        public Map<String, Object> report() {
            return Json.obj("ok", ok(), "files", new ArrayList<>(files.keySet()), "errors", errors, "warnings", warnings, "assumptions", assumptions,
                    "team_code_used", teamUsed, "team_bugs_not_copied", notCopied, "facts", facts);
        }
    }

    private final Map<String, Object> m;
    private final Map<String, Object> answers = new LinkedHashMap<>();
    private final Map<String, Object> path;
    private final Result r = new Result();
    private final Set<String> imports = new TreeSet<>();
    private PedroAdapter pedro;
    private Paradigm par;
    private String robotVar, follower, runnerList = "runningActions", startExpr, startDesc;
    private Map<String, Object> wrapper, scoring;
    private int capacity = -1;
    private double vmax;
    private final List<String> pathFields = new ArrayList<>();
    private final List<String> pathInit = new ArrayList<>();
    private final List<String> deviceFields = new ArrayList<>();
    private final List<String> deviceInit = new ArrayList<>();
    private final Set<String> declaredDevices = new LinkedHashSet<>();
    private int pathN = 0;
    private double testScale = 0;  // test shots: the flywheel speeds are multiplied by this (0 = real shots)

    private Generator(Map<String, Object> model, Map<String, Object> answers, Map<String, Object> path) {
        this.m = model;
        this.path = path;
        if (answers != null) this.answers.putAll(answers);
    }

    public static Result generate(Map<String, Object> model, Map<String, Object> answers, Map<String, Object> path) {
        Generator g = new Generator(model, answers, path);
        try {
            g.run();
        } catch (RuntimeException e) {
            g.r.errors.add("Internal error while generating: " + e);
        }
        if (!g.r.ok()) g.r.files.clear();
        return g.r;
    }

    // =====================================================================================

    private void run() {
        // every reason the export cannot happen is reported together, not one at a time
        String sm = Json.str(answers.get("shot_mode"), "real");
        if (sm.startsWith("test_")) testScale = Integer.parseInt(sm.substring(5)) / 100.0;
        pedroOk();
        paradigmOk();
        answersOk();
        boolean mirror = "yes".equals(answer("mirror_path"));
        Program prog = Program.of(mirror ? mirrored(path) : path);
        if (mirror) r.assumptions.add("The BEE path is mirrored left ↔ right (you chose it): every point's left offset and heading change sign.");
        r.errors.addAll(prog.errors);
        if (!r.ok()) return;
        if ("yes".equals(answer("intake_between_shots"))) intakeBetweenShots(prog);
        wrapper = Json.map(m.get("robot_wrapper")).isEmpty() ? null : Json.map(m.get("robot_wrapper"));
        scoring = Json.map(m.get("scoring")).isEmpty() ? null : Json.map(m.get("scoring"));
        Object cap = Json.map(Json.map(m.get("game_limits")).get("capacity")).get("value");
        if (cap != null) capacity = (int) Json.num(cap, -1);
        follower();
        startPose();
        checkStartSide();
        checkInsideField(prog, mirror);
        checkShotPlaces(prog);
        maxVelocity();
        if (!r.ok()) return;
        for (Object b : Json.list(m.get("team_bugs"))) r.notCopied.add(Json.str(Json.map(b).get("message"), "") + " (" + Json.map(b).get("file") + ":" + Json.map(b).get("line") + ")");

        // the program, in the team's paradigm
        List<String> items = new ArrayList<>();
        for (Program.Step s : prog.steps) {
            String e = step(s, "        ");
            if (e != null) items.add(e);
        }
        if (!r.ok()) return;
        String root = par.seq(items, "        ");
        String cls = className();
        String pkg = pkg();
        if (!r.ok()) return;
        String java = assemble(pkg, cls, root, prog);
        if (!r.ok()) return;
        r.files.put(pkg.replace('.', '/') + "/" + cls + ".java", java);
        r.facts.put("class", pkg + "." + cls);
        r.facts.put("pedro_adapter", pedro.label());
        r.facts.put("paradigm", par.name());
    }

    /**
     * Between two shots, when the path says nothing about the intake (every point "keep"), the robot is collecting:
     * intake on right after a shot, off right before the next one — what the team's own autos do.
     */
    private void intakeBetweenShots(Program prog) {
        List<Program.Step> st = prog.steps;
        List<Integer> shots = new ArrayList<>();
        for (int i = 0; i < st.size(); i++) if (st.get(i) instanceof Program.Shoot) shots.add(i);
        int added = 0;
        for (int k = shots.size() - 1; k > 0; k--) {
            int a = shots.get(k - 1), b = shots.get(k);
            boolean explicit = false, drives = false;
            for (int i = a + 1; i < b; i++) {
                if (st.get(i) instanceof Program.Intake || st.get(i) instanceof Program.Together) explicit = true;
                if (st.get(i) instanceof Program.Drive) drives = true;
            }
            if (explicit || !drives) continue;
            Program.Intake off = new Program.Intake();
            off.on = false;
            off.label = "intake off (before shooting)";
            Program.Intake on = new Program.Intake();
            on.on = true;
            on.label = "intake on (collecting after the shot)";
            st.add(b, off);
            st.add(a + 1, on);
            added++;
        }
        if (added > 0) r.assumptions.add("Your path never sets the intake between shots: it runs from each shot to the next one (" + added + " time" + (added == 1 ? "" : "s") + "), as your autos do.");
    }

    // ---------------- Pedro ----------------

    private boolean pedroOk() {
        Map<String, Object> p = Json.map(m.get("pedro"));
        String st = Json.str(p.get("status"), "absent");
        switch (st) {
            case "absent": {
                StringBuilder sb = new StringBuilder("Your project does not use Pedro Pathing, so BEE cannot export a Pedro autonomous for it. Add one of these to TeamCode/build.gradle (or build.dependencies.gradle), sync Gradle, tune Pedro, then import the project again:");
                for (Object o : Json.list(p.get("gradle_to_add"))) {
                    Map<String, Object> g = Json.map(o);
                    sb.append("\n  Pedro ").append(g.get("version")).append(": repositories { ").append(String.join("; ", strs(g.get("repositories")))).append(" }  dependencies { ")
                            .append(String.join("; ", strs(g.get("dependencies")))).append(" }");
                }
                r.errors.add(sb.toString());
                return false;
            }
            case "unsupported":
                r.errors.add(Json.str(p.get("message"), "This Pedro Pathing version is not supported."));
                return false;
            case "needs_confirmation":
                if (!"yes".equals(answer("pedro_api_version"))) {
                    r.errors.add(Json.str(p.get("message"), "") + " Answer the question in BEE to continue.");
                    return false;
                }
                r.assumptions.add("Your Pedro " + p.get("version") + " is not verified; you accepted the verified " + p.get("api_version") + " API.");
                break;
            default:
                break;
        }
        pedro = PedroAdapter.forVersion(Json.str(p.get("api_version"), ""));
        if (pedro == null) {
            r.errors.add("No adapter for Pedro Pathing " + p.get("api_version") + ".");
            return false;
        }
        List<String> missing = pedro.check();
        if (!missing.isEmpty()) {
            r.errors.add("Pedro Pathing " + pedro.version() + " does not have what the export needs: " + String.join(", ", missing) + ".");
            return false;
        }
        if (p.get("constants") == null) {
            // no constants class in the project: write one, in this version's exact format (never when the team has one)
            String pkg = teamcodeRoot() + ".pedroPathing";
            ConstantsWriter cw = new ConstantsWriter(PedroApi.load(pedro.version()), Json.map(m.get("garage")));
            String java = cw.write(pkg);
            if (!cw.errors.isEmpty() || java == null) {
                r.errors.addAll(cw.errors);
                return false;
            }
            r.files.put(pkg.replace('.', '/') + "/Constants.java", java);
            boolean v3 = pedro.version().startsWith("3");
            String fn = v3 ? ConstantsWriter.FACTORY_3 : ConstantsWriter.FACTORY_2;
            p.put("constants", Json.obj("class", pkg + ".Constants", "ref", "Constants", "import", pkg + ".Constants", "package", pkg, "generated", true,
                    "factory", Json.obj("name", fn, "params", List.of("HardwareMap"), "call", "Constants." + fn + "(hardwareMap)", "line", 0), "values", Json.obj()));
            r.warnings.add("Your project had no Pedro constants: BEE wrote " + pkg + ".Constants in the Pedro " + pedro.version() + " format from the Garage robot. They are NOT tuned — run Pedro's tuners before trusting this autonomous.");
            for (String n : cw.notes) r.assumptions.add("Constants: " + n);
        }
        r.facts.put("pedro_version", p.get("version"));
        r.facts.put("pedro_api_verified", pedro.version());
        return true;
    }

    // ---------------- questions ----------------

    private boolean answersOk() {
        // the alliance follows from the chosen start pose when the team's auto that starts there sets it
        if (answer("alliance") == null && answer("start_pose") != null) {
            for (Object o : Json.list(m.get("start_poses"))) {
                Map<String, Object> p = Json.map(o);
                if (answer("start_pose").equals(p.get("ref")) && p.get("alliance") != null) {
                    answers.put("alliance", p.get("alliance"));
                    r.assumptions.add("Alliance " + p.get("alliance") + ", from the start pose " + p.get("ref") + " (" + p.get("alliance_evidence") + ").");
                }
            }
        }
        for (Object o : Json.list(m.get("questions"))) {
            Map<String, Object> q = Json.map(o);
            String id = (String) q.get("id");
            if (answers.containsKey(id)) continue;
            if (q.get("default") != null) {
                answers.put(id, q.get("default"));
                r.assumptions.add("Not answered, used the default \"" + q.get("default") + "\": " + q.get("prompt"));
            } else if (Boolean.TRUE.equals(q.get("required"))) {
                r.errors.add("Answer this in BEE before exporting: " + q.get("prompt"));
            }
        }
        return r.ok();
    }

    private String answer(String id) {
        Object a = answers.get(id);
        return a == null ? null : a.toString();
    }

    // ---------------- paradigm, follower, start pose ----------------

    private boolean paradigmOk() {
        String p = Json.str(Json.map(m.get("paradigm")).get("value"), "plain");
        if (p.equals("mixed")) p = Json.str(answer("paradigm"), "rr_actions");
        Map<String, Object> pw = Json.map(m.get("robot_wrapper"));
        if (pedro == null) {
            // still tell about the framework, so every problem is listed at once
            if ("nextftc".equals(p)) r.errors.add("Your robot uses NextFTC. BEE's team export does not support NextFTC commands yet, and it will not mix in another framework. Use the BASIC export, or the AI prompt.");
            return false;
        }
        String fol = !pw.isEmpty() && pw.get("follower_field") != null ? Json.str(robotVarName(), "robot") + "." + pw.get("follower_field") : "follower";
        switch (p) {
            case "rr_actions": par = new Paradigms.RrActions(pedro, fol); break;
            case "ftclib_commands": {
                Map<String, Object> libs = Json.map(m.get("libraries"));
                String pkg = libs.keySet().stream().anyMatch(k -> k.startsWith("solverslib")) ? "com.seattlesolvers.solverslib.command" : "com.arcrobotics.ftclib.command";
                par = new Paradigms.Commands(pedro, fol, pkg);
                break;
            }
            case "nextftc":
                r.errors.add("Your robot uses NextFTC. BEE's team export does not support NextFTC commands yet, and it will not mix in another framework. Use the BASIC export, or the AI prompt.");
                return false;
            default: par = new Paradigms.Plain(pedro, fol, Json.map(m.get("team_actions")));
        }
        imports.addAll(par.imports());
        // the list the team's own runner takes (ActionRunner.tick(actions, packet)): same name, so that call is reused as is
        List<Object> rargs = Json.list(Json.map(m.get("runner")).get("args"));
        if (par instanceof Paradigms.RrActions && !rargs.isEmpty()) runnerList = rargs.get(0).toString();
        else if (par instanceof Paradigms.Commands) runnerList = "autonomousCommand";
        else if (par instanceof Paradigms.Plain) runnerList = "autonomousSteps";
        return true;
    }

    private String robotVarName() {
        Map<String, Object> loop = Json.map(m.get("loop"));
        for (Object o : Json.list(m.get("opmodes"))) {
            Map<String, Object> om = Json.map(o);
            if (Boolean.TRUE.equals(om.get("reference")) && om.get("robot_var") != null) return (String) om.get("robot_var");
        }
        return loop.isEmpty() ? "robot" : "robot";
    }

    private void follower() {
        robotVar = robotVarName();
        Map<String, Object> consts = Json.map(Json.map(m.get("pedro")).get("constants"));
        if (wrapper != null) {
            imports.add((String) wrapper.get("import"));
            r.teamUsed.add(wrapper.get("ref") + " (" + wrapper.get("file") + ")  — the robot: subsystems" + (wrapper.get("follower_field") != null ? " and the follower" : ""));
            if (wrapper.get("follower_field") != null) {
                follower = robotVar + "." + wrapper.get("follower_field");
                r.teamUsed.add(wrapper.get("ref") + "." + wrapper.get("follower_field") + " — the Follower your Robot creates with " + Json.map(consts.get("factory")).get("call"));
                return;
            }
        }
        follower = "follower";
        Map<String, Object> f = Json.map(consts.get("factory"));
        if (f.isEmpty()) {
            r.errors.add("Your Pedro constants (" + consts.get("class") + ") have no static method that returns a Follower: BEE does not know how your robot creates it.");
            return;
        }
        imports.add((String) consts.get("import"));
        r.teamUsed.add(f.get("call") + " (" + consts.get("file") + ":" + f.get("line") + ") — your Pedro constants and factory");
    }

    private void startPose() {
        String a = answer("start_pose");
        if (a == null) { r.errors.add("Choose the start pose in BEE before exporting."); return; }
        if (a.equals("bee_start")) {
            Map<String, Object> st = Json.map(path.get("start"));
            double x = Json.num(st.get("x_in"), 9), y = Json.num(st.get("y_in"), 72), rot = Math.toRadians(Json.num(st.get("rot_deg"), 0));
            boolean blue = "blue".equals(answer("alliance"));
            if (blue) { x = 144 - x; y = 144 - y; rot += Math.PI; }
            // BEE's map: x right, y DOWN, rotation 0 = facing up the screen. Pedro: x right, y UP, heading 0 = +x.
            double px = x, py = 144 - y, ph = Math.atan2(Math.cos(rot), Math.sin(rot));
            startExpr = pedro.newPose(Gen.num(px), Gen.num(py), Gen.num(ph));
            startDesc = String.format(Locale.ROOT, "BEE start converted: (%.2f, %.2f, %.1f°)", px, py, Math.toDegrees(ph));
            r.assumptions.add("Start pose converted from BEE's map to Pedro field coordinates assuming BEE's map is drawn like Pedro's field diagram (x right, y up). Check it on the field.");
            r.facts.put("start_pose", Json.obj("x", px, "y", py, "heading", ph, "ref", null));
            return;
        }
        for (Object o : Json.list(m.get("start_poses"))) {
            Map<String, Object> p = Json.map(o);
            String id = p.get("ref") != null ? (String) p.get("ref") : "pose@" + p.get("file") + ":" + p.get("line");
            if (!id.equals(a)) continue;
            if (p.get("ref") != null) {
                startExpr = (String) p.get("ref");
                if (p.get("import") != null) imports.add((String) p.get("import"));
            } else {
                startExpr = pedro.newPose(Gen.num((double) p.get("x")), Gen.num((double) p.get("y")), Gen.num((double) p.get("heading")));
            }
            startDesc = String.format(Locale.ROOT, "%s = (%.3f, %.3f, %.1f°)  %s:%s", p.get("name") != null ? p.get("name") : id, (double) p.get("x"), (double) p.get("y"), Math.toDegrees((double) p.get("heading")), p.get("file"), p.get("line"));
            r.facts.put("start_pose", Json.obj("x", p.get("x"), "y", p.get("y"), "heading", p.get("heading"), "ref", p.get("ref")));
            if (answer("alliance") == null && p.get("alliance") != null) answers.put("alliance", p.get("alliance"));
            return;
        }
        r.errors.add("The start pose \"" + a + "\" is not in your code any more. Analyze the project again and choose it again.");
    }

    /** The path mirrored left <-> right: y and headings of the points, move left/right, turns. */
    static Map<String, Object> mirrored(Map<String, Object> p) {
        Map<String, Object> c = Json.map(Json.parse(Json.write(p)));
        for (Object o : Json.list(c.get("points"))) {
            Map<String, Object> pt = Json.map(o);
            pt.put("y", 0.0 - Json.num(pt.get("y"), 0) + 0.0);  // + 0.0: no "-0"
            pt.put("h", 0.0 - Json.num(pt.get("h"), 0) + 0.0);
        }
        mirrorBlocks(Json.list(c.get("blocks")));
        return c;
    }

    private static void mirrorBlocks(List<Object> blocks) {
        for (Object o : blocks) {
            Map<String, Object> b = Json.map(o);
            if ("move".equals(b.get("t"))) {
                String d = Json.str(b.get("dir"), "forward");
                b.put("dir", d.equals("left") ? "right" : d.equals("right") ? "left" : d);
            }
            if ("turn".equals(b.get("t"))) b.put("deg", 0.0 - Json.num(b.get("deg"), 0) + 0.0);
            for (String k : new String[]{"body", "then", "else"}) mirrorBlocks(Json.list(b.get(k)));
        }
    }

    /** Where the drive targets land on the field from a start pose (inches, field coordinates). */
    private static List<double[]> landing(Program prog, double x0, double y0, double h0) {
        List<double[]> out = new ArrayList<>();
        List<Program.Step> all = new ArrayList<>(prog.steps);
        for (int i = 0; i < all.size(); i++) {
            Program.Step st = all.get(i);
            if (st instanceof Program.Together) all.addAll(i + 1, ((Program.Together) st).body);
            if (!(st instanceof Program.Drive)) continue;
            Program.Drive d = (Program.Drive) st;
            double c = Math.cos(h0), s = Math.sin(h0);
            out.add(new double[]{x0 + d.x * c - d.y * s, y0 + d.x * s + d.y * c, d.point});
        }
        return out;
    }

    /**
     * Every drive target must keep the robot inside the 144 in field (from the chosen start, in the team's field
     * coordinates). A path that leaves it is refused, with the starts (as drawn or mirrored) where it does fit.
     */
    private void checkInsideField(Program prog, boolean mirror) {
        Map<String, Object> co = Json.map(m.get("coordinates"));
        if (!"pedro_field".equals(Json.map(co.get("system")).get("value"))) return;
        Map<String, Object> sp = Json.map(r.facts.get("start_pose"));
        if (sp.isEmpty()) return;
        Map<String, Object> g = Json.map(m.get("garage"));
        double half = Math.max(Json.num(g.get("width_in"), 18), Json.num(g.get("length_in"), 18)) / 2.0;
        double lo = half - 1.0, hi = 144 - half + 1.0;  // 1 in of tolerance
        List<String> bad = new ArrayList<>();
        int k = 0;
        for (double[] p : landing(prog, Json.num(sp.get("x"), 0), Json.num(sp.get("y"), 0), Json.num(sp.get("heading"), 0))) {
            k++;
            if (p[0] < lo || p[0] > hi || p[1] < lo || p[1] > hi)
                bad.add(String.format(Locale.ROOT, "%s at (%.0f, %.0f)", p[2] >= 0 ? "point " + (int) (p[2] + 1) : "move #" + k, p[0], p[1]));
        }
        if (bad.isEmpty()) return;
        // where would it fit?
        List<String> fits = new ArrayList<>();
        Program other = Program.of(mirror ? path : mirrored(path));
        for (Object o : Json.list(m.get("start_poses"))) {
            Map<String, Object> p = Json.map(o);
            double x0 = Json.num(p.get("x"), 0), y0 = Json.num(p.get("y"), 0), h0 = Json.num(p.get("heading"), 0);
            String nm = Json.str(p.get("name"), Json.str(p.get("ref"), "pose"));
            for (int v = 0; v < 2; v++) {
                Program pr = v == 0 ? prog : other;
                boolean ok = true;
                for (double[] q : landing(pr, x0, y0, h0)) if (q[0] < lo || q[0] > hi || q[1] < lo || q[1] > hi) ok = false;
                boolean mirroredHere = (v == 1) != mirror;
                if (ok) fits.add(nm + (mirroredHere ? " with the path mirrored" : " as drawn"));
            }
        }
        r.errors.add("From " + Json.str(sp.get("ref"), "this start") + " the path leaves the field (the robot is " + Gen.num(2 * half) + " in wide): " + String.join(", ", bad)
                + ". The robot would drive into the wall. " + (fits.isEmpty() ? "It does not fit from any of your start poses: change the path in BEE."
                : "It fits from: " + String.join("; ", fits) + ". Choose that start (and \"Mirror the BEE path\" if needed) in the panel, or change the path."));
    }

    /** A shot far from every place the team's own autos shoot from: maybe not a legal / tested spot (BEE does not know the game's zones). */
    private void checkShotPlaces(Program prog) {
        List<Object> shooting = Json.list(m.get("shooting_poses"));
        Map<String, Object> sp = Json.map(r.facts.get("start_pose"));
        if (shooting.isEmpty() || sp.isEmpty()) return;
        double x0 = Json.num(sp.get("x"), 0), y0 = Json.num(sp.get("y"), 0), h0 = Json.num(sp.get("heading"), 0);
        double cx = x0, cy = y0;
        int n = 0;
        for (Program.Step st : prog.steps) {
            if (st instanceof Program.Drive) {
                Program.Drive d = (Program.Drive) st;
                cx = x0 + d.x * Math.cos(h0) - d.y * Math.sin(h0);
                cy = y0 + d.x * Math.sin(h0) + d.y * Math.cos(h0);
            }
            if (!(st instanceof Program.Shoot)) continue;
            n++;
            double best = Double.MAX_VALUE;
            String near = null;
            for (Object o : shooting) {
                Map<String, Object> p = Json.map(o);
                double dd = Math.hypot(Json.num(p.get("x"), 0) - cx, Json.num(p.get("y"), 0) - cy);
                if (dd < best) { best = dd; near = Json.str(p.get("name"), "?") + String.format(Locale.ROOT, " (%.0f, %.0f)", Json.num(p.get("x"), 0), Json.num(p.get("y"), 0)); }
            }
            if (best > 24)
                r.warnings.add(String.format(Locale.ROOT, "Shot %d is at (%.0f, %.0f), %.0f in from where your autos shoot (nearest: %s). Check that the rules allow shooting there and that your shooter is tuned for that distance.", n, cx, cy, best, near));
        }
    }

    /**
     * The start pose and the alliance must agree with the team's own field: its red poses and blue poses sit on two
     * halves. A start on the other alliance's half (or an alliance that differs from the Garage robot) is reported.
     */
    private void checkStartSide() {
        Map<String, Object> sp = Json.map(r.facts.get("start_pose"));
        String al = answer("alliance");
        if (sp.isEmpty() || al == null) return;
        double sx = Json.num(sp.get("x"), 0), sy = Json.num(sp.get("y"), 0);
        double[] sum = new double[4];  // red x, red n, blue x, blue n
        for (Object o : Json.list(m.get("start_poses"))) {
            Map<String, Object> p = Json.map(o);
            if ("red".equals(p.get("alliance"))) { sum[0] += Json.num(p.get("x"), 0); sum[1]++; }
            if ("blue".equals(p.get("alliance"))) { sum[2] += Json.num(p.get("x"), 0); sum[3]++; }
        }
        if (sum[1] > 0 && sum[3] > 0) {
            double red = sum[0] / sum[1], blue = sum[2] / sum[3];
            String side = Math.abs(sx - red) < Math.abs(sx - blue) ? "red" : "blue";
            if (!side.equals(al))
                r.warnings.add(String.format(Locale.ROOT, "The start (%.1f, %.1f) is on the %s half of your field (your red poses are around x = %.0f, blue around x = %.0f), but the alliance is %s: "
                        + "the robot would aim at the %s goal from the wrong side. Pick one of your own start poses, or the other alliance.", sx, sy, side, red, blue, al, al));
        }
        Object ga = Json.map(m.get("garage")).get("alliance");
        if (ga != null && !ga.equals(al))
            r.warnings.add("The alliance is " + al + " but your Garage robot is " + ga + ". Check that this is the alliance you want.");
    }

    private double accel;

    private void maxVelocity() {
        Map<String, Object> vals = Json.map(Json.map(Json.map(m.get("pedro")).get("constants")).get("values"));
        for (String k : new String[]{"FollowerConstants.forwardZeroPowerAcceleration", "ForesightConfig.naturalForwardDeceleration"}) {
            Map<String, Object> v = Json.map(vals.get(k));
            if (v.get("value") instanceof Number && Math.abs(Json.num(v.get("value"), 0)) > 5) {
                accel = Math.abs(Json.num(v.get("value"), 0));
                r.facts.put("acceleration", Json.obj("value", accel, "from", k));
                break;
            }
        }
        for (String k : new String[]{"MecanumConstants.xVelocity", "ForesightConfig.maxAchievableForwardVelocity"}) {
            Map<String, Object> v = Json.map(vals.get(k));
            if (v.get("value") instanceof Number && Json.num(v.get("value"), 0) > 5) {
                vmax = Json.num(v.get("value"), 0);
                r.facts.put("max_velocity", Json.obj("value", vmax, "from", k));
                return;
            }
        }
        double garageV = Json.num(Json.map(m.get("garage")).get("max_speed_in_s"), 0);
        vmax = garageV > 5 ? garageV : 30;
        r.assumptions.add("Your Pedro constants have no measured max velocity: path time limits use " + Gen.num(vmax) + " in/s"
                + (garageV > 5 ? " from the Garage" : "") + ". Run Pedro's velocity tuner and re-export.");
    }

    /**
     * Path time limit from the distance and YOUR measured robot: the time of a trapezoid profile with the max velocity
     * (xVelocity, scaled by the path's power) and the measured zero-power deceleration as acceleration, x1.5,
     * + 1 s to settle + 1 s per 180° of turning.
     */
    private double timeout(double dist, double dhDeg, double power) {
        double v = vmax * Math.max(0.1, power);
        double a = accel > 0 ? accel : vmax;  // unknown: reach the top speed in about 1 s
        if (accel <= 0 && !r.assumptions.contains(ACCEL_NOTE)) r.assumptions.add(ACCEL_NOTE);
        double move = dist < v * v / a ? 2 * Math.sqrt(dist / a) : dist / v + v / a;
        double t = 1.5 * move + 1.0 + Math.abs(dhDeg) / 180.0;
        return Math.ceil(t * 10) / 10.0;
    }

    private static final String ACCEL_NOTE = "No measured acceleration in your Pedro constants: path time limits assume the robot reaches top speed in about 1 s.";

    // ---------------- steps ----------------

    private String step(Program.Step s, String ind) {
        if (s instanceof Program.Drive) {
            Program.Drive d = (Program.Drive) s;
            String name = "path" + (++pathN);
            pathFields.add("private " + pedro.pathType() + " " + name + ";  // " + d.label + ": " + Gen.num(d.dist) + " in");
            String a = "rel(" + Gen.num(d.x0) + ", " + Gen.num(d.y0) + ", " + Gen.num(d.h0) + ")";
            String b = "rel(" + Gen.num(d.x) + ", " + Gen.num(d.y) + ", " + Gen.num(d.h) + ")";
            pathInit.add(name + " = " + pedro.line(follower, a, b, d.headingMode) + ";");
            double t = timeout(d.dist, d.dh, d.maxPower);
            if (d.maxPower < 0.999 && !pedro.supportsMaxPower())
                r.warnings.add(d.label + ": speed " + Gen.num(d.maxPower) + " is not applied — " + pedro.label() + " has no max-power argument for follow().");
            return par.follow(name, Gen.num(t), d.maxPower, d.label);
        }
        if (s instanceof Program.Turn) {
            Program.Turn t = (Program.Turn) s;
            return par.turn("startHeading + Math.toRadians(" + Gen.num(t.h) + ")", Gen.num(timeout(0, t.dh, 1)), t.label);
        }
        if (s instanceof Program.Wait) return par.sleep(((Program.Wait) s).s, null, 1);
        if (s instanceof Program.Intake) return intake(((Program.Intake) s).on);
        if (s instanceof Program.Shoot) return shoot(((Program.Shoot) s).n, ind);
        if (s instanceof Program.Together) {
            Program.Together tg = (Program.Together) s;
            List<String> items = new ArrayList<>(), racing = new ArrayList<>();
            for (Program.Step b : tg.body) {
                String e = step(b, ind + "    ");
                // ANY: the intake on/off is done at once, so it does not end the block (as in the BASIC code)
                if (e != null) (tg.any && !(b instanceof Program.Intake) ? racing : items).add(e);
            }
            if (!racing.isEmpty()) items.add(par.race(racing, ind + "    "));
            return par.par(items, ind);
        }
        r.errors.add("Unsupported step " + s.label);
        return null;
    }

    private String intake(boolean on) {
        Map<String, Object> it = Json.map(Json.map(m.get("intake")).get(on ? "on" : "off"));
        if (it.isEmpty()) {
            r.errors.add("The autonomous turns the intake " + (on ? "on" : "off") + ", but none of your autonomous OpModes does that, so BEE does not know your intake call. "
                    + "Add it to one of your autos (e.g. robot.intake.setPower(...)) and analyze again.");
            return null;
        }
        String call = withRobot((String) it.get("call"));
        if (it.get("device") != null && device((String) it.get("device"), (String) it.get("field")) == null) return null;
        if (it.get("import") != null) imports.add((String) it.get("import"));
        r.teamUsed.add(call + "  — intake " + (on ? "on" : "off") + ", as in your auto (" + it.get("file") + ":" + it.get("line") + ")");
        importsFor(call);
        return par.instant(call + ";");
    }

    private String withRobot(String s) { return s.replace("{robot}", robotVar); }

    // ---------------- shooting ----------------

    @SuppressWarnings("unchecked")
    private String shoot(int n, String ind) {
        if (scoring == null) {
            r.errors.add("The autonomous shoots, but BEE found no scoring code in your project (a method like shootAll() / shoot() used by an autonomous). Add one and analyze again.");
            return null;
        }
        int k = n;
        if (capacity > 0 && n > capacity) {
            r.warnings.add("\"shoot " + n + "\" was clamped to " + capacity + ": your robot holds " + capacity + " (" + Json.map(Json.map(m.get("game_limits")).get("capacity")).get("evidence") + ").");
            k = capacity;
        }
        List<Object> seq = Json.list(scoring.get("sequence"));
        Map<String, Object> def = Json.map(scoring.get("defined_in"));
        String kind = Json.str(def.get("kind"), "sync");
        String core;
        if (capacity > 0 && k < capacity && !seq.isEmpty()) {
            List<Object> part = partial(seq, k);
            core = sequence(part, ind);
            r.teamUsed.add("The first " + k + " of the " + capacity + " gates of " + withRobot((String) scoring.get("call")) + ", in the same order and with the same delays");
        } else if (testScale > 0 && !seq.isEmpty() && (setsSpeedInSequence(seq) || fixedSpeedIn(seq) != null)) {
            // test shots: the team's sequence sets the speed itself -> run its steps, with the speed scaled
            String fixed = fixedSpeedIn(seq);
            if (fixed != null) {
                r.errors.add("Test shots are not possible: " + fixed + " sets a fixed flywheel speed inside your code, so BEE cannot slow it without changing your code. Export real shots, or make that speed a parameter / field.");
                return null;
            }
            core = sequence(seq, ind);
            r.teamUsed.add("The steps of " + withRobot((String) scoring.get("call")) + ", with the flywheel speed scaled for test shots");
        } else if (!def.isEmpty() && kind.equals("team_action")) {
            String call = withRobot((String) scoring.get("call"));
            core = par.teamAction(call);
            if (core == null) {
                r.errors.add(call + " returns one of your own Actions (" + Json.map(m.get("team_actions")).get("ref") + "), which does not fit a " + par.name() + " autonomous.");
                return null;
            }
            if (scoring.get("import") != null) imports.add((String) scoring.get("import"));
            r.teamUsed.add(call + "  — your scoring sequence (" + scoring.get("file") + ":" + scoring.get("line") + (scoring.get("evidence") != null ? "; " + scoring.get("evidence") : "") + ")");
            Map<String, Object> ta = Json.map(m.get("team_actions"));
            r.teamUsed.add(ta.get("ref") + " (" + ta.get("file") + ") — your own Actions, run with " + ta.get("update") + " until " + ta.get("done") + ", like your ActionRunner");
        } else if (!def.isEmpty() && (kind.equals("action") || kind.equals("command"))) {
            if (!par.accepts(kind)) {
                r.errors.add(withRobot((String) scoring.get("call")) + " returns a " + kind + ", which does not fit a " + par.name() + " autonomous.");
                return null;
            }
            String call = withRobot((String) scoring.get("call"));
            core = par.team(call);
            r.teamUsed.add(call + "  — your scoring sequence (" + scoring.get("file") + ":" + scoring.get("line") + ")");
        } else if (!def.isEmpty() && kind.equals("sync")) {
            // a plain method with no waits inside: calling it is the same as doing it
            String call = withRobot((String) scoring.get("call"));
            core = par.instant(call + ";");
            r.teamUsed.add(call + "  — your scoring method (" + scoring.get("file") + ":" + scoring.get("line") + ")");
        } else {
            // a sync / blocking team method: its steps, so the loop keeps running (updates) while it shoots
            core = sequence(seq, ind);
            r.teamUsed.add("The steps of " + withRobot((String) scoring.get("call")) + " (" + scoring.get("file") + ":" + scoring.get("line") + "), run without blocking the loop");
        }
        if (core == null) return null;
        // the team only shoots when e.g. the turret is locked
        List<Object> guard = Json.list(scoring.get("guard"));
        if (!guard.isEmpty()) {
            List<String> g = new ArrayList<>();
            for (Object o : guard) g.add(withRobot(o.toString()));
            String cond = String.join(" && ", g);
            Map<String, Object> to = Json.map(scoring.get("wait_timeout"));
            String timeout = to.get("ref") != null ? (String) to.get("ref") : Gen.num(Json.num(to.get("value"), 2.0));
            if (to.get("import") != null) imports.add((String) to.get("import"));
            if (to.isEmpty()) r.assumptions.add("Waiting at most 2 s for " + cond + " before shooting (no time limit found in your auto).");
            boolean skip = "skip".equals(answer("guard_timeout"));
            r.teamUsed.add("Waits for " + cond + " (at most " + timeout + " s) like your auto, then " + (skip ? "shoots only if it became true" : "shoots"));
            List<String> items = new ArrayList<>();
            items.add(par.waitUntil(cond, timeout));
            items.add(skip ? par.ifThen(cond, core) : core);
            return par.seq(items, ind);
        }
        return core;
    }

    /** A sequence step that passes a speed to a flywheel speed method (needs scaling in test mode). */
    private boolean setsSpeedInSequence(List<Object> seq) {
        for (Object o : seq) {
            Map<String, Object> st = Json.map(o);
            if ("parallel".equals(st.get("op"))) { for (Object b : Json.list(st.get("branches"))) if (setsSpeedInSequence(Json.list(b))) return true; continue; }
            if (!"call".equals(st.get("op"))) continue;
            if (st.get("device") != null && ("setVelocity".equals(st.get("method")) || "setPower".equals(st.get("method"))) && speedName(String.valueOf(st.get("device")))) return true;
            for (Object so : speedSettersOf(Json.str(st.get("subsystem"), ""))) if (Json.map(so).get("method").equals(st.get("method"))) return true;
        }
        return false;
    }

    private static boolean speedName(String n) {
        n = n.toLowerCase(Locale.ROOT);
        return n.contains("fly") || n.contains("shoot") || n.contains("launch") || n.contains("outtake") || n.contains("wheel");
    }

    private List<Object> speedSettersOf(String cls) {
        for (Object o : Json.list(m.get("subsystems"))) if (cls.equals(Json.map(o).get("class"))) return Json.list(Json.map(o).get("speed_setters"));
        return List.of();
    }

    /** "Flywheel.spinUp() -> setTargetVelocity(Config.SHOOT)": a method in the sequence that hides a constant speed. */
    private String fixedSpeedIn(List<Object> seq) {
        for (Object o : seq) {
            Map<String, Object> st = Json.map(o);
            if ("parallel".equals(st.get("op"))) { for (Object b : Json.list(st.get("branches"))) { String f = fixedSpeedIn(Json.list(b)); if (f != null) return f; } continue; }
            if (!"call".equals(st.get("op")) || st.get("subsystem") == null) continue;
            for (Object so : Json.list(m.get("subsystems"))) {
                Map<String, Object> s = Json.map(so);
                if (!s.get("class").equals(st.get("subsystem"))) continue;
                for (Object a : Json.list(s.get("api")))
                    if (Json.map(a).get("name").equals(st.get("method")) && Json.map(a).get("fixed_speed") != null)
                        return s.get("ref") + "." + st.get("method") + "() (" + Json.map(a).get("fixed_speed") + ", " + s.get("file") + ":" + Json.map(a).get("line") + ")";
            }
        }
        return null;
    }

    /**
     * The team's sequence with only the first k pieces: everything before the first gate step and after the last stays,
     * gate openings (or kicker pushes) after the k-th are dropped, and each kept opening keeps its closing.
     */
    private List<Object> partial(List<Object> seq, int k) {
        int first = -1, last = -1;
        for (int i = 0; i < seq.size(); i++) if (hasGate(seq.get(i))) { if (first < 0) first = i; last = i; }
        List<Object> out = new ArrayList<>();
        int[] count = {0};
        Set<String> open = new LinkedHashSet<>();
        boolean doneK = false;
        for (int i = 0; i < seq.size(); i++) {
            Object st = seq.get(i);
            if (i < first || i > last) { out.add(st); continue; }
            if (doneK) continue;
            Object f = filterGates(st, count, open, k);
            if (f != null) out.add(f);
            if (count[0] >= k && open.isEmpty()) doneK = true;
        }
        return out;
    }

    private static boolean hasGate(Object o) {
        Map<String, Object> st = Json.map(o);
        if ("parallel".equals(st.get("op"))) {
            for (Object b : Json.list(st.get("branches"))) for (Object x : Json.list(b)) if (hasGate(x)) return true;
            return false;
        }
        return st.get("gate") != null;
    }

    private static Object filterGates(Object o, int[] count, Set<String> open, int k) {
        Map<String, Object> st = Json.map(o);
        if ("parallel".equals(st.get("op"))) {
            List<Object> branches = new ArrayList<>();
            for (Object b : Json.list(st.get("branches"))) {
                List<Object> nb = new ArrayList<>();
                for (Object x : Json.list(b)) {
                    Object f = filterGates(x, count, open, k);
                    if (f != null) nb.add(f);
                }
                if (!nb.isEmpty()) branches.add(nb);
            }
            if (branches.isEmpty()) return null;
            Map<String, Object> c = new LinkedHashMap<>(st);
            c.put("branches", branches);
            return c;
        }
        Map<String, Object> g = Json.map(st.get("gate"));
        if (g.isEmpty()) return o;
        String dev = (String) g.get("device");
        switch (Json.str(g.get("state"), "")) {
            case "open":
                if (count[0] >= k) return null;
                count[0]++;
                open.add(dev);
                return o;
            case "pulse":
                if (count[0] >= k) return null;
                count[0]++;
                return o;
            case "closed":
                return open.remove(dev) ? o : null;
            default:
                return o;
        }
    }

    /** A flattened team sequence -> steps in this paradigm. */
    private String sequence(List<Object> seq, String ind) {
        List<String> items = new ArrayList<>();
        for (Object o : seq) {
            String e = seqStep(Json.map(o), ind + "    ");
            if (e == null) return null;
            items.add(e);
        }
        return par.seq(items, ind);
    }

    private String seqStep(Map<String, Object> st, String ind) {
        String op = Json.str(st.get("op"), "");
        switch (op) {
            case "parallel": {
                List<String> branches = new ArrayList<>();
                for (Object b : Json.list(st.get("branches"))) {
                    List<Object> l = Json.list(b);
                    String e = l.size() == 1 ? seqStep(Json.map(l.get(0)), ind + "    ") : sequence(l, ind + "    ");
                    if (e == null) return null;
                    branches.add(e);
                }
                return par.par(branches, ind);
            }
            case "sleep": {
                if (st.get("seconds") == null) { r.errors.add("Cannot tell how long " + st.get("text") + " waits."); return null; }
                if (st.get("import") != null) imports.add((String) st.get("import"));
                return par.sleep(Json.num(st.get("seconds"), 0), (String) st.get("ref"), Json.num(st.get("scale"), 1));
            }
            case "call": {
                String call = callText(st);
                if (call == null) return null;
                String kind = Json.str(st.get("kind"), "sync");
                if (kind.equals("sync") || st.get("subsystem") == null) return par.instant(call + ";");
                if (!par.accepts(kind)) {
                    r.errors.add(call + " returns a " + kind + ", which does not fit your " + par.name() + " autonomous.");
                    return null;
                }
                return par.team(call);
            }
            default:
                r.errors.add("BEE cannot reuse this part of your scoring code: " + st.get("text") + " (line " + st.get("line") + "). Shoot a full load instead, or simplify the method.");
                return null;
        }
    }

    /** robot.indexer.openServo(1): rebuilt from target + method + argument values (constants by name). */
    private String callText(Map<String, Object> st) {
        String target = (String) st.get("target");
        String cls = Json.str(st.get("class"), "");
        String prefix;
        String viaWrapper = wrapper == null ? null : wrapperPath(cls, target);
        if (wrapper != null && cls.equals(wrapper.get("class"))) prefix = robotVar + "." + target;
        else if (viaWrapper != null) prefix = viaWrapper;
        else if (st.get("device") != null) prefix = device((String) st.get("device"), target);
        else if (target != null && target.contains(".")) prefix = target;
        else {
            r.errors.add("BEE cannot call " + st.get("text") + " from the generated autonomous (it uses '" + target + "' of " + cls + ").");
            return null;
        }
        if (prefix == null) return null;
        List<String> args = new ArrayList<>();
        for (Object o : Json.list(st.get("args"))) {
            Map<String, Object> a = Json.map(o);
            Map<String, Object> v = Json.map(a.get("value"));
            if (v.get("ref") != null) {
                args.add((String) v.get("ref"));
                if (v.get("import") != null) imports.add((String) v.get("import"));
            } else if ("number".equals(v.get("kind"))) {
                double d = Json.num(v.get("value"), 0);
                if (v.get("private_ref") != null) r.assumptions.add(v.get("private_ref") + " is private in your code: the export uses its value " + Gen.num(d) + " (change both if you tune it).");
                args.add(d == Math.rint(d) && Math.abs(d) < 1e9 && !Json.str(a.get("text"), "").contains(".") ? String.valueOf((long) d) : Gen.num(d));
            } else if ("boolean".equals(v.get("kind")) || "string".equals(v.get("kind"))) {
                args.add(v.get("kind").equals("string") ? Gen.q((String) v.get("value")) : String.valueOf(v.get("value")));
            } else {
                r.errors.add("BEE cannot tell the value of '" + a.get("text") + "' in " + st.get("text") + " (line " + st.get("line") + ").");
                return null;
            }
        }
        return scaleSpeed(prefix + "." + st.get("method") + "(" + String.join(", ", args) + ")");
    }

    // ---------------- test shots ----------------

    private final List<String> testNotes = new ArrayList<>();

    /** In test-shot mode, every speed passed to the team's flywheel speed methods (or flywheel motors) is scaled. */
    private String scaleSpeed(String code) {
        if (testScale <= 0) return code;
        String out = code;
        for (Object o : Json.list(m.get("subsystems"))) {
            Map<String, Object> s = Json.map(o);
            List<String> paths = subsystemPaths((String) s.get("class"));
            for (Object so : Json.list(s.get("speed_setters"))) {
                Map<String, Object> st = Json.map(so);
                for (String p : paths) out = scaleArg(out, p + "." + st.get("method"), (int) Json.num(st.get("index"), 0), s.get("ref") + "." + st.get("method") + "(" + st.get("param") + ")");
            }
            if ("flywheel".equals(Json.map(s.get("role")).get("value")))
                for (Object d : Json.list(m.get("hardware"))) {
                    Map<String, Object> h = Json.map(d);
                    if (!s.get("class").equals(h.get("owner_class")) || !"motor".equals(h.get("kind"))) continue;
                    for (String p : paths) for (String fn : new String[]{"setVelocity", "setPower"})
                        out = scaleArg(out, p + "." + h.get("field") + "." + fn, 0, "motor \"" + Json.map(h.get("name")).get("value") + "\"." + fn);
                }
        }
        // teams without subsystems: flywheel motors declared in the generated OpMode
        for (Object d : Json.list(m.get("hardware"))) {
            Map<String, Object> h = Json.map(d);
            String n = String.valueOf(Json.map(h.get("name")).get("value")).toLowerCase(Locale.ROOT) + " " + String.valueOf(h.get("field")).toLowerCase(Locale.ROOT);
            if (!"motor".equals(h.get("kind")) || !(n.contains("fly") || n.contains("shoot") || n.contains("launch") || n.contains("outtake"))) continue;
            if (!declaredDevices.contains(String.valueOf(h.get("field")))) continue;
            for (String fn : new String[]{"setVelocity", "setPower"}) out = scaleArg(out, h.get("field") + "." + fn, 0, "motor \"" + Json.map(h.get("name")).get("value") + "\"." + fn);
        }
        return out;
    }

    /** robot.flywheel / flywheel: how the generated code reaches a subsystem class. */
    private List<String> subsystemPaths(String cls) {
        List<String> out = new ArrayList<>();
        if (wrapper != null) for (Map.Entry<String, Object> e : Json.map(wrapper.get("subsystems")).entrySet()) if (e.getValue().equals(cls)) out.add(robotVar + "." + e.getKey());
        return out;
    }

    /** call(a, b) -> call(a * TEST_SHOT_SCALE, b) for the argument `index` of every call to `callee` in `code`. */
    private String scaleArg(String code, String callee, int index, String what) {
        StringBuilder sb = new StringBuilder();
        int from = 0;
        java.util.regex.Matcher mm = java.util.regex.Pattern.compile("(?<![\\w.])" + java.util.regex.Pattern.quote(callee) + "\\s*\\(").matcher(code);
        while (mm.find(from)) {
            int open = mm.end() - 1, depth = 0, argStart = open + 1, argN = 0, close = -1;
            int[] range = null;
            for (int i = open; i < code.length(); i++) {
                char c = code.charAt(i);
                if (c == '(') depth++;
                else if (c == ')') { depth--; if (depth == 0) { if (argN == index) range = new int[]{argStart, i}; close = i; break; } }
                else if (c == ',' && depth == 1) { if (argN == index) range = new int[]{argStart, i}; argN++; argStart = i + 1; }
            }
            if (close < 0) break;
            if (range == null) { sb.append(code, from, close + 1); from = close + 1; continue; }
            String arg = code.substring(range[0], range[1]).trim();
            boolean simple = arg.matches("[\\w.]+");
            sb.append(code, from, range[0]).append(range[0] > open + 1 ? " " : "").append(simple ? arg : "(" + arg + ")").append(" * TEST_SHOT_SCALE");
            sb.append(code, range[1], close + 1);
            from = close + 1;
            String note = "Scaled: " + what + " (the speed argument)";
            if (!testNotes.contains(note)) testNotes.add(note);
        }
        sb.append(code.substring(from));
        return sb.toString();
    }

    /** robot.launcher.kicker: a public device field of a subsystem the Robot holds (no second hardware handle). */
    private String wrapperPath(String cls, String target) {
        String sub = null;
        for (Map.Entry<String, Object> e : Json.map(wrapper.get("subsystems")).entrySet()) if (e.getValue().equals(cls)) sub = e.getKey();
        if (sub == null) return null;
        for (Object o : Json.list(m.get("hardware"))) {
            Map<String, Object> h = Json.map(o);
            if (cls.equals(h.get("owner_class")) && target.equals(h.get("field")) && Boolean.TRUE.equals(h.get("field_public"))) return robotVar + "." + sub + "." + target;
        }
        return null;
    }

    /** A device used directly (teams without subsystems): declared here and configured exactly like the team does. */
    private String device(String name, String field) {
        if (declaredDevices.contains(field)) return field;
        Map<String, Object> d = null;
        for (Object o : Json.list(m.get("hardware"))) {
            Map<String, Object> h = Json.map(o);
            if (name.equals(Json.map(h.get("name")).get("value"))) d = h;
        }
        if (d == null) { r.errors.add("Device \"" + name + "\" is not in the robot model."); return null; }
        String type = (String) d.get("java_type");
        imports.add("com.qualcomm.robotcore.hardware." + type);
        declaredDevices.add(field);
        deviceFields.add("private " + type + " " + field + ";");
        String nameExpr = d.get("name_ref") != null ? (String) d.get("name_ref") : Gen.q(name);
        if (d.get("name_import") != null) imports.add((String) d.get("name_import"));
        deviceInit.add(field + " = hardwareMap.get(" + type + ".class, " + nameExpr + ");");
        for (Object o : Json.list(d.get("init_calls"))) {
            Map<String, Object> c = Json.map(o);
            if (!Boolean.TRUE.equals(c.get("init"))) continue;
            String v = valueExpr(c.get("value"));
            if (v == null) continue;
            deviceInit.add(field + "." + c.get("method") + "(" + v + ");");
        }
        for (Object o : Json.list(d.get("positions_used"))) {
            Map<String, Object> c = Json.map(o);
            if (!Boolean.TRUE.equals(c.get("init"))) continue;
            String v = valueExpr(c.get("value"));
            if (v != null) { deviceInit.add(field + ".setPosition(" + v + ");"); break; }
        }
        r.teamUsed.add("Device \"" + name + "\" (" + type + ") configured like " + d.get("file") + ":" + Json.map(d.get("name")).get("line"));
        return field;
    }

    private String valueExpr(Object val) {
        Map<String, Object> v = Json.map(val);
        if (v.isEmpty()) return null;
        if (v.get("ref") != null) {
            if (v.get("import") != null) imports.add((String) v.get("import"));
            String ref = (String) v.get("ref");
            if (v.get("import") == null && ref.startsWith("DcMotor")) imports.add("com.qualcomm.robotcore.hardware." + ref.split("\\.")[0]);
            return ref;
        }
        if ("number".equals(v.get("kind"))) {
            if (v.get("private_ref") != null) r.assumptions.add(v.get("private_ref") + " is private in your code: the export uses its value " + Gen.num(Json.num(v.get("value"), 0)) + " (change both if you tune it).");
            return Gen.num(Json.num(v.get("value"), 0));
        }
        if ("boolean".equals(v.get("kind"))) return String.valueOf(v.get("value"));
        if ("enum".equals(v.get("kind"))) return v.get("type") + "." + v.get("value");
        return null;
    }

    // ---------------- loop, init, start ----------------

    private void importsFor(String code) {
        Map<String, Object> loop = Json.map(m.get("loop"));
        for (Object o : Json.list(loop.get("source_imports"))) {
            String imp = o.toString();
            String simple = imp.substring(imp.lastIndexOf('.') + 1);
            if (java.util.regex.Pattern.compile("\\b" + java.util.regex.Pattern.quote(simple) + "\\b").matcher(code).find()) imports.add(imp);
        }
    }

    /** Team code copied with its own line breaks, moved to our indentation (continuation lines keep their offset). */
    private static String reindent(String text, String ind) {
        String[] lines = text.split("\n");
        int min = Integer.MAX_VALUE;
        for (int i = 1; i < lines.length; i++) {
            if (lines[i].isBlank()) continue;
            min = Math.min(min, lines[i].length() - lines[i].stripLeading().length());
        }
        StringBuilder sb = new StringBuilder(ind).append(lines[0].strip());
        for (int i = 1; i < lines.length; i++) {
            String l = lines[i];
            int lead = l.length() - l.stripLeading().length();
            // a closing brace line has the statement's own indentation: everything else is one level deeper
            int base = min == Integer.MAX_VALUE ? lead : min;
            sb.append('\n').append(ind).append(l.isBlank() ? "" : l.substring(Math.min(lead, base)));
        }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private List<String> loopBody(String ind) {
        List<String> L = new ArrayList<>();
        Map<String, Object> loop = Json.map(m.get("loop"));
        List<Object> order = Json.list(loop.get("order"));
        boolean copyLogic = "yes".equals(answer("copy_loop_logic"));
        Set<Integer> logicLines = new LinkedHashSet<>();
        for (Object o : Json.list(Json.map(loop.get("logic")).get("statements"))) logicLines.add((int) Json.num(Json.map(o).get("line"), -1));
        boolean ranRunner = false, bulk = false;
        boolean teamRunner = false;
        for (Object o : order) if ("runner".equals(Json.map(o).get("kind"))) teamRunner = true;
        int lastUpdate = -1;
        Set<String> updated = new LinkedHashSet<>();
        List<String> covered = new ArrayList<>();
        for (Object o : order) {
            Map<String, Object> e = Json.map(o);
            String kind = (String) e.get("kind");
            String text = (String) e.get("text");
            switch (kind) {
                case "bulk_clear":
                    L.add(reindent(text, ind));
                    importsFor(text);
                    bulk = true;
                    covered.add("bulk cache clear: " + text.trim() + " (" + Json.str(e.get("file"), (String) loop.get("file")) + ":" + e.get("line") + ")");
                    break;
                case "runner_support":
                    if (par instanceof Paradigms.RrActions) { L.add(reindent(text, ind)); importsFor(text); }
                    break;
                case "logic":
                    if (copyLogic && logicLines.contains((int) Json.num(e.get("line"), -1))) {
                        L.add(scaleSpeed(reindent(text, ind)));
                        importsFor(text);
                        covered.add("your logic: " + text.split("\n")[0].trim() + "  (" + Json.str(e.get("file"), (String) loop.get("file")) + ":" + e.get("line") + ")");
                    }
                    break;
                case "update":
                    L.add(reindent(text, ind));
                    importsFor(text);
                    lastUpdate = L.size();
                    updated.add(e.get("receiver") + "." + e.get("method"));
                    String via = "";
                    if (wrapper != null && (robotVar + "." + Json.map(wrapper.get("update")).get("method")).equals(e.get("receiver") + "." + e.get("method")))
                        via = "  -> " + String.join(", ", strs(Json.map(wrapper.get("update")).get("calls")));
                    covered.add(text.trim() + via + "  (" + Json.str(e.get("file"), (String) loop.get("file")) + ":" + e.get("line") + ")");
                    break;
                case "runner":
                    if (par instanceof Paradigms.RrActions && !Json.map(e.get("runner")).isEmpty() && Json.list(Json.map(e.get("runner")).get("args")).contains(runnerListName())) {
                        L.add(reindent(text, ind));
                        importsFor(text);
                        Map<String, Object> rn = Json.map(e.get("runner"));
                        if (rn.get("import") != null) imports.add((String) rn.get("import"));
                        r.teamUsed.add(rn.get("function") + "(...) — your Action runner, every loop");
                        covered.add(text.trim() + "  (your runner: runs this autonomous)");
                    } else {
                        for (String s : par.runOnce(runnerList)) L.add(ind + s);
                        covered.add("runs this autonomous's " + par.stepType() + "s" + (Boolean.TRUE.equals(e.get("team_runner")) ? " (where your loop runs " + text.trim() + ")" : ""));
                    }
                    ranRunner = true;
                    break;
                case "state_machine":
                    if (!(par instanceof Paradigms.RrActions) && !teamRunner && !ranRunner) {
                        for (String s : par.runOnce(runnerList)) L.add(ind + s);
                        ranRunner = true;
                    }
                    break;
                default:
                    break;
            }
        }
        // every update the robot needs, even if the reference auto forgot one
        List<String> extra = requiredUpdates(updated);
        if (!extra.isEmpty()) {
            List<String> add = new ArrayList<>();
            for (String s : extra) add.add(ind + s);
            if (lastUpdate >= 0) L.addAll(lastUpdate, add);
            else L.addAll(0, add);
        }
        Map<String, Object> bc = Json.map(m.get("bulk_caching"));
        if (!bulk && "MANUAL".equals(bc.get("value"))) {
            imports.add("com.qualcomm.hardware.lynx.LynxModule");
            String hubs = wrapper != null && wrapper.get("hubs_field") != null ? robotVar + "." + wrapper.get("hubs_field") : "hardwareMap.getAll(LynxModule.class)";
            L.add(0, ind + "for (LynxModule hub : " + hubs + ") hub.clearBulkCache();  // your code sets MANUAL bulk caching (" + bc.get("file") + ":" + bc.get("line") + ")");
            covered.add(0, "bulk cache clear (added: MANUAL caching is set in " + bc.get("file") + ":" + bc.get("line") + ")");
        }
        if (!ranRunner) {
            if (par instanceof Paradigms.RrActions) imports.add("com.acmerobotics.dashboard.telemetry.TelemetryPacket");
            for (String s : par.runOnce(runnerList)) L.add(ind + s);
        }
        for (String s : extra) covered.add(s.trim() + "  (added)");
        r.facts.put("every_loop", covered);
        return L;
    }

    private String runnerListName() { return runnerList; }

    /** Required update() calls the loop does not make yet (directly or through the Robot wrapper's update). */
    @SuppressWarnings("unchecked")
    private List<String> requiredUpdates(Set<String> updated) {
        List<String> out = new ArrayList<>();
        Set<String> viaWrapper = new LinkedHashSet<>();
        boolean followerUpdated = updated.contains(follower + ".update");
        if (wrapper != null) {
            Map<String, Object> wu = Json.map(wrapper.get("update"));
            if (!wu.isEmpty() && updated.contains(robotVar + "." + wu.get("method"))) {
                for (Object c : Json.list(wu.get("calls"))) viaWrapper.add(c.toString());
                if (Boolean.TRUE.equals(wu.get("calls_follower_update"))) followerUpdated = true;
            }
        }
        for (Object o : Json.list(m.get("subsystems"))) {
            Map<String, Object> s = Json.map(o);
            Map<String, Object> u = Json.map(s.get("update"));
            if (u.isEmpty() || !Boolean.TRUE.equals(u.get("required"))) continue;
            // FTCLib / SolversLib: CommandScheduler.run() calls periodic() of every registered SubsystemBase
            if (par instanceof Paradigms.Commands && Boolean.TRUE.equals(s.get("framework_subsystem")) && "periodic".equals(u.get("method"))) continue;
            if (wrapper != null && s.get("class").equals(wrapper.get("class"))) {
                if (!updated.contains(robotVar + "." + u.get("method"))) out.add(robotVar + "." + u.get("method") + "(" + updateArgs(Json.list(u.get("params"))) + ");  // " + u.get("evidence"));
                continue;
            }
            String field = null;
            if (wrapper != null) for (Map.Entry<String, Object> e : Json.map(wrapper.get("subsystems")).entrySet()) if (e.getValue().equals(s.get("class"))) field = e.getKey();
            if (field == null) {
                r.warnings.add(s.get("ref") + "." + u.get("method") + "() must run every loop (" + u.get("evidence") + "), but the generated autonomous does not create a " + s.get("ref") + ". If it is on the robot, add it to your Robot class.");
                continue;
            }
            String call = field + "." + u.get("method");
            if (viaWrapper.contains(call) || updated.contains(robotVar + "." + call)) continue;
            out.add(robotVar + "." + call + "(" + updateArgs(Json.list(u.get("params"))) + ");  // must run every loop: " + u.get("evidence"));
        }
        if (!followerUpdated) out.add(pedro.update(follower) + "  // the follower must update every loop");
        return out;
    }

    private String updateArgs(List<Object> params) {
        List<String> a = new ArrayList<>();
        for (Object p : params) {
            String t = p.toString();
            if (t.equals("Pose")) a.add(pedro.pose(follower));
            else if (t.equals("Telemetry")) a.add("telemetry");
            else { r.errors.add("BEE does not know what to pass to an update(" + t + ") method."); a.add("null"); }
        }
        return String.join(", ", a);
    }

    private List<String> initBody(String ind) {
        List<String> L = new ArrayList<>();
        if (wrapper != null) {
            List<String> args = new ArrayList<>();
            boolean poseGiven = false;
            for (Object o : Json.list(wrapper.get("ctor_params"))) {
                String t = o.toString().split(" ")[0];
                switch (t) {
                    case "HardwareMap": args.add("hardwareMap"); break;
                    case "Pose": args.add("startPose"); poseGiven = true; break;
                    case "Telemetry": args.add("telemetry"); break;
                    default: r.errors.add("BEE cannot build your " + wrapper.get("ref") + ": its constructor needs a " + t + "."); return L;
                }
            }
            L.add(ind + "startPose = " + startExpr + ";");
            L.add(ind + robotVar + " = new " + wrapper.get("ref") + "(" + String.join(", ", args) + ");");
            for (Object c : Json.list(Json.map(m.get("loop")).get("robot_init_calls"))) L.add(ind + robotVar + "." + c + "();  // as your autos do after new " + wrapper.get("ref") + "(...)");
            if (!poseGiven || wrapper.get("follower_field") == null) L.add(ind + pedro.setStartingPose(follower, "startPose"));
        } else {
            Map<String, Object> consts = Json.map(Json.map(m.get("pedro")).get("constants"));
            Map<String, Object> f = Json.map(consts.get("factory"));
            List<String> args = new ArrayList<>();
            for (Object p : Json.list(f.get("params"))) {
                String t = p.toString();
                if (t.equals("HardwareMap")) args.add("hardwareMap");
                else if (t.equals("Telemetry")) args.add("telemetry");
                else { r.errors.add("BEE cannot call " + consts.get("ref") + "." + f.get("name") + ": it needs a " + t + "."); return L; }
            }
            L.add(ind + "startPose = " + startExpr + ";");
            L.add(ind + "follower = " + consts.get("ref") + "." + f.get("name") + "(" + String.join(", ", args) + ");");
            L.add(ind + pedro.setStartingPose(follower, "startPose"));
            imports.add("com.pedropathing.follower.Follower");
        }
        L.add(ind + "startHeading = " + pedro.heading("startPose") + ";");
        // the alliance, as the team's autos set it (the turret aims from it)
        String al = answer("alliance");
        if (al != null) {
            String stmt = allianceStatement(al);
            if (stmt != null) L.add(ind + stmt + "  // as in your autos");
        }
        // values some methods need before they work (Flywheel.velocity <- setFlywheelParameters(...))
        Set<String> doneSetters = new LinkedHashSet<>();
        for (Object o : Json.list(m.get("subsystems"))) {
            Map<String, Object> s = Json.map(o);
            for (Object p : Json.list(s.get("preconditions"))) {
                Map<String, Object> pm = Json.map(p);
                String id = "precondition:" + s.get("ref").toString().replaceAll(".*\\.", "") + "." + pm.get("field");
                if (!"fallback".equals(answer(id))) continue;
                Map<String, Object> setter = Json.map(Json.list(pm.get("setters")).get(0));
                List<String> args = new ArrayList<>();
                for (Object fb : Json.list(setter.get("fallbacks"))) {
                    Map<String, Object> f = Json.map(fb);
                    args.add((String) f.get("ref"));
                    if (f.get("import") != null) imports.add((String) f.get("import"));
                }
                String field = null;
                if (wrapper != null) for (Map.Entry<String, Object> e : Json.map(wrapper.get("subsystems")).entrySet()) if (e.getValue().equals(s.get("class"))) field = e.getKey();
                if (field == null) continue;
                String setCall = robotVar + "." + field + "." + setter.get("method") + "(" + String.join(", ", args) + ");";
                if (!doneSetters.add(setCall)) continue;
                L.add(ind + scaleSpeed(robotVar + "." + field + "." + setter.get("method") + "(" + String.join(", ", args) + ")") + ";  // " + s.get("ref") + "." + pm.get("method") + "() needs '" + pm.get("field") + "'");
                r.teamUsed.add(robotVar + "." + field + "." + setter.get("method") + "(" + String.join(", ", args) + ") at init — " + pm.get("message"));
            }
        }
        for (String s : deviceInit) L.add(ind + s);
        for (String s : pathInit) L.add(ind + s);
        return L;
    }

    private String allianceStatement(String al) {
        Map<String, Object> any = null;
        for (Object o : Json.list(m.get("opmodes"))) {
            Map<String, Object> a = Json.map(Json.map(o).get("alliance"));
            if (a.isEmpty()) continue;
            if (al.equals(a.get("value"))) {
                importsFor((String) a.get("statement"));
                String target = (String) a.get("target");
                imports.addAll(importsOfRef(target));
                return a.get("statement").toString().trim();
            }
            any = a;
        }
        if (any != null) {
            // only the other alliance is set somewhere: same statement with the other enum constant
            String vr = (String) any.get("value_ref");
            String other = vr.replaceAll("(?i)(RED|BLUE)$", al.toUpperCase(Locale.ROOT));
            importsFor((String) any.get("statement"));
            return any.get("target") + " = " + other + ";";
        }
        return null;
    }

    private List<String> importsOfRef(String ref) {
        List<String> out = new ArrayList<>();
        String head = ref.split("\\.")[0];
        for (Object o : Json.list(Json.map(m.get("loop")).get("source_imports"))) if (o.toString().endsWith("." + head)) out.add(o.toString());
        return out;
    }

    private List<String> startBody(String ind, String root) {
        List<String> L = new ArrayList<>();
        Map<String, Object> st = Json.map(Json.map(m.get("loop")).get("start_statements"));
        int copied = 0;
        for (Object o : Json.list(st.get("statements"))) {
            String t = Json.str(Json.map(o).get("text"), "");
            // setup (camera start, pipeline) is copied; moving a mechanism is the team's autonomous, BEE's path replaces it
            if (t.matches("(?s).*\\.(setPower|setPosition|setVelocity|setTargetPosition|turnOn\\w*|turnOff\\w*|followPath|run|stop)\\(.*")) {
                r.warnings.add("Not copied from your start(): " + t.trim() + " — it moves a mechanism; the BEE path decides that.");
                continue;
            }
            // your auto places the robot at its own start pose: the export already starts it at the chosen one
            if (t.matches("(?s).*\\.(setPose|setStartingPose)\\(.*") || t.matches("(?s)\\s*(final\\s+)?Pose\\s+\\w+\\s*=.*")) {
                r.assumptions.add("Not copied from your start(): " + t.split("\n")[0].trim() + " — the export starts at the pose you chose (" + startDesc.split("  ")[0] + ").");
                continue;
            }
            L.add(reindent(t, ind));
            importsFor(t);
            copied++;
        }
        if (copied > 0) r.teamUsed.add("Your start() setup from " + Json.str(st.get("class"), "").replaceAll(".*\\.", "") + " (" + st.get("file") + ")");
        for (String s : par.startRoot(root, runnerList)) L.add(ind + s);
        return L;
    }

    // ---------------- assembly ----------------

    private String className() {
        String n = Gen.ident(Json.str(path.get("name"), "BeeAuto")) + (testScale > 0 ? "TestShots" : "");
        Set<String> taken = new LinkedHashSet<>();
        for (Object o : Json.list(m.get("opmodes"))) taken.add(Json.str(Json.map(o).get("class"), "").replaceAll(".*\\.", ""));
        for (Object o : Json.list(m.get("subsystems"))) taken.add(Json.str(Json.map(o).get("ref"), ""));
        if (taken.contains(n)) {
            r.warnings.add("Your project already has a class " + n + ": the export is called " + n + "Bee.");
            n = n + "Bee";
        }
        return n;
    }

    private String teamcodeRoot() {
        for (Object o : Json.list(m.get("opmodes"))) {
            String c = Json.str(Json.map(o).get("class"), "");
            if (c.contains(".teamcode")) return c.substring(0, c.indexOf(".teamcode") + 9);
        }
        return "org.firstinspires.ftc.teamcode";
    }

    private String pkg() {
        for (Object o : Json.list(m.get("opmodes"))) {
            Map<String, Object> om = Json.map(o);
            if (Boolean.TRUE.equals(om.get("reference"))) return (String) om.get("package");
        }
        Map<String, Object> consts = Json.map(Json.map(m.get("pedro")).get("constants"));
        String p = Json.str(consts.get("package"), "org.firstinspires.ftc.teamcode");
        return p.contains(".teamcode") ? p.substring(0, p.indexOf(".teamcode") + 9) : p;
    }

    private boolean linearStyle() {
        for (Object o : Json.list(m.get("opmodes"))) {
            Map<String, Object> om = Json.map(o);
            if (Boolean.TRUE.equals(om.get("reference"))) return "linear".equals(om.get("style"));
        }
        return false;
    }

    private String assemble(String pkg, String cls, String root, Program prog) {
        boolean linear = linearStyle();
        String ind2 = "        ";
        List<String> init = initBody(ind2);
        List<String> loop = loopBody(linear ? ind2 + "    " : ind2);
        List<String> start = startBody(ind2, "autonomous()");
        if (!r.ok()) return null;
        imports.addAll(pedro.imports());
        imports.add("com.qualcomm.robotcore.eventloop.opmode.Autonomous");
        imports.add(linear ? "com.qualcomm.robotcore.eventloop.opmode.LinearOpMode" : "com.qualcomm.robotcore.eventloop.opmode.OpMode");
        imports.add("java.util.ArrayList");
        imports.add("java.util.List");
        // the copied loop logic: its fields and imports
        Map<String, Object> logic = Json.map(Json.map(m.get("loop")).get("logic"));
        boolean copyLogic = "yes".equals(answer("copy_loop_logic"));
        List<String> logicFields = new ArrayList<>();
        if (copyLogic) {
            for (Object o : Json.map(logic.get("fields")).values()) logicFields.add("private " + Json.map(o).get("decl"));
            for (Object o : Json.list(logic.get("imports"))) imports.add(o.toString());
            for (Object o : Json.map(logic.get("fields")).values()) importsFor(Json.str(Json.map(o).get("decl"), ""));
            if (!Json.list(logic.get("statements")).isEmpty())
                r.teamUsed.add("Your per-loop logic from " + Json.str(logic.get("class"), "").replaceAll(".*\\.", "") + "." + logic.get("method") + "() (" + logic.get("file") + ")");
            for (Object o : Json.list(logic.get("rejected")))
                r.warnings.add("Not copied from your loop (line " + Json.map(o).get("line") + "): " + Json.map(o).get("text").toString().split("\n")[0] + " — " + Json.map(o).get("reason"));
        }
        for (String f : logicFields) importsFor(f);
        // the team's stop(): robot.stop() (background threads), with the fields it reads
        List<String> stop = new ArrayList<>();
        Map<String, Object> stopSt = Json.map(Json.map(m.get("loop")).get("stop_statements"));
        for (Object o : Json.list(stopSt.get("statements"))) {
            String t = Json.str(Json.map(o).get("text"), "");
            stop.add(reindent(t, ind2));
            importsFor(t);
        }
        for (Object o : Json.map(stopSt.get("fields")).values()) {
            String decl = "private " + Json.map(o).get("decl");
            if (!logicFields.contains(decl)) { logicFields.add(decl); importsFor(decl); }
        }
        for (Object o : Json.list(stopSt.get("imports"))) imports.add(o.toString());
        if (!stop.isEmpty()) r.teamUsed.add("Your stop() from " + Json.str(stopSt.get("class"), "").replaceAll(".*\\.", "") + " (" + stopSt.get("file") + ")");

        List<String> L = new ArrayList<>();
        L.add("package " + pkg + ";");
        L.add("");
        for (String i : imports) {
            boolean samePackage = i.startsWith(pkg + ".") && !i.substring(pkg.length() + 1).contains(".");
            if (!i.isEmpty() && !samePackage) L.add("import " + i + ";");
        }
        L.add("");
        L.addAll(header(cls, prog));
        L.add("@Autonomous(name = " + Gen.q(testScale > 0 ? cls + " (TEST SHOTS " + Math.round(testScale * 100) + "%)" : cls) + ", group = " + Gen.q(testScale > 0 ? "BEE TEST" : "BEE") + ")");
        L.add("public class " + cls + " extends " + (linear ? "LinearOpMode" : "OpMode") + " {");
        if (wrapper != null) L.add("    private " + wrapper.get("ref") + " " + robotVar + ";");
        else L.add("    private Follower follower;");
        L.add("    private " + pedro.poseType() + " startPose;");
        L.add("    private double startHeading;");
        for (String f : par.fields(runnerList)) L.add("    " + f);
        L.add("    private final List<String> timedOut = new ArrayList<>();");
        for (String f : deviceFields) L.add("    " + f);
        for (String f : logicFields) L.add("    " + f);
        for (String f : pathFields) L.add("    " + f);
        if (pedro instanceof Pedro3Adapter) L.add("    private static final double TURN_TOLERANCE_RAD = Math.toRadians(2);");
        if (testScale > 0) L.add("    /** TEST SHOTS: every flywheel speed your code asks for is multiplied by this. 1.0 = real shots. */\n    static final double TEST_SHOT_SCALE = " + Gen.num(testScale) + ";");
        L.add("");
        if (linear) {
            L.add("    @Override");
            L.add("    public void runOpMode() {");
            L.addAll(init);
            L.add(ind2 + "telemetry.addData(\"BEE\", " + Gen.q(cls + " ready, start " + startDesc.split("  ")[0]) + ");");
            L.add(ind2 + "telemetry.update();");
            L.add(ind2 + "waitForStart();");
            L.addAll(start);
            L.add(ind2 + "while (opModeIsActive() && !(" + par.done(runnerList) + ")) {");
            L.addAll(loop);
            L.addAll(telemetry(ind2 + "    "));
            L.add(ind2 + "}");
            for (String s : stop) L.add("    " + s);
            L.add("    }");
        } else {
            L.add("    @Override");
            L.add("    public void init() {");
            L.addAll(init);
            L.add("    }");
            L.add("");
            L.add("    @Override");
            L.add("    public void init_loop() {");
            L.add(ind2 + "telemetry.addData(\"BEE\", " + Gen.q(cls + " ready, start " + startDesc.split("  ")[0]) + ");");
            L.add(ind2 + "telemetry.update();");
            L.add("    }");
            L.add("");
            L.add("    @Override");
            L.add("    public void start() {");
            L.addAll(start);
            L.add("    }");
            L.add("");
            L.add("    @Override");
            L.add("    public void loop() {");
            L.addAll(loop);
            L.addAll(telemetry(ind2));
            L.add("    }");
            if (!stop.isEmpty()) {
                L.add("");
                L.add("    @Override");
                L.add("    public void stop() {");
                L.addAll(stop);
                L.add("    }");
            }
        }
        L.add("");
        L.add("    /** The autonomous drawn in BEE, as one " + par.stepType() + ". */");
        L.add("    private " + par.stepType() + " autonomous() {");
        L.add("        return " + root.replace("\n", "\n        ") + ";");
        L.add("    }");
        L.add("");
        L.add("    /** BEE's path is relative to the start (x forward, y left, heading in degrees, + = left): this places it on the field. */");
        L.add("    private " + pedro.poseType() + " rel(double forward, double left, double headingDeg) {");
        L.add("        double c = Math.cos(startHeading), s = Math.sin(startHeading);");
        L.add("        return " + pedro.newPose(pedro.x("startPose") + " + forward * c - left * s", pedro.y("startPose") + " + forward * s + left * c", "startHeading + Math.toRadians(headingDeg)") + ";");
        L.add("    }");
        if (pedro instanceof Pedro3Adapter) {
            L.add("");
            L.add("    private static double angleDiff(double a, double b) {");
            L.add("        return Math.atan2(Math.sin(a - b), Math.cos(a - b));");
            L.add("    }");
        }
        L.add("");
        L.addAll(par.helpers());
        L.add("}");
        return String.join("\n", L) + "\n";
    }

    private List<String> telemetry(String ind) {
        List<String> L = new ArrayList<>();
        String pose = pedro.pose(follower);
        if (testScale > 0) L.add(ind + "telemetry.addData(\"TEST SHOTS\", \"flywheel at %.0f%% — not for matches\", TEST_SHOT_SCALE * 100);");
        L.add(ind + "telemetry.addData(\"BEE auto\", " + par.done(runnerList) + " ? \"finished\" : \"running\");");
        L.add(ind + "telemetry.addData(\"pose\", \"%.1f, %.1f, %.0f°\", " + pedro.x(pose) + ", " + pedro.y(pose) + ", Math.toDegrees(" + pedro.heading(pose) + "));");
        L.add(ind + "if (!timedOut.isEmpty()) telemetry.addData(\"ran out of time\", timedOut);");
        L.add(ind + "telemetry.update();");
        return L;
    }

    @SuppressWarnings("unchecked")
    private List<String> header(String cls, Program prog) {
        List<String> H = new ArrayList<>();
        H.add("/**");
        H.add(" * " + cls + " — exported by the BEE Auto Builder from your own robot code.");
        if (testScale > 0) {
            H.add(" *");
            H.add(" * !!! TEST SHOTS: the flywheel runs at " + Math.round(testScale * 100) + "% of the speed your code asks for (TEST_SHOT_SCALE).");
            H.add(" * !!! Pieces only roll out. Use it to try the path and the sequence; NEVER in a match.");
            for (String t : testNotes) H.add(" *     " + t);
        }
        H.add(" *");
        H.add(" * DETECTED IN YOUR PROJECT");
        Map<String, Object> libs = Json.map(m.get("libraries"));
        for (Map.Entry<String, Object> e : libs.entrySet()) {
            Map<String, Object> d = Json.map(e.getValue());
            H.add(" *   " + d.get("group") + ":" + d.get("artifact") + ":" + d.get("version") + "   (" + d.get("file") + ":" + d.get("line") + ")");
        }
        H.add(" *   Pedro calls: " + pedro.label() + ", every call checked against the published " + pedro.version() + " artifacts");
        H.add(" *   Sequencing: " + par.name() + " (" + Json.str(Json.map(m.get("paradigm")).get("evidence"), "") + ")");
        H.add(" *   Start: " + startDesc);
        Map<String, Object> co = Json.map(m.get("coordinates"));
        if (!co.isEmpty()) H.add(" *   Coordinates: " + Json.map(co.get("system")).get("value") + ", headings in " + Json.map(co.get("heading_units")).get("value") + " (" + Json.map(co.get("system")).get("evidence") + ")");
        if (capacity > 0) H.add(" *   Pieces held: " + capacity + " (" + Json.map(Json.map(m.get("game_limits")).get("capacity")).get("evidence") + ")");
        H.add(" *   Max velocity for time limits: " + Gen.num(vmax) + " in/s");
        H.add(" *");
        H.add(" * YOUR CODE THIS USES");
        for (String s : new LinkedHashSet<>(r.teamUsed)) H.add(" *   - " + s);
        List<String> every = (List<String>) r.facts.getOrDefault("every_loop", List.of());
        if (!every.isEmpty()) {
            H.add(" *");
            H.add(" * EVERY LOOP, IN YOUR ORDER");
            for (String s : every) H.add(" *   - " + s.replace("\n", " ").replaceAll("\\s+", " "));
        }
        H.add(" *");
        H.add(" * BEE PATH (relative to the start: x forward, y left, degrees)");
        for (Program.Step s : prog.steps) H.add(" *   - " + stepText(s));
        if (!r.assumptions.isEmpty()) {
            H.add(" *");
            H.add(" * ASSUMPTIONS");
            for (String s : r.assumptions) H.add(" *   - " + s);
        }
        List<Object> conflicts = Json.list(m.get("conflicts"));
        if (!conflicts.isEmpty() || !r.warnings.isEmpty()) {
            H.add(" *");
            H.add(" * WARNINGS");
            for (Object c : conflicts) H.add(" *   - " + Json.map(c).get("message"));
            for (String s : r.warnings) H.add(" *   - " + s);
        }
        if (!r.notCopied.isEmpty()) {
            H.add(" *");
            H.add(" * BUGS FOUND IN YOUR CODE (reported, NOT copied into this file)");
            for (String s : r.notCopied) H.add(" *   - " + s);
        }
        H.add(" */");
        // never let the comment end early
        List<String> safe = new ArrayList<>();
        for (int i = 0; i < H.size(); i++) safe.add(i == H.size() - 1 ? H.get(i) : H.get(i).replace("*/", "* /"));
        return safe;
    }

    private static String stepText(Program.Step s) {
        if (s instanceof Program.Drive) {
            Program.Drive d = (Program.Drive) s;
            return String.format(Locale.ROOT, "%s: to (%.1f, %.1f, %.0f°), %s heading, power %.2f, %.1f in", d.label, d.x, d.y, d.h, d.headingMode, d.maxPower, d.dist);
        }
        if (s instanceof Program.Together) {
            List<String> b = new ArrayList<>();
            for (Program.Step x : ((Program.Together) s).body) b.add(stepText(x));
            return (((Program.Together) s).any ? "together (any): " : "together: ") + String.join(" | ", b);
        }
        return s.label;
    }

    private static List<String> strs(Object o) {
        List<String> out = new ArrayList<>();
        for (Object x : Json.list(o)) out.add(String.valueOf(x));
        return out;
    }

    @SuppressWarnings("unused")
    private static int major(String v) { return Version.major(v); }
}
