package org.beesim.team.gen;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** The three ways a generated autonomous can sequence its steps (see {@link Paradigm}). */
public final class Paradigms {
    private Paradigms() {}

    static String secondsExpr(double seconds, String ref, double refScale) {
        if (ref == null) return Gen.num(seconds);
        if (refScale == 1.0) return ref;
        if (refScale == 0.001) return ref + " / 1000.0";
        return ref + " * " + Gen.num(refScale);
    }

    static String millisExpr(double seconds, String ref, double refScale) {
        if (ref == null) return Math.round(seconds * 1000) + "L";
        if (refScale == 0.001) return "(long) " + ref;
        if (refScale == 1.0) return "(long) (" + ref + " * 1000)";
        return "(long) (" + ref + " * " + Gen.num(refScale * 1000) + ")";
    }

    // =====================================================================================
    /** Road Runner Actions (com.acmerobotics.roadrunner), run by the team's own runner every loop. */
    public static final class RrActions extends Paradigm {
        public RrActions(PedroAdapter p, String follower) { super(p, follower); }

        @Override public String name() { return "rr_actions"; }

        @Override public String stepType() { return "Action"; }

        @Override public List<String> imports() {
            return List.of("com.acmerobotics.roadrunner.Action", "com.acmerobotics.roadrunner.SequentialAction", "com.acmerobotics.roadrunner.ParallelAction",
                    "com.acmerobotics.roadrunner.SleepAction", "com.acmerobotics.dashboard.telemetry.TelemetryPacket", "com.qualcomm.robotcore.util.ElapsedTime",
                    "java.util.function.BooleanSupplier", "java.util.function.Supplier", "java.util.ArrayList", "java.util.List");
        }

        @Override public String seq(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "new SequentialAction(" + Gen.args(items, ind) + ")"; }

        @Override public String par(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "new ParallelAction(" + Gen.args(items, ind) + ")"; }

        @Override public String race(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "new Race(" + Gen.args(items, ind) + ")"; }

        /** Your Action factories run when the step starts (as in your autos), not when the autonomous is built. */
        @Override public String team(String expr) { return "lazy(() -> " + expr + ")"; }

        @Override public String sleep(double s, String ref, double sc) { return "new SleepAction(" + secondsExpr(s, ref, sc) + ")"; }

        @Override public String instant(String st) { return "packet -> { " + st + " return false; }"; }

        @Override public String waitUntil(String c, String t) { return "new WaitUntil(() -> " + c + ", " + t + ")"; }

        @Override public String ifThen(String c, String then) { return "new IfThen(() -> " + c + ", " + then + ")"; }

        @Override public boolean accepts(String kind) { return kind.equals("action") || kind.equals("sync"); }

        @Override public List<String> fields(String list) { return List.of("private final List<Action> " + list + " = new ArrayList<>();"); }

        @Override public List<String> startRoot(String root, String list) { return List.of(list + ".add(" + root + ");"); }

        @Override public List<String> runOnce(String list) {
            return List.of("TelemetryPacket packet = new TelemetryPacket();",
                    "for (int i = 0; i < " + list + ".size(); ) {",
                    "    if (" + list + ".get(i).run(packet)) i++;",
                    "    else " + list + ".remove(i);",
                    "}");
        }

        @Override public String done(String list) { return list + ".isEmpty()"; }

        @Override public List<String> helpers() {
            List<String> L = new ArrayList<>();
            L.add("    /** Follows one Pedro path. Done when the follower is done, or after timeoutS seconds (then it holds where it is). */");
            L.add("    private class FollowPath implements Action {");
            L.add("        private final " + pedro.pathType() + " path;");
            L.add("        private final double maxPower, timeoutS;");
            L.add("        private final String label;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("        private boolean started;");
            L.add("");
            L.add("        FollowPath(" + pedro.pathType() + " path, double maxPower, double timeoutS, String label) {");
            L.add("            this.path = path;");
            L.add("            this.maxPower = maxPower;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("            this.label = label;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run(TelemetryPacket packet) {");
            L.add("            if (!started) {");
            L.add("                started = true;");
            L.add("                timer.reset();");
            for (String s : pedro.followWithPower(follower, "path", "maxPower")) L.add("                " + s);
            L.add("            }");
            L.add("            if (!" + pedro.isBusy(follower) + ") return false;");
            L.add("            if (timer.seconds() > timeoutS) {");
            L.add("                // not there in time (blocked, or slower than expected): stop and hold here, go on");
            for (String s : pedro.holdHere(follower)) L.add("                " + s);
            L.add("                timedOut.add(label);");
            L.add("                return false;");
            L.add("            }");
            L.add("            return true;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** The actions at the same time; done as soon as the FIRST one is done (a path still running stops there). */");
            L.add("    private class Race implements Action {");
            L.add("        private final Action[] actions;");
            L.add("");
            L.add("        Race(Action... actions) {");
            L.add("            this.actions = actions;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run(TelemetryPacket packet) {");
            L.add("            for (Action a : actions) {");
            L.add("                if (!a.run(packet)) {");
            L.add("                    if (" + pedro.isBusy(follower) + ") {");
            for (String s : pedro.holdHere(follower)) L.add("                        " + s);
            L.add("                    }");
            L.add("                    return false;");
            L.add("                }");
            L.add("            }");
            L.add("            return true;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** Turns in place to a field heading (radians). */");
            L.add("    private class TurnTo implements Action {");
            L.add("        private final double heading, timeoutS;");
            L.add("        private final String label;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("        private boolean started;");
            L.add("");
            L.add("        TurnTo(double heading, double timeoutS, String label) {");
            L.add("            this.heading = heading;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("            this.label = label;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run(TelemetryPacket packet) {");
            L.add("            if (!started) {");
            L.add("                started = true;");
            L.add("                timer.reset();");
            for (String s : pedro.turnTo(follower, "heading")) L.add("                " + s);
            L.add("            }");
            L.add("            if (!(" + pedro.turning(follower, "heading") + ")) return false;");
            L.add("            if (timer.seconds() > timeoutS) {");
            for (String s : pedro.holdHere(follower)) L.add("                " + s);
            L.add("                timedOut.add(label);");
            L.add("                return false;");
            L.add("            }");
            L.add("            return true;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** Waits until the condition is true, at most timeoutS seconds. */");
            L.add("    private static class WaitUntil implements Action {");
            L.add("        private final BooleanSupplier condition;");
            L.add("        private final double timeoutS;");
            L.add("        private ElapsedTime timer;");
            L.add("");
            L.add("        WaitUntil(BooleanSupplier condition, double timeoutS) {");
            L.add("            this.condition = condition;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run(TelemetryPacket packet) {");
            L.add("            if (timer == null) timer = new ElapsedTime();");
            L.add("            return !condition.getAsBoolean() && timer.seconds() < timeoutS;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** Builds the Action only when it starts, like your autonomous does (your Action methods run at that moment). */");
            L.add("    private static Action lazy(Supplier<Action> make) {");
            L.add("        return new Action() {");
            L.add("            private Action action;");
            L.add("");
            L.add("            @Override");
            L.add("            public boolean run(TelemetryPacket packet) {");
            L.add("                if (action == null) action = make.get();");
            L.add("                return action.run(packet);");
            L.add("            }");
            L.add("        };");
            L.add("    }");
            L.add("");
            L.add("    /** Runs `then` only if the condition is true when this step starts. */");
            L.add("    private static class IfThen implements Action {");
            L.add("        private final BooleanSupplier condition;");
            L.add("        private final Action then;");
            L.add("        private Boolean yes;");
            L.add("");
            L.add("        IfThen(BooleanSupplier condition, Action then) {");
            L.add("            this.condition = condition;");
            L.add("            this.then = then;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run(TelemetryPacket packet) {");
            L.add("            if (yes == null) yes = condition.getAsBoolean();");
            L.add("            return yes && then.run(packet);");
            L.add("        }");
            L.add("    }");
            return L;
        }
    }

    // =====================================================================================
    /** FTCLib / SolversLib commands, run by the CommandScheduler every loop. */
    public static final class Commands extends Paradigm {
        private final String pkg;  // com.arcrobotics.ftclib.command / com.seattlesolvers.solverslib.command

        public Commands(PedroAdapter p, String follower, String pkg) {
            super(p, follower);
            this.pkg = pkg;
        }

        @Override public String name() { return "ftclib_commands"; }

        @Override public String stepType() { return "Command"; }

        @Override public List<String> imports() {
            return List.of(pkg + ".Command", pkg + ".CommandBase", pkg + ".CommandScheduler", pkg + ".SequentialCommandGroup", pkg + ".ParallelCommandGroup", pkg + ".ParallelRaceGroup",
                    pkg + ".WaitCommand", pkg + ".InstantCommand", pkg + ".ConditionalCommand", "com.qualcomm.robotcore.util.ElapsedTime", "java.util.function.BooleanSupplier");
        }

        @Override public String seq(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "new SequentialCommandGroup(" + Gen.args(items, ind) + ")"; }

        @Override public String par(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "new ParallelCommandGroup(" + Gen.args(items, ind) + ")"; }

        @Override public String race(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "new ParallelRaceGroup(" + Gen.args(items, ind) + ")"; }

        @Override public String sleep(double s, String ref, double sc) { return "new WaitCommand(" + millisExpr(s, ref, sc) + ")"; }

        @Override public String instant(String st) { return "new InstantCommand(() -> { " + st + " })"; }

        @Override public String waitUntil(String c, String t) { return "new WaitUntil(() -> " + c + ", " + t + ")"; }

        @Override public String ifThen(String c, String then) { return "new ConditionalCommand(" + then + ", new InstantCommand(), () -> " + c + ")"; }

        @Override public boolean accepts(String kind) { return kind.equals("command") || kind.equals("sync"); }

        @Override public List<String> fields(String list) { return List.of("private Command " + list + ";"); }

        @Override public List<String> startRoot(String root, String list) {
            return List.of(list + " = " + root + ";", "CommandScheduler.getInstance().schedule(" + list + ");");
        }

        @Override public List<String> runOnce(String list) { return List.of("CommandScheduler.getInstance().run();"); }

        @Override public String done(String list) { return list + " != null && !CommandScheduler.getInstance().isScheduled(" + list + ")"; }

        @Override public List<String> helpers() {
            List<String> L = new ArrayList<>();
            L.add("    /** Follows one Pedro path. Done when the follower is done, or after timeoutS seconds (then it holds where it is). */");
            L.add("    private class FollowPath extends CommandBase {");
            L.add("        private final " + pedro.pathType() + " path;");
            L.add("        private final double maxPower, timeoutS;");
            L.add("        private final String label;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("");
            L.add("        FollowPath(" + pedro.pathType() + " path, double maxPower, double timeoutS, String label) {");
            L.add("            this.path = path;");
            L.add("            this.maxPower = maxPower;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("            this.label = label;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public void initialize() {");
            L.add("            timer.reset();");
            for (String s : pedro.followWithPower(follower, "path", "maxPower")) L.add("            " + s);
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean isFinished() {");
            L.add("            return !" + pedro.isBusy(follower) + " || timer.seconds() > timeoutS;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public void end(boolean interrupted) {");
            L.add("            if (" + pedro.isBusy(follower) + ") {");
            for (String s : pedro.holdHere(follower)) L.add("                " + s);
            L.add("                if (!interrupted) timedOut.add(label);  // interrupted = a TOGETHER (ANY) ended first");
            L.add("            }");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** Turns in place to a field heading (radians). */");
            L.add("    private class TurnTo extends CommandBase {");
            L.add("        private final double heading, timeoutS;");
            L.add("        private final String label;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("");
            L.add("        TurnTo(double heading, double timeoutS, String label) {");
            L.add("            this.heading = heading;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("            this.label = label;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public void initialize() {");
            L.add("            timer.reset();");
            for (String s : pedro.turnTo(follower, "heading")) L.add("            " + s);
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean isFinished() {");
            L.add("            return !(" + pedro.turning(follower, "heading") + ") || timer.seconds() > timeoutS;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public void end(boolean interrupted) {");
            L.add("            if (" + pedro.turning(follower, "heading") + ") {");
            for (String s : pedro.holdHere(follower)) L.add("                " + s);
            L.add("                timedOut.add(label);");
            L.add("            }");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** Waits until the condition is true, at most timeoutS seconds. */");
            L.add("    private static class WaitUntil extends CommandBase {");
            L.add("        private final BooleanSupplier condition;");
            L.add("        private final double timeoutS;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("");
            L.add("        WaitUntil(BooleanSupplier condition, double timeoutS) {");
            L.add("            this.condition = condition;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public void initialize() {");
            L.add("            timer.reset();");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean isFinished() {");
            L.add("            return condition.getAsBoolean() || timer.seconds() > timeoutS;");
            L.add("        }");
            L.add("    }");
            return L;
        }
    }

    // =====================================================================================
    /** No framework: a tiny step runner inside the OpMode. run() returns true while the step is still running. */
    public static final class Plain extends Paradigm {
        private final Map<String, Object> team;  // the team's own Action class (update / done / reset), or null

        public Plain(PedroAdapter p, String follower) { this(p, follower, null); }

        public Plain(PedroAdapter p, String follower, Map<String, Object> teamActions) {
            super(p, follower);
            this.team = teamActions == null || teamActions.isEmpty() ? null : teamActions;
        }

        @Override public String name() { return "plain"; }

        @Override public String stepType() { return "Step"; }

        @Override public List<String> imports() {
            List<String> l = new ArrayList<>(List.of("com.qualcomm.robotcore.util.ElapsedTime", "java.util.function.BooleanSupplier"));
            if (team != null) { l.add((String) team.get("import")); l.add("java.util.function.Supplier"); }
            return l;
        }

        @Override public String teamAction(String expr) { return team == null ? null : "new TeamStep(() -> " + expr + ")"; }

        @Override public String seq(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "seq(" + Gen.args(items, ind) + ")"; }

        @Override public String par(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "par(" + Gen.args(items, ind) + ")"; }

        @Override public String race(List<String> items, String ind) { return items.size() == 1 ? items.get(0) : "race(" + Gen.args(items, ind) + ")"; }

        @Override public String sleep(double s, String ref, double sc) { return "new Sleep(" + secondsExpr(s, ref, sc) + ")"; }

        @Override public String instant(String st) { return "() -> { " + st + " return false; }"; }

        @Override public String waitUntil(String c, String t) { return "new WaitUntil(() -> " + c + ", " + t + ")"; }

        @Override public String ifThen(String c, String then) { return "new IfThen(() -> " + c + ", " + then + ")"; }

        @Override public boolean accepts(String kind) { return kind.equals("sync") || kind.equals("team_action") && team != null; }

        @Override public List<String> fields(String list) { return List.of("private Step " + list + ";", "private boolean finished;"); }

        @Override public List<String> startRoot(String root, String list) { return List.of(list + " = " + root + ";"); }

        @Override public List<String> runOnce(String list) { return List.of("if (" + list + " != null && !finished) finished = !" + list + ".run();"); }

        @Override public String done(String list) { return "finished"; }

        @Override public List<String> helpers() {
            List<String> L = new ArrayList<>();
            L.add("    /** One step of the autonomous: run() is called every loop and returns true while the step is still running. */");
            L.add("    private interface Step {");
            L.add("        boolean run();");
            L.add("    }");
            L.add("");
            L.add("    /** The steps one after the other (the next one starts in the same loop the previous one ends). */");
            L.add("    private static Step seq(Step... steps) {");
            L.add("        return new Step() {");
            L.add("            private int i = 0;");
            L.add("");
            L.add("            @Override");
            L.add("            public boolean run() {");
            L.add("                while (i < steps.length) {");
            L.add("                    if (steps[i].run()) return true;");
            L.add("                    i++;");
            L.add("                }");
            L.add("                return false;");
            L.add("            }");
            L.add("        };");
            L.add("    }");
            L.add("");
            L.add("    /** The steps at the same time; done when all are done. */");
            L.add("    private static Step par(Step... steps) {");
            L.add("        return new Step() {");
            L.add("            private final boolean[] done = new boolean[steps.length];");
            L.add("");
            L.add("            @Override");
            L.add("            public boolean run() {");
            L.add("                boolean running = false;");
            L.add("                for (int i = 0; i < steps.length; i++) {");
            L.add("                    if (!done[i]) done[i] = !steps[i].run();");
            L.add("                    running |= !done[i];");
            L.add("                }");
            L.add("                return running;");
            L.add("            }");
            L.add("        };");
            L.add("    }");
            L.add("");
            L.add("    /** The steps at the same time; done as soon as the FIRST one is done (a path still running stops there). */");
            L.add("    private Step race(Step... steps) {");
            L.add("        return () -> {");
            L.add("            for (Step s : steps) {");
            L.add("                if (!s.run()) {");
            L.add("                    if (" + pedro.isBusy(follower) + ") {");
            for (String s : pedro.holdHere(follower)) L.add("                        " + s);
            L.add("                    }");
            L.add("                    return false;");
            L.add("                }");
            L.add("            }");
            L.add("            return true;");
            L.add("        };");
            L.add("    }");
            L.add("");
            L.add("    private static class Sleep implements Step {");
            L.add("        private final double seconds;");
            L.add("        private ElapsedTime timer;");
            L.add("");
            L.add("        Sleep(double seconds) {");
            L.add("            this.seconds = seconds;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run() {");
            L.add("            if (timer == null) timer = new ElapsedTime();");
            L.add("            return timer.seconds() < seconds;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    private static class WaitUntil implements Step {");
            L.add("        private final BooleanSupplier condition;");
            L.add("        private final double timeoutS;");
            L.add("        private ElapsedTime timer;");
            L.add("");
            L.add("        WaitUntil(BooleanSupplier condition, double timeoutS) {");
            L.add("            this.condition = condition;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run() {");
            L.add("            if (timer == null) timer = new ElapsedTime();");
            L.add("            return !condition.getAsBoolean() && timer.seconds() < timeoutS;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    private static class IfThen implements Step {");
            L.add("        private final BooleanSupplier condition;");
            L.add("        private final Step then;");
            L.add("        private Boolean yes;");
            L.add("");
            L.add("        IfThen(BooleanSupplier condition, Step then) {");
            L.add("            this.condition = condition;");
            L.add("            this.then = then;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run() {");
            L.add("            if (yes == null) yes = condition.getAsBoolean();");
            L.add("            return yes && then.run();");
            L.add("        }");
            L.add("    }");
            L.add("");
            if (team != null) {
                String ref = (String) team.get("ref");
                L.add("    /** One of your own " + ref + "s, run like your ActionRunner runs it: built when the step starts, then " + team.get("update") + " until " + team.get("done") + ". */");
                L.add("    private static class TeamStep implements Step {");
                L.add("        private final Supplier<" + ref + "> make;");
                L.add("        private " + ref + " action;");
                L.add("");
                L.add("        TeamStep(Supplier<" + ref + "> make) {");
                L.add("            this.make = make;");
                L.add("        }");
                L.add("");
                L.add("        @Override");
                L.add("        public boolean run() {");
                L.add("            if (action == null) {");
                L.add("                action = make.get();");
                if (team.get("reset") != null) L.add("                action." + team.get("reset") + ";");
                L.add("            }");
                L.add("            action." + team.get("update") + ";");
                L.add("            return !action." + team.get("done") + ";");
                L.add("        }");
                L.add("    }");
                L.add("");
            }
            L.add("    /** Follows one Pedro path. Done when the follower is done, or after timeoutS seconds (then it holds where it is). */");
            L.add("    private class FollowPath implements Step {");
            L.add("        private final " + pedro.pathType() + " path;");
            L.add("        private final double maxPower, timeoutS;");
            L.add("        private final String label;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("        private boolean started;");
            L.add("");
            L.add("        FollowPath(" + pedro.pathType() + " path, double maxPower, double timeoutS, String label) {");
            L.add("            this.path = path;");
            L.add("            this.maxPower = maxPower;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("            this.label = label;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run() {");
            L.add("            if (!started) {");
            L.add("                started = true;");
            L.add("                timer.reset();");
            for (String s : pedro.followWithPower(follower, "path", "maxPower")) L.add("                " + s);
            L.add("            }");
            L.add("            if (!" + pedro.isBusy(follower) + ") return false;");
            L.add("            if (timer.seconds() > timeoutS) {");
            L.add("                // not there in time (blocked, or slower than expected): stop and hold here, go on");
            for (String s : pedro.holdHere(follower)) L.add("                " + s);
            L.add("                timedOut.add(label);");
            L.add("                return false;");
            L.add("            }");
            L.add("            return true;");
            L.add("        }");
            L.add("    }");
            L.add("");
            L.add("    /** Turns in place to a field heading (radians). */");
            L.add("    private class TurnTo implements Step {");
            L.add("        private final double heading, timeoutS;");
            L.add("        private final String label;");
            L.add("        private final ElapsedTime timer = new ElapsedTime();");
            L.add("        private boolean started;");
            L.add("");
            L.add("        TurnTo(double heading, double timeoutS, String label) {");
            L.add("            this.heading = heading;");
            L.add("            this.timeoutS = timeoutS;");
            L.add("            this.label = label;");
            L.add("        }");
            L.add("");
            L.add("        @Override");
            L.add("        public boolean run() {");
            L.add("            if (!started) {");
            L.add("                started = true;");
            L.add("                timer.reset();");
            for (String s : pedro.turnTo(follower, "heading")) L.add("                " + s);
            L.add("            }");
            L.add("            if (!(" + pedro.turning(follower, "heading") + ")) return false;");
            L.add("            if (timer.seconds() > timeoutS) {");
            for (String s : pedro.holdHere(follower)) L.add("                " + s);
            L.add("                timedOut.add(label);");
            L.add("                return false;");
            L.add("            }");
            L.add("            return true;");
            L.add("        }");
            L.add("    }");
            return L;
        }
    }
}
