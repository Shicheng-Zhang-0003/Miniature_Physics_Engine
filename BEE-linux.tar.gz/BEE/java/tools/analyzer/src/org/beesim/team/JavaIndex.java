package org.beesim.team;

import com.sun.source.tree.AnnotationTree;
import com.sun.source.tree.BlockTree;
import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.IdentifierTree;
import com.sun.source.tree.ImportTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.SourcePositions;
import com.sun.source.util.Trees;

import javax.lang.model.element.Modifier;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;
import javax.tools.ToolProvider;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The team's Java sources parsed with the JDK's own parser (javac tree API, no classpath needed: we only need
 * syntax trees, not types). Gives classes (nested ones too, e.g. Config.Hardware), fields with their initializers,
 * methods, imports, and line numbers for provenance.
 */
public final class JavaIndex {

    public static final class Src {
        public final String path;
        public final String text;
        public CompilationUnitTree cu;
        public String pkg = "";
        public final List<String> imports = new ArrayList<>();   // fully qualified, as written (may end in .*)

        Src(String path, String text) { this.path = path; this.text = text; }
    }

    public static final class ClassInfo {
        public String fqn, simple, pkg, kind;
        public Src src;
        public ClassTree tree;
        public ClassInfo outer;
        public final Map<String, FieldInfo> fields = new LinkedHashMap<>();
        public final List<MethodInfo> methods = new ArrayList<>();
        public final List<ClassInfo> inner = new ArrayList<>();
        public final List<String> annotations = new ArrayList<>();
        public String superName = "";
        public final List<String> interfaces = new ArrayList<>();
        public boolean isStatic, isPublic, isAbstract, privateClass;
        public int line;

        public boolean isPrivate() { return privateClass || (outer != null && outer.isPrivate()); }

        /** How other code refers to it: Config.Hardware */
        public String ref() { return outer == null ? simple : outer.ref() + "." + simple; }

        /** What to import: the top-level class */
        public String importName() { return outer == null ? fqn : outer.importName(); }

        public ClassInfo top() { return outer == null ? this : outer.top(); }

        public List<MethodInfo> methods(String name) {
            List<MethodInfo> out = new ArrayList<>();
            for (MethodInfo m : methods) if (m.name.equals(name)) out.add(m);
            return out;
        }

        public List<MethodInfo> ctors() { return methods("<init>"); }

        @Override public String toString() { return fqn; }
    }

    public static final class FieldInfo {
        public String name, type;
        public ExpressionTree init;
        public boolean isStatic, isFinal, isPublic, isPrivate;
        public int line;
        public ClassInfo owner;
        public VariableTree tree;
    }

    public static final class MethodInfo {
        public String name, returnType;
        public final List<VariableTree> params = new ArrayList<>();
        public BlockTree body;
        public boolean isStatic, isPublic, isCtor, isPrivate;
        public int line;
        public ClassInfo owner;
        public MethodTree tree;

        public int paramIndex(String n) {
            for (int i = 0; i < params.size(); i++) if (params.get(i).getName().contentEquals(n)) return i;
            return -1;
        }

        public String signature() {
            StringBuilder sb = new StringBuilder(isCtor ? owner.simple : name).append('(');
            for (int i = 0; i < params.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(params.get(i).getType()).append(' ').append(params.get(i).getName());
            }
            return sb.append(')').toString();
        }

        @Override public String toString() { return owner.simple + "." + (isCtor ? "<init>" : name); }
    }

    public final List<Src> sources = new ArrayList<>();
    public final Map<String, ClassInfo> byFqn = new LinkedHashMap<>();
    public final Map<String, List<ClassInfo>> bySimple = new LinkedHashMap<>();
    public final List<String> parseErrors = new ArrayList<>();
    private Trees trees;
    private SourcePositions pos;

    public static JavaIndex build(Map<String, String> files) throws IOException {
        JavaIndex ix = new JavaIndex();
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        if (javac == null) throw new IOException("A JDK (with javac) is needed to analyze the project");
        List<JavaFileObject> objs = new ArrayList<>();
        Map<URI, Src> byUri = new LinkedHashMap<>();
        int n = 0;
        for (Map.Entry<String, String> e : files.entrySet()) {
            Src s = new Src(e.getKey(), e.getValue());
            ix.sources.add(s);
            URI uri = URI.create("mem:///f" + (n++) + "/" + e.getKey().replaceAll("[^\\w./-]", "_"));
            byUri.put(uri, s);
            objs.add(new SimpleJavaFileObject(uri, JavaFileObject.Kind.SOURCE) {
                @Override public CharSequence getCharContent(boolean ignore) { return s.text; }
            });
        }
        DiagnosticCollector<JavaFileObject> diags = new DiagnosticCollector<>();
        JavacTask task = (JavacTask) javac.getTask(null, null, diags, List.of("-proc:none", "-Xlint:none"), null, objs);
        ix.trees = Trees.instance(task);
        ix.pos = ix.trees.getSourcePositions();
        for (CompilationUnitTree cu : task.parse()) {
            Src s = byUri.get(cu.getSourceFile().toUri());
            if (s == null) continue;
            s.cu = cu;
            if (cu.getPackageName() != null) s.pkg = cu.getPackageName().toString();
            for (ImportTree it : cu.getImports()) if (!it.isStatic()) s.imports.add(it.getQualifiedIdentifier().toString());
            for (Tree t : cu.getTypeDecls()) if (t instanceof ClassTree) ix.addClass(s, (ClassTree) t, null);
        }
        diags.getDiagnostics().forEach(d -> {
            if (d.getKind() == javax.tools.Diagnostic.Kind.ERROR) {
                Src s = byUri.get(d.getSource() == null ? null : d.getSource().toUri());
                ix.parseErrors.add((s == null ? "?" : s.path) + ":" + d.getLineNumber() + ": " + d.getMessage(null));
            }
        });
        return ix;
    }

    private void addClass(Src s, ClassTree ct, ClassInfo outer) {
        ClassInfo c = new ClassInfo();
        c.src = s;
        c.tree = ct;
        c.outer = outer;
        c.simple = ct.getSimpleName().toString();
        c.pkg = s.pkg;
        c.fqn = outer == null ? (s.pkg.isEmpty() ? c.simple : s.pkg + "." + c.simple) : outer.fqn + "." + c.simple;
        c.kind = ct.getKind().toString().toLowerCase();
        c.line = line(s, ct);
        c.isStatic = ct.getModifiers().getFlags().contains(Modifier.STATIC) || outer == null;
        c.isPublic = ct.getModifiers().getFlags().contains(Modifier.PUBLIC);
        c.isAbstract = ct.getModifiers().getFlags().contains(Modifier.ABSTRACT);
        c.privateClass = ct.getModifiers().getFlags().contains(Modifier.PRIVATE);
        for (AnnotationTree a : ct.getModifiers().getAnnotations()) c.annotations.add(simpleName(a.getAnnotationType().toString()));
        if (ct.getExtendsClause() != null) c.superName = ct.getExtendsClause().toString().replaceAll("<.*>", "");
        for (Tree i : ct.getImplementsClause()) c.interfaces.add(i.toString().replaceAll("<.*>", ""));
        if (outer != null) outer.inner.add(c);
        byFqn.put(c.fqn, c);
        bySimple.computeIfAbsent(c.simple, k -> new ArrayList<>()).add(c);
        for (Tree m : ct.getMembers()) {
            if (m instanceof VariableTree) {
                VariableTree v = (VariableTree) m;
                FieldInfo f = new FieldInfo();
                f.name = v.getName().toString();
                f.type = v.getType() == null ? "var" : v.getType().toString();
                f.init = v.getInitializer();
                var flags = v.getModifiers().getFlags();
                boolean iface = ct.getKind() == Tree.Kind.INTERFACE;
                f.isStatic = flags.contains(Modifier.STATIC) || iface || ct.getKind() == Tree.Kind.ENUM && f.type.equals(c.simple);
                f.isFinal = flags.contains(Modifier.FINAL) || iface;
                f.isPublic = flags.contains(Modifier.PUBLIC) || iface;
                f.isPrivate = flags.contains(Modifier.PRIVATE);
                f.line = line(s, v);
                f.owner = c;
                f.tree = v;
                c.fields.put(f.name, f);
            } else if (m instanceof MethodTree) {
                MethodTree mt = (MethodTree) m;
                MethodInfo mi = new MethodInfo();
                mi.name = mt.getName().toString();
                mi.isCtor = mi.name.equals("<init>");
                mi.returnType = mt.getReturnType() == null ? "" : mt.getReturnType().toString();
                mi.params.addAll(mt.getParameters());
                mi.body = mt.getBody();
                var flags = mt.getModifiers().getFlags();
                mi.isStatic = flags.contains(Modifier.STATIC);
                mi.isPublic = flags.contains(Modifier.PUBLIC) || ct.getKind() == Tree.Kind.INTERFACE;
                mi.isPrivate = flags.contains(Modifier.PRIVATE);
                mi.line = line(s, mt);
                mi.owner = c;
                mi.tree = mt;
                c.methods.add(mi);
            } else if (m instanceof ClassTree) {
                addClass(s, (ClassTree) m, c);
            }
        }
    }

    // ---------------- positions ----------------

    public int line(Src s, Tree t) {
        long p = pos.getStartPosition(s.cu, t);
        return p < 0 ? 0 : (int) s.cu.getLineMap().getLineNumber(p);
    }

    public int endLine(Src s, Tree t) {
        long p = pos.getEndPosition(s.cu, t);
        return p < 0 ? 0 : (int) s.cu.getLineMap().getLineNumber(p);
    }

    public long start(Src s, Tree t) { return pos.getStartPosition(s.cu, t); }

    public long end(Src s, Tree t) { return pos.getEndPosition(s.cu, t); }

    /** The source text of a tree exactly as the team wrote it (formatting kept). */
    public String text(Src s, Tree t) {
        long a = start(s, t), b = end(s, t);
        if (a < 0 || b < 0 || b > s.text.length()) return t.toString();
        return s.text.substring((int) a, (int) b);
    }

    // ---------------- types ----------------

    public static String simpleName(String dotted) {
        int i = dotted.lastIndexOf('.');
        return i < 0 ? dotted : dotted.substring(i + 1);
    }

    /**
     * A type name as written in `ctx` ("Config.Hardware", "Flywheel", "org.x.Robot") -> the project's class,
     * or null when it is not a team class (SDK / library types).
     */
    public ClassInfo resolveType(String name, ClassInfo ctx) {
        if (name == null || name.isEmpty()) return null;
        name = name.replaceAll("<.*>", "").replace("[]", "").trim();
        if (byFqn.containsKey(name)) return byFqn.get(name);
        String[] parts = name.split("\\.");
        ClassInfo head = resolveSimple(parts[0], ctx);
        if (head == null) {
            // a fully qualified name with a package prefix: org.x.Config.Hardware
            for (int i = parts.length - 1; i > 0; i--) {
                String pre = String.join(".", java.util.Arrays.copyOfRange(parts, 0, i + 1));
                if (byFqn.containsKey(pre)) {
                    ClassInfo c = byFqn.get(pre);
                    for (int j = i + 1; j < parts.length && c != null; j++) c = nested(c, parts[j]);
                    return c;
                }
            }
            return null;
        }
        ClassInfo c = head;
        for (int i = 1; i < parts.length && c != null; i++) c = nested(c, parts[i]);
        return c;
    }

    private static ClassInfo nested(ClassInfo c, String simple) {
        for (ClassInfo in : c.inner) if (in.simple.equals(simple)) return in;
        return null;
    }

    private ClassInfo resolveSimple(String simple, ClassInfo ctx) {
        if (ctx != null) {
            // the class itself, its nested classes, and the classes it is nested in (and their members)
            for (ClassInfo c = ctx; c != null; c = c.outer) {
                if (c.simple.equals(simple)) return c;
                ClassInfo n = nested(c, simple);
                if (n != null) return n;
            }
            // inherited nested classes (one level is enough for FTC code)
            ClassInfo sup = ctx.superName.isEmpty() ? null : resolveType(ctx.superName, ctx.outer);
            if (sup != null && sup != ctx) {
                ClassInfo n = nested(sup, simple);
                if (n != null) return n;
            }
            Src s = ctx.src;
            for (String imp : s.imports) {
                if (imp.endsWith("." + simple) && byFqn.containsKey(imp)) return byFqn.get(imp);
                if (imp.endsWith(".*")) {
                    String f = imp.substring(0, imp.length() - 2) + "." + simple;
                    if (byFqn.containsKey(f)) return byFqn.get(f);
                }
            }
            for (String imp : s.imports) if (imp.endsWith("." + simple)) return null; // imported from a library
            String samePkg = s.pkg.isEmpty() ? simple : s.pkg + "." + simple;
            if (byFqn.containsKey(samePkg)) return byFqn.get(samePkg);
        }
        List<ClassInfo> l = bySimple.get(simple);
        if (l != null) {
            List<ClassInfo> tops = new ArrayList<>();
            for (ClassInfo c : l) if (c.outer == null) tops.add(c);
            if (tops.size() == 1) return tops.get(0);
            if (l.size() == 1) return l.get(0);
        }
        return null;
    }

    /** The fully qualified name of a library type used in `ctx` (from its imports), or "" when unknown. */
    public static String importedFqn(String simple, ClassInfo ctx) {
        for (String imp : ctx.src.imports) if (imp.endsWith("." + simple)) return imp;
        return "";
    }

    /** Does `c` (or one of its project superclasses) extend / implement a type whose simple name is in `names`? */
    public boolean isA(ClassInfo c, String... names) {
        for (int guard = 0; c != null && guard < 8; guard++) {
            for (String n : names) {
                if (simpleName(c.superName).equals(n)) return true;
                for (String i : c.interfaces) if (simpleName(i).equals(n)) return true;
            }
            c = c.superName.isEmpty() ? null : resolveType(c.superName, c);
        }
        return false;
    }

    /** The project superclass of `c` (BaseOpMode for Auto2), or null. */
    public ClassInfo superOf(ClassInfo c) {
        return c == null || c.superName.isEmpty() ? null : resolveType(c.superName, c);
    }

    /** A field of `c` or of its project superclasses. */
    public FieldInfo field(ClassInfo c, String name) {
        for (int guard = 0; c != null && guard < 8; guard++) {
            FieldInfo f = c.fields.get(name);
            if (f != null) return f;
            c = c.superName.isEmpty() ? null : resolveType(c.superName, c);
        }
        return null;
    }

    public List<MethodInfo> methods(ClassInfo c, String name) {
        List<MethodInfo> out = new ArrayList<>();
        for (int guard = 0; c != null && guard < 8; guard++) {
            out.addAll(c.methods(name));
            c = c.superName.isEmpty() ? null : resolveType(c.superName, c);
        }
        return out;
    }

    public List<ClassInfo> classes() { return new ArrayList<>(byFqn.values()); }

    /** "a.b.c" for identifiers and member selects; null for anything else (calls, literals...). */
    public static String dotted(ExpressionTree e) {
        if (e instanceof IdentifierTree) return ((IdentifierTree) e).getName().toString();
        if (e instanceof MemberSelectTree) {
            String l = dotted(((MemberSelectTree) e).getExpression());
            return l == null ? null : l + "." + ((MemberSelectTree) e).getIdentifier();
        }
        return null;
    }
}
