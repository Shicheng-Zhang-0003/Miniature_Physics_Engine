package org.beesim.team.gen;

import org.beesim.team.Json;
import org.beesim.team.PedroApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Pedro Pathing 3.0.x (com.pedropathing:core + revhub). Verified API (resources/pedro-api/3.*.json):
 * math.Pose(x, y, heading) with x()/y()/heading(), api.Paths.line(Pose, Pose).linear(Pose, Pose) / .constant(double)
 * -> paths.Path, follower.follow(Path), hold(Pose), isBusy(), pose(), update(), setPose(Pose).
 */
public final class Pedro3Adapter extends PedroAdapter {
    static final String F = "com.pedropathing.follower.Follower";
    static final String POSE = "com.pedropathing.math.Pose";
    static final String PATH = "com.pedropathing.paths.Path";
    static final String PATHS = "com.pedropathing.api.Paths";
    static final String FS = "com.pedropathing.algorithm.ForesightConfig";

    Pedro3Adapter(PedroApi api) { super(api); }

    @Override public String label() { return "Pedro Pathing " + api.version + " (3.x adapter)"; }

    @Override public List<String[]> required() {
        List<String[]> r = new ArrayList<>();
        r.add(new String[]{F, "update"});
        r.add(new String[]{F, "setPose", POSE});
        r.add(new String[]{F, "follow", PATH});
        r.add(new String[]{F, "hold", POSE});
        r.add(new String[]{F, "isBusy"});
        r.add(new String[]{F, "pose"});
        r.add(new String[]{POSE, "<init>", "double", "double", "double"});
        r.add(new String[]{POSE, "x"});
        r.add(new String[]{POSE, "y"});
        r.add(new String[]{POSE, "heading"});
        r.add(new String[]{PATHS, "line", POSE, POSE});
        r.add(new String[]{PATH, "linear", POSE, POSE});
        r.add(new String[]{PATH, "constant", "double"});
        return r;
    }

    @Override public List<String> imports() { return List.of(F, POSE, PATH, PATHS); }

    @Override public String poseType() { return "Pose"; }

    @Override public String pathType() { return "Path"; }

    @Override public String newPose(String x, String y, String h) { return "new Pose(" + x + ", " + y + ", " + h + ")"; }

    @Override public String x(String p) { return p + ".x()"; }

    @Override public String y(String p) { return p + ".y()"; }

    @Override public String heading(String p) { return p + ".heading()"; }

    @Override public String line(String f, String a, String b, String mode) {
        return "Paths.line(" + a + ", " + b + ")" + (mode.equals("constant") ? ".constant(" + heading(b) + ")" : ".linear(" + a + ", " + b + ")");
    }

    @Override public List<String> follow(String f, String path, double maxPower, List<String> notes) {
        if (maxPower < 0.999) notes.add("Pedro 3.x follow(Path) has no max-power argument: the speed " + Gen.num(maxPower) + " set in BEE is not applied (the path runs at the speed Foresight plans).");
        return List.of(f + ".follow(" + path + ");");
    }

    @Override public List<String> followWithPower(String f, String path, String powerVar) {
        return List.of(f + ".follow(" + path + ");");
    }

    @Override public boolean supportsMaxPower() { return false; }

    @Override public String isBusy(String f) { return f + ".isBusy()"; }

    @Override public String pose(String f) { return f + ".pose()"; }

    @Override public List<String> holdHere(String f) { return List.of(f + ".hold(" + f + ".pose());"); }

    @Override public List<String> turnTo(String f, String rad) {
        return List.of(f + ".hold(new Pose(" + f + ".pose().x(), " + f + ".pose().y(), " + rad + "));");
    }

    /** 3.x: hold() keeps the follower in HOLD mode; the turn is done when the heading error is small. */
    @Override public String turning(String f, String rad) {
        return "Math.abs(angleDiff(" + rad + ", " + f + ".pose().heading())) > TURN_TOLERANCE_RAD";
    }

    @Override public String update(String f) { return f + ".update();"; }

    @Override public String setStartingPose(String f, String p) { return f + ".setPose(" + p + ");"; }

    @Override public List<Map<String, Object>> tuningSchema() {
        List<Map<String, Object>> s = new ArrayList<>();
        String[][] rows = {
                {"maxAchievableForwardVelocity", "Max forward velocity", "in/s", "positive", "maxAchievableForwardVelocity"},
                {"maxAchievableStrafeVelocity", "Max strafe velocity", "in/s", "positive", "maxAchievableStrafeVelocity"},
                {"naturalForwardDeceleration", "Natural forward deceleration", "in/s²", "positive", "naturalForwardDeceleration"},
                {"naturalStrafeDeceleration", "Natural strafe deceleration", "in/s²", "positive", "naturalStrafeDeceleration"},
                {"headingFeedback", "Heading kP", "", "positive", "heading kP"},
                {"coast", "Coast kV", "", "positive", "coast kV"},
                {"brake", "Brake kV", "", "positive", "brake kV"},
                {"headingBrakeCoefficients", "Heading braking (linear, quadratic)", "", "positive", null},
                {"linearBrakeCoefficients", "Linear braking (forward, strafe)", "", "positive", null},
                {"quadraticBrakeCoefficients", "Quadratic braking (forward, strafe)", "", "positive", null},
                {"forwardTranslational", "Forward translational controller", "", "positive", null},
                {"strafeTranslational", "Strafe translational controller", "", "positive", null},
        };
        List<String> fields = api.members(FS);
        for (String[] r : rows) {
            boolean exists = false;
            for (String m : fields) if (m.matches(".*\\b" + r[0] + "\\b.*") && !m.contains("(")) exists = true;
            if (!exists) continue;
            s.add(Json.obj("key", "ForesightConfig." + r[0], "builder", "ForesightConfig", "method", r[0], "type", "config_var", "label", r[1], "unit", r[2],
                    "sign", r[3], "sim_key", r[4], "sim_transform", r[4] == null ? null : "identity", "verified", true, "default", null));
        }
        return s;
    }
}
