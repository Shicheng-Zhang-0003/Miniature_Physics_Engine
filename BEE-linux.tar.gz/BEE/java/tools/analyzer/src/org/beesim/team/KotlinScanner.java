package org.beesim.team;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Kotlin files, read with a token-level scanner (the JDK has no Kotlin parser). Everything found here is LOW
 * confidence and shown to the user for confirmation. Generated code stays Java and calls Kotlin with the
 * standard interop rules: object X { fun f() } -> X.INSTANCE.f(); const val / @JvmField -> X.NAME.
 */
public final class KotlinScanner {
    public final List<Map<String, Object>> devices = new ArrayList<>();
    public final List<Map<String, Object>> classes = new ArrayList<>();
    public final List<Map<String, Object>> constants = new ArrayList<>();

    private static final Pattern GET_JAVA = Pattern.compile("hardwareMap(?:\\(\\))?\\s*\\.\\s*get\\(\\s*(\\w+)::class\\.java\\s*,\\s*(\"[^\"]*\"|[\\w.]+)\\s*\\)");
    private static final Pattern GET_REIFIED = Pattern.compile("hardwareMap(?:\\(\\))?\\s*\\.\\s*get<\\s*(\\w+)\\s*>\\(\\s*(\"[^\"]*\"|[\\w.]+)\\s*\\)");
    private static final Pattern NEXTFTC_DEV = Pattern.compile("\\b(MotorEx|ServoEx|CRServoEx|Motor|Servo)\\(\\s*(\"[^\"]*\")");
    private static final Pattern CONST = Pattern.compile("(?:const\\s+val|@JvmField\\s+(?:var|val)|@JvmStatic\\s+(?:var|val))\\s+(\\w+)\\s*(?::\\s*[\\w<>?]+)?\\s*=\\s*([^\\n;]+)");
    private static final Pattern DECL = Pattern.compile("^\\s*(?:(?:public|internal|private|open|abstract|data|sealed)\\s+)*(object|class|interface)\\s+(\\w+)(?:\\s*\\([^)]*\\))?\\s*(?::\\s*([^{\\n]+))?", Pattern.MULTILINE);
    private static final Pattern FUN = Pattern.compile("^\\s*(?:(?:public|internal|private|override|open|suspend)\\s+)*fun\\s+(\\w+)\\s*\\(([^)]*)\\)\\s*(?::\\s*([\\w<>?.]+))?", Pattern.MULTILINE);
    private static final Pattern PROP = Pattern.compile("^\\s*(?:(?:public|internal|private|override|open|lateinit)\\s+)*(val|var)\\s+(\\w+)\\s*(?::\\s*([\\w<>?.]+))?\\s*(?:=\\s*([^\\n]+)|by\\s+[^\\n]+|get\\(\\))?", Pattern.MULTILINE);

    public static KotlinScanner scan(Map<String, String> files) {
        KotlinScanner k = new KotlinScanner();
        for (Map.Entry<String, String> e : files.entrySet()) k.file(e.getKey(), GradleScanner.stripComments(e.getValue(), false));
        return k;
    }

    private void file(String f, String t) {
        Map<String, String> strConsts = new LinkedHashMap<>();
        Matcher m = CONST.matcher(t);
        while (m.find()) {
            String v = m.group(2).trim();
            constants.add(Json.obj("name", m.group(1), "value", v, "file", f, "line", GradleScanner.lineOf(t, m.start()), "confidence", Fact.LOW));
            if (v.startsWith("\"")) strConsts.put(m.group(1), v.replace("\"", ""));
        }
        for (Pattern p : new Pattern[]{GET_JAVA, GET_REIFIED, NEXTFTC_DEV}) {
            m = p.matcher(t);
            while (m.find()) {
                String raw = m.group(2);
                String name = raw.startsWith("\"") ? raw.substring(1, raw.length() - 1) : strConsts.get(raw.substring(raw.lastIndexOf('.') + 1));
                devices.add(Json.obj("name", Fact.of(name, f, GradleScanner.lineOf(t, m.start()), Fact.LOW, m.group(0)), "java_type", m.group(1),
                        "kind", Hardware.KINDS.getOrDefault(m.group(1), "other"), "file", f, "line", GradleScanner.lineOf(t, m.start())));
            }
        }
        // classes / objects with their members: the region from one declaration to the next
        List<int[]> spans = new ArrayList<>();
        m = DECL.matcher(t);
        while (m.find()) {
            spans.add(new int[]{m.start(), t.length()});
            Map<String, Object> c = Json.obj("kind", m.group(1), "name", m.group(2), "supertypes", m.group(3) == null ? "" : m.group(3).trim(),
                    "file", f, "line", GradleScanner.lineOf(t, m.start()), "confidence", Fact.LOW, "functions", new ArrayList<>(), "properties", new ArrayList<>(),
                    "java_access", m.group(1).equals("object") ? m.group(2) + ".INSTANCE" : null);
            classes.add(c);
        }
        int base = classes.size() - spans.size();
        for (int i = 0; i < spans.size(); i++) {
            int a = spans.get(i)[0], b = i + 1 < spans.size() ? spans.get(i + 1)[0] : t.length();
            String region = t.substring(a, b);
            Map<String, Object> c = classes.get(base + i);
            @SuppressWarnings("unchecked") List<Object> fns = (List<Object>) c.get("functions");
            @SuppressWarnings("unchecked") List<Object> props = (List<Object>) c.get("properties");
            Matcher fm = FUN.matcher(region);
            while (fm.find()) fns.add(Json.obj("name", fm.group(1), "params", fm.group(2).trim(), "returns", fm.group(3) == null ? "Unit" : fm.group(3),
                    "line", GradleScanner.lineOf(t, a + fm.start())));
            Matcher pm = PROP.matcher(region);
            while (pm.find()) {
                String name = pm.group(2);
                String getter = "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1) + "()";
                props.add(Json.obj("name", name, "type", pm.group(3), "init", pm.group(4) == null ? null : pm.group(4).trim(), "java_getter", getter,
                        "line", GradleScanner.lineOf(t, a + pm.start())));
            }
        }
    }

    public Map<String, Object> json() {
        return Json.obj("devices", devices, "classes", classes, "constants", constants, "confidence", Fact.LOW,
                "note", devices.isEmpty() && classes.isEmpty() ? null : "Kotlin is read with a token scanner: confirm these facts.");
    }
}
