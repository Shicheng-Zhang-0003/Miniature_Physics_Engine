package org.beesim.team;

import com.sun.source.tree.AssignmentTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.IdentifierTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.TreePath;
import org.beesim.team.JavaIndex.ClassInfo;
import org.beesim.team.JavaIndex.MethodInfo;
import org.beesim.team.Walk.Hit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Every device the team gets from the hardwareMap: its configured name (through constants and constructor /
 * method parameters), its Java type, WHERE it ends up (class + field: Flywheel.motor1), and how the team
 * configures it there (direction, run mode sequence, zero-power behavior, servo positions used).
 */
public final class Hardware {

    public static final class Device {
        public String name, nameRef, nameImport, javaType, kind, confidence, evidence;
        public String file;
        public int line;
        public ClassInfo owner;      // class holding the field (Flywheel)
        public String field;         // field name (motor1), or a local variable when owner == null
        public ClassInfo declaredIn; // class where hardwareMap.get(...) is written (Robot)
        public final List<String> via = new ArrayList<>();
        public final List<String> alsoDeclaredIn = new ArrayList<>();
        public final List<Map<String, Object>> config = new ArrayList<>(); // setDirection / setMode / ... in order
        public final List<Map<String, Object>> positions = new ArrayList<>(); // setPosition(...) uses, per method
        public String direction, directionRef, mode, modeRef, zeroPower, zeroPowerRef;
        public boolean resetsEncoder;

        Map<String, Object> json() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", Fact.of(name, file, line, confidence, evidence));
            if (nameRef != null) m.put("name_ref", nameRef);
            if (nameImport != null) m.put("name_import", nameImport);
            m.put("java_type", javaType);
            m.put("kind", kind);
            m.put("owner_class", owner == null ? null : owner.fqn);
            m.put("owner_ref", owner == null ? null : owner.ref());
            m.put("field", field);
            JavaIndex.FieldInfo fi = owner == null || field == null ? null : owner.fields.get(field);
            m.put("field_public", fi != null && fi.isPublic);
            m.put("declared_in", declaredIn == null ? null : declaredIn.fqn);
            m.put("via", via);
            m.put("also_declared_in", alsoDeclaredIn);
            m.put("direction", direction == null ? null : Fact.of(direction, cfgFile("setDirection"), cfgLine("setDirection"), Fact.HIGH, directionRef));
            m.put("run_mode", mode == null ? null : Fact.of(mode, cfgFile("setMode"), cfgLine("setMode"), Fact.HIGH, modeRef));
            m.put("resets_encoder", resetsEncoder);
            m.put("zero_power", zeroPower == null ? null : Fact.of(zeroPower, cfgFile("setZeroPowerBehavior"), cfgLine("setZeroPowerBehavior"), Fact.HIGH, zeroPowerRef));
            m.put("init_calls", config);
            m.put("positions_used", positions);
            return m;
        }

        private Map<String, Object> lastCfg(String method) {
            Map<String, Object> last = null;
            for (Map<String, Object> c : config) if (method.equals(c.get("method")) && Boolean.TRUE.equals(c.get("init"))) last = c;
            return last;
        }

        private String cfgFile(String method) { Map<String, Object> c = lastCfg(method); return c == null ? file : (String) c.get("file"); }

        private int cfgLine(String method) { Map<String, Object> c = lastCfg(method); return c == null ? line : (int) c.get("line"); }
    }

    static final Map<String, String> KINDS = new HashMap<>();
    static {
        for (String t : new String[]{"DcMotor", "DcMotorEx", "DcMotorSimple", "DcMotorImplEx", "Motor", "MotorEx"}) KINDS.put(t, "motor");
        for (String t : new String[]{"Servo", "ServoImplEx", "ServoEx", "SimpleServo"}) KINDS.put(t, "servo");
        for (String t : new String[]{"CRServo", "CRServoImplEx", "CRServoEx"}) KINDS.put(t, "crservo");
        for (String t : new String[]{"IMU", "BNO055IMU", "BHI260IMU"}) KINDS.put(t, "imu");
        KINDS.put("GoBildaPinpointDriver", "pinpoint");
        KINDS.put("Limelight3A", "limelight");
        KINDS.put("LynxModule", "hub");
        for (String t : new String[]{"ColorSensor", "NormalizedColorSensor", "RevColorSensorV3", "ColorRangeSensor"}) KINDS.put(t, "color");
        for (String t : new String[]{"DistanceSensor", "Rev2mDistanceSensor"}) KINDS.put(t, "distance");
        for (String t : new String[]{"TouchSensor", "RevTouchSensor", "DigitalChannel"}) KINDS.put(t, "touch");
        KINDS.put("WebcamName", "webcam");
        KINDS.put("AnalogInput", "analog");
        KINDS.put("VoltageSensor", "voltage");
        KINDS.put("SparkFunOTOS", "otos");
    }
    // FTCLib / SolversLib wrappers: new MotorEx(hardwareMap, "name", ...)
    static final String[] LIB_CTORS = {"MotorEx", "Motor", "SimpleServo", "ServoEx", "CRServo", "CRServoEx", "MotorGroup"};
    static final Map<String, String> OLD_MAP = Map.of("dcMotor", "DcMotor", "servo", "Servo", "crservo", "CRServo", "colorSensor", "ColorSensor",
            "touchSensor", "TouchSensor", "voltageSensor", "VoltageSensor", "digitalChannel", "DigitalChannel", "analogInput", "AnalogInput");

    private final JavaIndex ix;
    private final Eval ev;
    public final List<Device> devices = new ArrayList<>();
    public Map<String, Object> bulkCaching;
    public final List<Map<String, Object>> warnings = new ArrayList<>();

    public Hardware(JavaIndex ix, Eval ev) { this.ix = ix; this.ev = ev; }

    /** hardwareMap, opMode.hardwareMap, or any variable / parameter / field declared as HardwareMap (hw, hwMap...). */
    boolean isHardwareMap(ExpressionTree e, ClassInfo c, MethodInfo m) {
        if (isHardwareMap(e)) return true;
        String d = JavaIndex.dotted(e);
        if (d == null || d.contains(".")) return false;
        if (m != null) {
            for (var p : m.params) if (p.getName().contentEquals(d) && JavaIndex.simpleName(p.getType().toString()).equals("HardwareMap")) return true;
            for (Hit h : Walk.find(c, m, t -> t instanceof VariableTree && ((VariableTree) t).getName().contentEquals(d)))
                if (JavaIndex.simpleName(String.valueOf(((VariableTree) h.leaf()).getType())).equals("HardwareMap")) return true;
        }
        JavaIndex.FieldInfo f = ix.field(c, d);
        return f != null && JavaIndex.simpleName(f.type).equals("HardwareMap");
    }

    private boolean inOpMode(ClassInfo c) {
        return c != null && (ix.isA(c, "OpMode", "LinearOpMode", "CommandOpMode", "SelectableOpMode") || c.annotations.contains("TeleOp") || c.annotations.contains("Autonomous"));
    }

    static boolean isHardwareMap(ExpressionTree e) {
        if (e == null) return false;
        String d = JavaIndex.dotted(e);
        if (d != null) return d.equals("hardwareMap") || d.endsWith(".hardwareMap");
        // ActiveOpMode.hardwareMap() (NextFTC), opMode.hardwareMap()
        return e instanceof MethodInvocationTree && Walk.methodName((MethodInvocationTree) e).equals("hardwareMap");
    }

    public void run() {
        for (ClassInfo c : ix.classes()) {
            for (Hit h : Walk.find(c, t -> t instanceof MethodInvocationTree || t instanceof NewClassTree)) {
                Tree t = h.leaf();
                if (t instanceof MethodInvocationTree) {
                    MethodInvocationTree m = (MethodInvocationTree) t;
                    String fn = Walk.methodName(m);
                    ExpressionTree sel = m.getMethodSelect();
                    if (!(sel instanceof MemberSelectTree)) continue;
                    ExpressionTree recv = ((MemberSelectTree) sel).getExpression();
                    if (fn.equals("get") && isHardwareMap(recv, c, h.method) && m.getArguments().size() == 2 && m.getArguments().get(0) instanceof MemberSelectTree
                            && ((MemberSelectTree) m.getArguments().get(0)).getIdentifier().contentEquals("class")) {
                        String type = ((MemberSelectTree) m.getArguments().get(0)).getExpression().toString();
                        found(h, type, m.getArguments().get(1), "hardwareMap.get(" + type + ".class, " + m.getArguments().get(1) + ")");
                    } else if (fn.equals("get") && recv instanceof MemberSelectTree && isHardwareMap(((MemberSelectTree) recv).getExpression(), c, h.method)
                            && OLD_MAP.containsKey(((MemberSelectTree) recv).getIdentifier().toString()) && m.getArguments().size() == 1) {
                        String type = OLD_MAP.get(((MemberSelectTree) recv).getIdentifier().toString());
                        found(h, type, m.getArguments().get(0), m.toString());
                    } else if (fn.equals("setBulkCachingMode") && !m.getArguments().isEmpty()) {
                        Val v = ev.eval(m.getArguments().get(0), c);
                        String mode = v != null && v.kind == Val.K.ENUM ? v.str : m.getArguments().get(0).toString();
                        bulkCaching = Fact.of(mode, c.src.path, h.line(ix), Fact.HIGH, m.toString());
                        bulkCaching.put("class", c.fqn);
                        bulkCaching.put("method", h.method == null ? null : h.method.name);
                    }
                } else {
                    NewClassTree n = (NewClassTree) t;
                    String type = JavaIndex.simpleName(n.getIdentifier().toString().replaceAll("<.*>", ""));
                    if (ix.resolveType(type, c) != null) continue; // a team class with the same name
                    for (String lib : LIB_CTORS) {
                        if (lib.equals(type) && n.getArguments().size() >= 2 && isHardwareMap(n.getArguments().get(0), c, h.method)) {
                            found(h, type, n.getArguments().get(1), n.toString());
                        }
                    }
                }
            }
        }
        // the same device built in several places (Robot, and again in a tuning OpMode): one entry, every site kept
        // the robot's own classes come first: a tuning OpMode is not where the robot is defined
        devices.sort((a, b) -> Boolean.compare(inOpMode(a.declaredIn), inOpMode(b.declaredIn)));
        List<Device> merged = new ArrayList<>();
        for (Device d : devices) {
            Device same = null;
            for (Device m : merged)
                if (java.util.Objects.equals(m.name, d.name) && (m.owner == d.owner && java.util.Objects.equals(m.field, d.field) && m.owner != null
                        || inOpMode(d.declaredIn) && d.owner == d.declaredIn && d.javaType.equals(m.javaType))) same = m;
            if (same == null) { merged.add(d); continue; }
            same.alsoDeclaredIn.add(d.file + ":" + d.line);
            if (Fact.rank(d.confidence) > Fact.rank(same.confidence)) same.confidence = d.confidence;
        }
        devices.clear();
        devices.addAll(merged);
        for (Device d : devices) configure(d);
    }

    // ---------------- one hardwareMap.get(...) ----------------

    private void found(Hit h, String type, ExpressionTree nameExpr, String evidence) {
        List<Object[]> names = new ArrayList<>(); // {Val, confidence, via}
        resolveName(nameExpr, h.cls, h.method, 0, Fact.HIGH, new ArrayList<>(), names);
        if (names.isEmpty()) {
            warnings.add(Json.obj("file", h.cls.src.path, "line", h.line(ix), "message",
                    "Cannot tell the hardware name in " + evidence + " (it comes from somewhere the analysis cannot follow). Confirm it in BEE."));
            Object[] unknown = {null, Fact.LOW, List.of("unresolved: " + nameExpr)};
            names.add(unknown);
        }
        for (Object[] nm : names) {
            Device d = new Device();
            Val v = (Val) nm[0];
            d.name = v == null ? null : v.str;
            d.nameRef = v == null ? null : v.ref;
            d.nameImport = v == null ? null : v.imp;
            d.confidence = (String) nm[1];
            @SuppressWarnings("unchecked") List<String> via = (List<String>) nm[2];
            d.via.addAll(via);
            d.javaType = JavaIndex.simpleName(type);
            d.kind = KINDS.getOrDefault(d.javaType, "other");
            d.file = h.cls.src.path;
            d.line = h.line(ix);
            d.evidence = evidence;
            d.declaredIn = h.cls;
            destination(d, h.cls, h.method, h.path, 0);
            devices.add(d);
        }
    }

    /**
     * The name expression -> string value(s). A parameter of a constructor / method is followed to every call
     * site (new Lift(hardwareMap, "lift"), intake.init(this, Names.INTAKE)), with lower confidence.
     */
    private void resolveName(ExpressionTree e, ClassInfo c, MethodInfo m, int depth, String conf, List<String> via, List<Object[]> out) {
        Val v = ev.eval(e, c);
        if (v != null && v.kind == Val.K.STR) {
            out.add(new Object[]{v, v.ref != null ? Fact.min(conf, Fact.HIGH) : conf, new ArrayList<>(via)});
            return;
        }
        if (depth > 4 || m == null || !(e instanceof IdentifierTree)) return;
        int pi = m.paramIndex(((IdentifierTree) e).getName().toString());
        if (pi < 0) return;
        for (Object[] site : callSites(m)) {
            ClassInfo cc = (ClassInfo) site[0];
            MethodInfo cm = (MethodInfo) site[1];
            @SuppressWarnings("unchecked") List<? extends ExpressionTree> args = (List<? extends ExpressionTree>) site[2];
            if (pi >= args.size()) continue;
            List<String> v2 = new ArrayList<>(via);
            v2.add("parameter '" + m.params.get(pi).getName() + "' of " + m.owner.simple + (m.isCtor ? "(...)" : "." + m.name + "(...)") + " <- " + cc.src.path + ":" + site[3]);
            resolveName(args.get(pi), cc, cm, depth + 1, Fact.MEDIUM, v2, out);
        }
    }

    /** {callerClass, callerMethod, args, line} for every call of `m` (constructor: new X(..); method: x.m(..) with the same arity). */
    List<Object[]> callSites(MethodInfo m) {
        List<Object[]> out = new ArrayList<>();
        for (ClassInfo c : ix.classes()) {
            for (Hit h : Walk.find(c, t -> t instanceof NewClassTree || t instanceof MethodInvocationTree)) {
                if (m.isCtor && h.leaf() instanceof NewClassTree) {
                    NewClassTree n = (NewClassTree) h.leaf();
                    ClassInfo t = ix.resolveType(n.getIdentifier().toString(), c);
                    if (t == m.owner && n.getArguments().size() == m.params.size())
                        out.add(new Object[]{c, h.method, n.getArguments(), h.line(ix)});
                } else if (m.isCtor && h.leaf() instanceof MethodInvocationTree) {
                    // super(hardwareMap, "name") from a subclass constructor
                    MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
                    if (Walk.methodName(mi).equals("super") && ix.resolveType(c.superName, c) == m.owner && mi.getArguments().size() == m.params.size())
                        out.add(new Object[]{c, h.method, mi.getArguments(), h.line(ix)});
                } else if (!m.isCtor && h.leaf() instanceof MethodInvocationTree) {
                    MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
                    if (Walk.methodName(mi).equals(m.name) && mi.getArguments().size() == m.params.size())
                        out.add(new Object[]{c, h.method, mi.getArguments(), h.line(ix)});
                }
            }
        }
        return out;
    }

    /** Where the device ends up: a field (directly, or through a constructor / method parameter), or a local variable. */
    private void destination(Device d, ClassInfo c, MethodInfo m, TreePath self, int depth) {
        // skip ( ) and casts: (DcMotorEx) hardwareMap.get(...)
        TreePath childPath = self;
        TreePath p = self.getParentPath();
        while (p != null && (p.getLeaf().getKind() == Tree.Kind.PARENTHESIZED || p.getLeaf().getKind() == Tree.Kind.TYPE_CAST)) {
            childPath = p;
            p = p.getParentPath();
        }
        if (p == null || depth > 4) return;
        Tree parent = p.getLeaf();
        Tree child = childPath.getLeaf();
        if (parent instanceof AssignmentTree) {
            String written = JavaIndex.dotted(((AssignmentTree) parent).getVariable());
            if (written == null) return;  // motors[0] = ...
            String target = written.startsWith("this.") ? written.substring(5) : written;
            boolean shadowed = m != null && m.paramIndex(target) >= 0 && !written.startsWith("this.");
            if (!target.contains(".") && ix.field(c, target) != null && !shadowed) {
                d.owner = c;
                d.field = target;
            } else if (!target.contains(".")) {
                localDestination(d, c, m, target, depth);
            }
        } else if (parent instanceof VariableTree) {
            String n = ((VariableTree) parent).getName().toString();
            if (m == null && c.fields.containsKey(n)) {
                d.owner = c;
                d.field = n;
            } else {
                localDestination(d, c, m, n, depth);
            }
        } else if (parent instanceof NewClassTree || parent instanceof MethodInvocationTree) {
            // passed on: new Flywheel(hardwareMap.get(...), ...) -> the parameter -> this.motor1 = motor1
            List<? extends ExpressionTree> args = parent instanceof NewClassTree ? ((NewClassTree) parent).getArguments() : ((MethodInvocationTree) parent).getArguments();
            int idx = args.indexOf(child);
            if (idx < 0) return;
            MethodInfo callee = callee(parent, c, args.size());
            if (callee == null) return;
            d.via.add((callee.isCtor ? "new " + callee.owner.simple : callee.owner.simple + "." + callee.name) + "(...) parameter '" + callee.params.get(idx).getName() + "'");
            paramToField(d, callee, callee.params.get(idx).getName().toString(), depth + 1);
        }
    }

    private MethodInfo callee(Tree call, ClassInfo c, int nargs) {
        if (call instanceof NewClassTree) {
            ClassInfo t = ix.resolveType(((NewClassTree) call).getIdentifier().toString(), c);
            if (t == null) return null;
            for (MethodInfo mi : t.ctors()) if (mi.params.size() == nargs) return mi;
            return null;
        }
        MethodInvocationTree mi = (MethodInvocationTree) call;
        String name = Walk.methodName(mi);
        if (name.equals("super")) {
            ClassInfo t = ix.resolveType(c.superName, c);
            if (t == null) return null;
            for (MethodInfo x : t.ctors()) if (x.params.size() == nargs) return x;
            return null;
        }
        String recv = Walk.receiver(mi);
        ClassInfo t = c;
        if (recv != null) {
            JavaIndex.FieldInfo f = ix.field(c, recv);
            t = f == null ? ix.resolveType(recv, c) : ix.resolveType(f.type, c);
        }
        if (t == null) return null;
        for (MethodInfo x : ix.methods(t, name)) if (x.params.size() == nargs) return x;
        return null;
    }

    /** In `callee`, `this.f = param` (or f = param) gives the field; the parameter may also be passed further on. */
    private void paramToField(Device d, MethodInfo callee, String param, int depth) {
        ClassInfo c = callee.owner;
        for (Hit h : Walk.find(c, callee, t -> t instanceof IdentifierTree && ((IdentifierTree) t).getName().contentEquals(param))) {
            TreePath up = h.up();
            if (up == null) continue;
            Tree p = up.getLeaf();
            if (p instanceof AssignmentTree && ((AssignmentTree) p).getExpression() == h.leaf()) {
                String target = JavaIndex.dotted(((AssignmentTree) p).getVariable());
                if (target == null) continue;
                if (target.startsWith("this.")) target = target.substring(5);
                if (ix.field(c, target) != null) {
                    d.owner = c;
                    d.field = target;
                    return;
                }
            } else if (p instanceof NewClassTree || p instanceof MethodInvocationTree) {
                List<? extends ExpressionTree> args = p instanceof NewClassTree ? ((NewClassTree) p).getArguments() : ((MethodInvocationTree) p).getArguments();
                int idx = args.indexOf(h.leaf());
                if (idx < 0) continue;
                MethodInfo next = callee(p, c, args.size());
                if (next == null || depth > 4) continue;
                d.via.add((next.isCtor ? "new " + next.owner.simple : next.owner.simple + "." + next.name) + "(...) parameter '" + next.params.get(idx).getName() + "'");
                paramToField(d, next, next.params.get(idx).getName().toString(), depth + 1);
                if (d.owner != null) return;
            }
        }
        // kept only as a parameter: the class uses it through the parameter
        d.owner = c;
        d.field = param;
        d.via.add("(kept as parameter '" + param + "' in " + callee + ")");
    }

    /** Device stored in a local variable: configured right there, or passed on into a constructor. */
    private void localDestination(Device d, ClassInfo c, MethodInfo m, String local, int depth) {
        d.owner = null;
        d.field = local;
        d.declaredIn = c;
        if (m == null) return;
        for (Hit h : Walk.find(c, m, t -> t instanceof IdentifierTree && ((IdentifierTree) t).getName().contentEquals(local))) {
            TreePath up = h.up();
            if (up == null) continue;
            Tree p = up.getLeaf();
            if (p instanceof NewClassTree || (p instanceof MethodInvocationTree && ((MethodInvocationTree) p).getArguments().contains(h.leaf()))) {
                List<? extends ExpressionTree> args = p instanceof NewClassTree ? ((NewClassTree) p).getArguments() : ((MethodInvocationTree) p).getArguments();
                int idx = args.indexOf(h.leaf());
                MethodInfo callee = callee(p, c, args.size());
                if (idx < 0 || callee == null) continue;
                d.via.add("local '" + local + "' -> " + (callee.isCtor ? "new " + callee.owner.simple : callee.owner.simple + "." + callee.name) + "(...) parameter '" + callee.params.get(idx).getName() + "'");
                paramToField(d, callee, callee.params.get(idx).getName().toString(), depth + 1);
                return;
            }
        }
    }

    // ---------------- configuration ----------------

    static final String[] CFG = {"setDirection", "setMode", "setZeroPowerBehavior", "setInverted", "setRunMode", "setPosition", "setPwmRange", "scaleRange", "setVelocityPIDFCoefficients", "setPIDFCoefficients", "setTargetPositionTolerance"};

    private static boolean isInitMethod(MethodInfo m) {
        if (m == null) return true;
        String n = m.name.toLowerCase();
        return m.isCtor || n.equals("init") || n.startsWith("init") || n.equals("setup") || n.equals("initialize") || n.equals("runopmode");
    }

    /** setDirection / setMode / setZeroPowerBehavior / setPosition calls on the device's field, in source order. */
    private void configure(Device d) {
        ClassInfo c = d.owner != null ? d.owner : d.declaredIn;
        if (c == null || d.field == null) return;
        List<Hit> calls = Walk.find(c, t -> t instanceof MethodInvocationTree && d.field.equals(Walk.receiver((MethodInvocationTree) t)));
        calls.sort((a, b) -> Long.compare(ix.start(c.src, a.leaf()), ix.start(c.src, b.leaf())));
        for (Hit h : calls) {
            MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
            String fn = Walk.methodName(mi);
            boolean known = false;
            for (String x : CFG) known |= x.equals(fn);
            if (!known) continue;
            Val v = mi.getArguments().isEmpty() ? null : ev.eval(mi.getArguments().get(0), c);
            boolean init = isInitMethod(h.method);
            Map<String, Object> cfg = Json.obj("method", fn, "value", v == null ? (mi.getArguments().isEmpty() ? null : mi.getArguments().get(0).toString()) : v.json(),
                    "in", h.method == null ? "field" : h.method.toString(), "init", init, "file", c.src.path, "line", h.line(ix));
            if (fn.equals("setPosition")) {
                d.positions.add(cfg);
                continue;
            }
            d.config.add(cfg);
            if (!init) continue;
            String val = v == null ? null : (v.kind == Val.K.ENUM ? v.str : v.kind == Val.K.BOOL ? String.valueOf(v.bool) : v.toString());
            switch (fn) {
                case "setDirection": d.direction = val; d.directionRef = v == null ? null : v.ref; break;
                case "setInverted": d.direction = "true".equals(val) ? "REVERSE" : "FORWARD"; d.directionRef = "setInverted(" + val + ")"; break;
                case "setMode": case "setRunMode":
                    if ("STOP_AND_RESET_ENCODER".equals(val)) d.resetsEncoder = true;
                    d.mode = val;
                    d.modeRef = v == null ? null : v.ref;
                    break;
                case "setZeroPowerBehavior": d.zeroPower = val; d.zeroPowerRef = v == null ? null : v.ref; break;
                default: break;
            }
        }
        // the SDK default when the team never sets it
        if (d.kind.equals("motor") && d.direction == null) d.directionRef = "(not set: SDK default FORWARD)";
    }

    public List<Object> json() {
        List<Object> out = new ArrayList<>();
        for (Device d : devices) out.add(d.json());
        return out;
    }

    /** The device whose field is `field` in class `owner` (Indexer.rightServo -> "rightIndexer"). */
    public Device byField(ClassInfo owner, String field) {
        for (Device d : devices) if (d.owner == owner && field.equals(d.field)) return d;
        return null;
    }
}
