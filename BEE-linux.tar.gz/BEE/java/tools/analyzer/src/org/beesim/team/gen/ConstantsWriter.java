package org.beesim.team.gen;

import org.beesim.team.Json;
import org.beesim.team.PedroApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * Pedro constants for a team that has Pedro as a dependency but NO constants class yet — written in the exact format
 * of the detected version, from BEE's Garage robot. Every builder call / config field is checked against the
 * version's verified API table; a missing one is an error, never a guess. The values are NOT tuned: the file says so.
 * (A team that already has a constants class never gets this file.)
 */
final class ConstantsWriter {
    final List<String> errors = new ArrayList<>();
    final List<String> notes = new ArrayList<>();
    private final PedroApi api;
    private final Map<String, Object> g;
    private final TreeSet<String> imports = new TreeSet<>();

    ConstantsWriter(PedroApi api, Map<String, Object> garage) {
        this.api = api;
        this.g = garage == null ? Map.of() : garage;
    }

    static final String FACTORY_2 = "createFollower", FACTORY_3 = "create";

    String write(String pkg) {
        return api.version.startsWith("3") ? v3(pkg) : v2(pkg);
    }

    // ---------------- garage values ----------------

    private Map<String, Object> odo() { return Json.map(g.get("odometry")); }

    private String motor(String role, String dflt) {
        for (Map.Entry<String, Object> e : Json.map(g.get("motors")).entrySet()) if (role.equals(e.getValue())) return e.getKey();
        notes.add("No " + role + " drive motor in the Garage: using the name \"" + dflt + "\".");
        return dflt;
    }

    private boolean reversed(String role) {
        return "reverse".equals(Json.map(Json.map(g.get("drive")).get("dirs")).get(role));
    }

    private double num(Object o, double d) { return Json.num(o, d); }

    private double simOr(String key, double dflt, String what) {
        Map<String, Object> p = Json.map(g.get("pedro"));
        for (String src : new String[]{"real", "sim"}) {
            Object v = Json.map(p.get(src)).get(key);
            if (v instanceof Number) {
                notes.add(what + " = " + Gen.num(((Number) v).doubleValue()) + " from BEE's " + (src.equals("real") ? "real-robot values" : "SIMULATED robot") + ".");
                return ((Number) v).doubleValue();
            }
        }
        notes.add(what + " = " + Gen.num(dflt) + ": a placeholder, measure it on the robot.");
        return dflt;
    }

    /** One verified builder call: .method(value), or an error when this version does not have it. */
    private String call(String cls, String method, String type, String value) {
        if (!api.has(cls, method, type)) {
            errors.add("Pedro " + api.version + " has no " + cls.substring(cls.lastIndexOf('.') + 1) + "." + method + "(" + type + ")");
            return "";
        }
        return "\n            ." + method + "(" + value + ")";
    }

    /** One verified config field (3.x): c.field.set(value); */
    private String set(String cls, String field, String value) {
        boolean ok = false;
        for (String m : api.members(cls)) if (!m.contains("(") && m.endsWith(" " + field)) ok = true;
        if (!ok) {
            errors.add("Pedro " + api.version + " has no " + cls.substring(cls.lastIndexOf('.') + 1) + "." + field);
            return "";
        }
        return "                c." + field + ".set(" + value + ");\n";
    }

    // ---------------- 2.x ----------------

    private String v2(String pkg) {
        String FC = "com.pedropathing.follower.FollowerConstants", MC = "com.pedropathing.ftc.drivetrains.MecanumConstants", FB = "com.pedropathing.ftc.FollowerBuilder";
        String DIR = "com.qualcomm.robotcore.hardware.DcMotorSimple$Direction";
        imports.add("com.pedropathing.follower.Follower");
        imports.add(FC);
        imports.add(MC);
        imports.add(FB);
        imports.add("com.pedropathing.paths.PathConstraints");
        imports.add("com.qualcomm.robotcore.hardware.DcMotorSimple");
        imports.add("com.qualcomm.robotcore.hardware.HardwareMap");
        double mass = num(g.get("mass_kg"), 10);
        double v = simOr("maxAchievableForwardVelocity", num(g.get("max_speed_in_s"), 50), "xVelocity");
        double vy = simOr("maxAchievableStrafeVelocity", v * num(g.get("strafe_eff"), 0.8), "yVelocity");
        double fd = simOr("naturalForwardDeceleration", 35, "forward deceleration");
        double ld = simOr("naturalStrafeDeceleration", 70, "lateral deceleration");
        StringBuilder sb = new StringBuilder();
        sb.append("    public static FollowerConstants followerConstants = new FollowerConstants()")
                .append(call(FC, "mass", "double", Gen.num(mass)))
                // Pedro 2.x stores the natural deceleration as a NEGATIVE acceleration
                .append(call(FC, "forwardZeroPowerAcceleration", "double", Gen.num(-Math.abs(fd))))
                .append(call(FC, "lateralZeroPowerAcceleration", "double", Gen.num(-Math.abs(ld)))).append(";\n\n");
        sb.append("    public static MecanumConstants driveConstants = new MecanumConstants()")
                .append(call(MC, "maxPower", "double", "1"))
                .append(call(MC, "leftFrontMotorName", "java.lang.String", Gen.q(motor("fl", "leftFront"))))
                .append(call(MC, "leftRearMotorName", "java.lang.String", Gen.q(motor("bl", "leftRear"))))
                .append(call(MC, "rightFrontMotorName", "java.lang.String", Gen.q(motor("fr", "rightFront"))))
                .append(call(MC, "rightRearMotorName", "java.lang.String", Gen.q(motor("br", "rightRear"))))
                .append(call(MC, "leftFrontMotorDirection", DIR, dir("fl")))
                .append(call(MC, "leftRearMotorDirection", DIR, dir("bl")))
                .append(call(MC, "rightFrontMotorDirection", DIR, dir("fr")))
                .append(call(MC, "rightRearMotorDirection", DIR, dir("br")))
                .append(call(MC, "xVelocity", "double", Gen.num(v)))
                .append(call(MC, "yVelocity", "double", Gen.num(vy))).append(";\n\n");
        String t = Json.str(odo().get("type"), "none");
        String loc;
        switch (t) {
            case "pinpoint": {
                String PC = "com.pedropathing.ftc.localization.constants.PinpointConstants";
                imports.add(PC);
                imports.add("com.qualcomm.hardware.gobilda.GoBildaPinpointDriver");
                imports.add("org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit");
                String E = "com.qualcomm.hardware.gobilda.GoBildaPinpointDriver$EncoderDirection";
                sb.append("    public static PinpointConstants localizerConstants = new PinpointConstants()")
                        .append(call(PC, "forwardPodY", "double", Gen.num(num(odo().get("par_y_in"), 0))))
                        .append(call(PC, "strafePodX", "double", Gen.num(num(odo().get("perp_x_in"), 0))))
                        .append(call(PC, "distanceUnit", "org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit", "DistanceUnit.INCH"))
                        .append(call(PC, "hardwareMapName", "java.lang.String", Gen.q(Json.str(odo().get("pinpoint_name"), "pinpoint"))))
                        .append(call(PC, "encoderResolution", "com.qualcomm.hardware.gobilda.GoBildaPinpointDriver$GoBildaOdometryPods",
                                "GoBildaPinpointDriver.GoBildaOdometryPods." + ("swingarm".equals(odo().get("pinpoint_pods")) ? "goBILDA_SWINGARM_POD" : "goBILDA_4_BAR_POD")))
                        .append(call(PC, "forwardEncoderDirection", E, "GoBildaPinpointDriver.EncoderDirection." + ("reversed".equals(odo().get("pin_x_dir")) ? "REVERSED" : "FORWARD")))
                        .append(call(PC, "strafeEncoderDirection", E, "GoBildaPinpointDriver.EncoderDirection." + ("reversed".equals(odo().get("pin_y_dir")) ? "REVERSED" : "FORWARD")))
                        .append(";\n\n");
                loc = call(FB, "pinpointLocalizer", PC, "localizerConstants");
                break;
            }
            case "dead3": {
                String TC = "com.pedropathing.ftc.localization.constants.ThreeWheelConstants";
                imports.add(TC);
                List<Object> names = Json.list(odo().get("names"));
                double tpi = inchesPerTick();
                double py = num(odo().get("par_y_in"), 6);
                sb.append("    public static ThreeWheelConstants localizerConstants = new ThreeWheelConstants()")
                        .append(call(TC, "forwardTicksToInches", "double", Gen.num(tpi)))
                        .append(call(TC, "strafeTicksToInches", "double", Gen.num(tpi)))
                        .append(call(TC, "turnTicksToInches", "double", Gen.num(tpi)))
                        .append(call(TC, "leftPodY", "double", Gen.num(py)))
                        .append(call(TC, "rightPodY", "double", Gen.num(-py)))
                        .append(call(TC, "strafePodX", "double", Gen.num(num(odo().get("perp_x_in"), -4))))
                        .append(call(TC, "leftEncoder_HardwareMapName", "java.lang.String", Gen.q(name(names, 0, "odo_left"))))
                        .append(call(TC, "rightEncoder_HardwareMapName", "java.lang.String", Gen.q(name(names, 1, "odo_right"))))
                        .append(call(TC, "strafeEncoder_HardwareMapName", "java.lang.String", Gen.q(name(names, 2, "odo_perp"))))
                        .append(";\n\n");
                loc = call(FB, "threeWheelLocalizer", TC, "localizerConstants");
                notes.add("Encoder directions are left at Pedro's defaults: run the localization test and flip them if a pod counts backwards.");
                break;
            }
            default:
                errors.add("BEE can write Pedro constants for a goBILDA Pinpoint or three dead wheels; your Garage robot uses \"" + t
                        + "\". Set Pedro's localizer up with the Pedro quickstart, then analyze again.");
                return null;
        }
        sb.append("    public static PathConstraints pathConstraints = new PathConstraints(0.99, 100, 1, 1);\n\n");
        if (!api.has("com.pedropathing.paths.PathConstraints", "<init>", "double", "double", "double", "double")) errors.add("Pedro " + api.version + " has no PathConstraints(double, double, double, double)");
        sb.append("    public static Follower " + FACTORY_2 + "(HardwareMap hardwareMap) {\n")
                .append("        return new FollowerBuilder(followerConstants, hardwareMap)")
                .append(call(FB, "pathConstraints", "com.pedropathing.paths.PathConstraints", "pathConstraints").replace("\n            ", "\n                "))
                .append(call(FB, "mecanumDrivetrain", MC, "driveConstants").replace("\n            ", "\n                "))
                .append(loc.replace("\n            ", "\n                "))
                .append("\n                .build();\n    }\n");
        if (!api.has(FB, "build")) errors.add("Pedro " + api.version + " has no FollowerBuilder.build()");
        return wrap(pkg, sb.toString());
    }

    private String dir(String role) { return "DcMotorSimple.Direction." + (reversed(role) ? "REVERSE" : "FORWARD"); }

    private static String name(List<Object> names, int i, String d) { return i < names.size() ? names.get(i).toString() : d; }

    private double inchesPerTick() {
        double ticks = num(odo().get("pod_ticks"), 2000), diamMm = num(odo().get("pod_diam_mm"), 32);
        return Math.PI * diamMm / 25.4 / ticks;
    }

    // ---------------- 3.x ----------------

    private String v3(String pkg) {
        String MCF = "com.pedropathing.revhub.drivetrains.MecanumConfig", FSC = "com.pedropathing.algorithm.ForesightConfig";
        for (String i : new String[]{"com.pedropathing.algorithm.Foresight", FSC, "com.pedropathing.follower.Follower", "com.pedropathing.localization.Localizer",
                "com.pedropathing.revhub.drivetrains.Mecanum", MCF, "com.qualcomm.robotcore.hardware.DcMotorSimple", "com.qualcomm.robotcore.hardware.HardwareMap"})
            imports.add(i);
        StringBuilder sb = new StringBuilder();
        sb.append("    public static MecanumConfig drivetrainConfig = new MecanumConfig(\n            c -> {\n")
                .append(set(MCF, "frontLeftName", Gen.q(motor("fl", "frontLeft"))))
                .append(set(MCF, "backLeftName", Gen.q(motor("bl", "backLeft"))))
                .append(set(MCF, "frontRightName", Gen.q(motor("fr", "frontRight"))))
                .append(set(MCF, "backRightName", Gen.q(motor("br", "backRight"))))
                .append(set(MCF, "frontLeftDirection", dir("fl")))
                .append(set(MCF, "backLeftDirection", dir("bl")))
                .append(set(MCF, "frontRightDirection", dir("fr")))
                .append(set(MCF, "backRightDirection", dir("br")))
                .append("            }\n    );\n\n");
        String t = Json.str(odo().get("type"), "none");
        String locClass;
        if (t.equals("pinpoint")) {
            String PC = "com.pedropathing.revhub.localizers.PinpointConfig";
            imports.add(PC);
            imports.add("com.pedropathing.revhub.localizers.PinpointLocalizer");
            imports.add("com.qualcomm.hardware.gobilda.GoBildaPinpointDriver");
            sb.append("    public static PinpointConfig localizerConfig = new PinpointConfig(\n            c -> {\n")
                    .append(set(PC, "name", Gen.q(Json.str(odo().get("pinpoint_name"), "pinpoint"))))
                    .append(set(PC, "xPodOffset", Gen.num(num(odo().get("par_y_in"), 0))))
                    .append(set(PC, "yPodOffset", Gen.num(num(odo().get("perp_x_in"), 0))))
                    .append(set(PC, "xPodDirection", "GoBildaPinpointDriver.EncoderDirection." + ("reversed".equals(odo().get("pin_x_dir")) ? "REVERSED" : "FORWARD")))
                    .append(set(PC, "yPodDirection", "GoBildaPinpointDriver.EncoderDirection." + ("reversed".equals(odo().get("pin_y_dir")) ? "REVERSED" : "FORWARD")))
                    .append(set(PC, "podType", "GoBildaPinpointDriver.GoBildaOdometryPods." + ("swingarm".equals(odo().get("pinpoint_pods")) ? "goBILDA_SWINGARM_POD" : "goBILDA_4_BAR_POD")))
                    .append("            }\n    );\n\n");
            locClass = "PinpointLocalizer";
        } else if (t.equals("dead3") || t.equals("dead2")) {
            // the same localizer config BEE writes for its own Pedro 3 code (pedro/Constants.java), on the team's names
            List<Object> names = Json.list(odo().get("names"));
            String ipt = Gen.num(inchesPerTick()), py = Gen.num(num(odo().get("par_y_in"), 6)), px = Gen.num(num(odo().get("perp_x_in"), -4));
            if (t.equals("dead3")) {
                String TC = "com.pedropathing.revhub.localizers.ThreeWheelConfig";
                imports.add(TC);
                imports.add("com.pedropathing.revhub.localizers.ThreeWheelLocalizer");
                sb.append("    public static ThreeWheelConfig localizerConfig = new ThreeWheelConfig(\n            c -> {\n")
                        .append(set(TC, "leftEncoderName", Gen.q(name(names, 0, "odo_left"))))
                        .append(set(TC, "rightEncoderName", Gen.q(name(names, 1, "odo_right"))))
                        .append(set(TC, "strafeEncoderName", Gen.q(name(names, 2, "odo_perp"))))
                        .append(set(TC, "leftPodY", py))
                        .append(set(TC, "rightPodY", Gen.num(-num(odo().get("par_y_in"), 6))))
                        .append(set(TC, "strafePodX", px))
                        .append(set(TC, "forwardTicksToInches", ipt))
                        .append(set(TC, "strafeTicksToInches", ipt))
                        // heading = turnTicksToRadians * (right - left) / (leftPodY - rightPodY): inches per tick here too
                        .append(set(TC, "turnTicksToRadians", ipt))
                        .append(set(TC, "leftEncoderDirection", "1.0"))
                        .append(set(TC, "rightEncoderDirection", "1.0"))
                        .append(set(TC, "strafeEncoderDirection", "1.0"))
                        .append("            }\n    );\n\n");
                locClass = "ThreeWheelLocalizer";
            } else {
                String TC = "com.pedropathing.revhub.localizers.TwoWheelConfig";
                imports.add(TC);
                imports.add("com.pedropathing.revhub.localizers.TwoWheelLocalizer");
                imports.add("com.pedropathing.revhub.localizers.RevHubIMU");
                imports.add("com.qualcomm.hardware.rev.RevHubOrientationOnRobot");
                sb.append("    public static TwoWheelConfig localizerConfig = new TwoWheelConfig(\n            c -> {\n")
                        .append(set(TC, "xPodName", Gen.q(name(names, 0, "odo_left"))))
                        .append(set(TC, "yPodName", Gen.q(name(names, 2, "odo_perp"))))
                        .append(set(TC, "imuName", Gen.q(Json.str(g.get("imu_name"), "imu"))))
                        .append(set(TC, "imu", "new RevHubIMU(new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.UP, RevHubOrientationOnRobot.UsbFacingDirection.FORWARD))"))
                        .append(set(TC, "xPodOffset", Gen.num(-num(odo().get("par_y_in"), 6))))
                        .append(set(TC, "yPodOffset", px))
                        .append(set(TC, "forwardTicksToInches", ipt))
                        .append(set(TC, "strafeTicksToInches", ipt))
                        .append(set(TC, "xPodDirection", "1.0"))
                        .append(set(TC, "yPodDirection", "1.0"))
                        .append("            }\n    );\n\n");
                locClass = "TwoWheelLocalizer";
                notes.add("The IMU is set as a REV hub with the logo UP and the USB ports FORWARD: change RevHubOrientationOnRobot if yours is mounted otherwise.");
            }
            notes.add("Encoder directions are 1.0: run the localization test and set -1.0 for a pod that counts backwards.");
        } else {
            errors.add("BEE writes Pedro 3 constants for a goBILDA Pinpoint or 2 / 3 dead wheels; your Garage robot uses \"" + t + "\". Set the localizer up with the Pedro quickstart.");
            return null;
        }
        // Foresight: the speeds / decelerations BEE measured; the controllers stay at Pedro's documented example values
        imports.add("com.pedropathing.controllers.Controller");
        sb.append("    public static ForesightConfig foresightConfig = new ForesightConfig(\n            c -> {\n")
                .append(set(FSC, "maxAchievableForwardVelocity", Gen.num(simOr("maxAchievableForwardVelocity", num(g.get("max_speed_in_s"), 50), "max forward velocity"))))
                .append(set(FSC, "maxAchievableStrafeVelocity", Gen.num(simOr("maxAchievableStrafeVelocity", num(g.get("max_speed_in_s"), 50) * 0.8, "max strafe velocity"))))
                .append(set(FSC, "naturalForwardDeceleration", Gen.num(Math.abs(simOr("naturalForwardDeceleration", 85, "natural forward deceleration")))))
                .append(set(FSC, "naturalStrafeDeceleration", Gen.num(Math.abs(simOr("naturalStrafeDeceleration", 104, "natural strafe deceleration")))))
                .append(set(FSC, "headingFeedback", "Controller.proportional(" + Gen.num(simOr("heading kP", 5.26, "heading kP")) + ")"))
                .append("            }\n    );\n\n");
        if (!api.has("com.pedropathing.controllers.Controller", "proportional", "double")) errors.add("Pedro " + api.version + " has no Controller.proportional(double)");
        sb.append("    public static Localizer localizer(HardwareMap h) {\n        return new " + locClass + "(h, localizerConfig);\n    }\n\n");
        sb.append("    public static Follower " + FACTORY_3 + "(HardwareMap h) {\n        return new Follower(localizer(h), new Mecanum(h, drivetrainConfig), new Foresight(foresightConfig));\n    }\n");
        return wrap(pkg, sb.toString());
    }

    private String wrap(String pkg, String body) {
        StringBuilder sb = new StringBuilder("package " + pkg + ";\n\n");
        for (String i : imports) sb.append("import ").append(i.replace('$', '.')).append(";\n");
        sb.append("\n/**\n * Pedro Pathing ").append(api.version).append(" constants written by BEE because your project had none.\n");
        sb.append(" * NOT TUNED: run Pedro's tuners on the robot and replace these values (BEE's tuning screen can read them back).\n");
        for (String n : notes) sb.append(" *   - ").append(n).append('\n');
        sb.append(" */\npublic class Constants {\n").append(body).append("}\n");
        return sb.toString();
    }
}
