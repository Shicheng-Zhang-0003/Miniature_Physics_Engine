package org.beesim.team;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Reads a team project (folder or ZIP of the FTC SDK repo): sources (.java / .kt) and build files.
 * Paths are kept relative to the project root, with "/" separators, so provenance is stable.
 * FTC SDK samples (FtcRobotController) and build outputs are skipped: they are not the team's robot.
 */
public final class ProjectReader {
    public final Map<String, String> java = new TreeMap<>();
    public final Map<String, String> kotlin = new TreeMap<>();
    public final Map<String, String> gradle = new TreeMap<>();   // *.gradle, *.gradle.kts, libs.versions.toml, gradle.properties
    public int skipped = 0;
    public String root;

    public static ProjectReader read(Path p) throws IOException {
        ProjectReader r = new ProjectReader();
        if (Files.isDirectory(p)) {
            // only the TeamCode folder was chosen: the build files (versions!) are in the project root above it
            Path q = p.toAbsolutePath();
            for (int i = 0; i < 4 && q != null && !Files.exists(q.resolve("settings.gradle")) && !Files.exists(q.resolve("settings.gradle.kts")); i++) q = q.getParent();
            if (q != null && (Files.exists(q.resolve("settings.gradle")) || Files.exists(q.resolve("settings.gradle.kts")))) p = q;
            r.root = p.toString();
            try (Stream<Path> s = Files.walk(p)) {
                for (Path f : (Iterable<Path>) s.filter(Files::isRegularFile)::iterator) {
                    String rel = p.relativize(f).toString().replace('\\', '/');
                    if (r.wanted(rel)) r.add(rel, Files.readString(f, StandardCharsets.UTF_8));
                }
            }
        } else {
            try (ZipFile z = new ZipFile(p.toFile())) {
                // a ZIP usually has one top folder (code-decode-main/...): strip it so paths match the folder case
                String prefix = commonPrefix(z);
                for (ZipEntry e : Collections.list(z.entries())) {
                    if (e.isDirectory()) continue;
                    String rel = e.getName().replace('\\', '/');
                    if (rel.startsWith(prefix)) rel = rel.substring(prefix.length());
                    if (!r.wanted(rel)) continue;
                    try (InputStream in = z.getInputStream(e)) {
                        r.add(rel, new String(in.readAllBytes(), StandardCharsets.UTF_8));
                    }
                }
            }
        }
        return r;
    }

    private static String commonPrefix(ZipFile z) {
        String first = null;
        for (ZipEntry e : Collections.list(z.entries())) {
            String n = e.getName();
            if (n.startsWith("__MACOSX")) continue;
            int i = n.indexOf('/');
            String top = i < 0 ? "" : n.substring(0, i + 1);
            if (first == null) first = top;
            else if (!first.equals(top)) return "";
        }
        return first == null ? "" : first;
    }

    private boolean wanted(String rel) {
        String low = rel.toLowerCase();
        if (low.contains("__macosx/") || low.contains("/build/") || low.startsWith("build/") || low.contains("/.gradle/") || low.contains("/.idea/")) return false;
        boolean src = low.endsWith(".java") || low.endsWith(".kt");
        boolean build = low.endsWith(".gradle") || low.endsWith(".gradle.kts") || low.endsWith("libs.versions.toml") || low.endsWith("gradle.properties");
        if (!src && !build) return false;
        // the SDK's sample OpModes and the Robot Controller app are not the team's code
        if (src && (low.contains("org/firstinspires/ftc/robotcontroller/") || low.contains("/external/samples/"))) {
            skipped++;
            return false;
        }
        return true;
    }

    private void add(String rel, String text) {
        String low = rel.toLowerCase();
        if (low.endsWith(".java")) java.put(rel, text);
        else if (low.endsWith(".kt")) kotlin.put(rel, text);
        else gradle.put(rel, text);
    }
}
