package org.beesim.team;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A value the analysis could compute from the team's code (a constant, a Pose, an enum constant...), plus how the
 * generated code can REFER to it (ref + import), so the export uses Config.Indexer.OPEN_POSITION, not a copied 0.
 */
public final class Val {
    public enum K { NUM, STR, BOOL, POSE, ENUM, OBJ }

    public K kind;
    public double num;
    public String str;
    public boolean bool;
    public double x, y, h;          // POSE (h exactly as the team's code computes it)
    public boolean poseHasHeading;
    public String type;             // OBJ / ENUM: the type name as written (DcMotorSimple.Direction)
    public final List<Val> args = new ArrayList<>();
    public String ref;              // Java expression for this value (Config.Indexer.OPEN_POSITION), or null
    public String imp;              // fully qualified class to import for ref, or null
    public String file;             // where the value is defined
    public int line;
    public boolean usesToRadians;   // a heading written as Math.toRadians(..)
    public String privateRef;       // the constant's name when it is private (the export uses the value instead)

    static Val num(double d) { Val v = new Val(); v.kind = K.NUM; v.num = d; return v; }

    static Val str(String s) { Val v = new Val(); v.kind = K.STR; v.str = s; return v; }

    static Val bool(boolean b) { Val v = new Val(); v.kind = K.BOOL; v.bool = b; return v; }

    static Val enumConst(String type, String name) {
        Val v = new Val();
        v.kind = K.ENUM;
        v.type = type;
        v.str = name;
        return v;
    }

    Val withRef(String ref, String imp, String file, int line) {
        Val v = copy();
        v.ref = ref;
        v.imp = imp;
        v.file = file;
        v.line = line;
        return v;
    }

    Val copy() {
        Val v = new Val();
        v.kind = kind; v.num = num; v.str = str; v.bool = bool; v.x = x; v.y = y; v.h = h; v.poseHasHeading = poseHasHeading;
        v.type = type; v.args.addAll(args); v.ref = ref; v.imp = imp; v.file = file; v.line = line; v.usesToRadians = usesToRadians; v.privateRef = privateRef;
        return v;
    }

    public boolean isNum() { return kind == K.NUM; }

    /** JSON form for the model. */
    public Object json() {
        Map<String, Object> m;
        switch (kind) {
            case NUM: m = Json.obj("kind", "number", "value", num); break;
            case STR: m = Json.obj("kind", "string", "value", str); break;
            case BOOL: m = Json.obj("kind", "boolean", "value", bool); break;
            case ENUM: m = Json.obj("kind", "enum", "type", type, "value", str); break;
            case POSE: m = Json.obj("kind", "pose", "x", x, "y", y, "heading", h, "heading_given", poseHasHeading, "uses_toRadians", usesToRadians); break;
            default: m = Json.obj("kind", "object", "type", type); break;
        }
        if (ref != null) m.put("ref", ref);
        if (privateRef != null) m.put("private_ref", privateRef);
        if (imp != null) m.put("import", imp);
        if (file != null) { m.put("file", file); m.put("line", line); }
        return m;
    }

    @Override public String toString() {
        switch (kind) {
            case NUM: return Double.toString(num);
            case STR: return '"' + str + '"';
            case BOOL: return Boolean.toString(bool);
            case ENUM: return type + "." + str;
            case POSE: return "Pose(" + x + ", " + y + ", " + h + ")";
            default: return "new " + type + "(...)";
        }
    }
}
