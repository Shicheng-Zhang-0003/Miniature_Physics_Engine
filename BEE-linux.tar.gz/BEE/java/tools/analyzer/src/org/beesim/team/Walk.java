package org.beesim.team;

import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.TreePath;
import com.sun.source.util.TreePathScanner;
import org.beesim.team.JavaIndex.ClassInfo;
import org.beesim.team.JavaIndex.FieldInfo;
import org.beesim.team.JavaIndex.MethodInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/** Tree walking helpers: every call / new in a method (with its path, for parent lookups). */
public final class Walk {
    private Walk() {}

    /** A node found inside a method (or a field initializer when method == null). */
    public static final class Hit {
        public final ClassInfo cls;
        public final MethodInfo method;
        public final FieldInfo field;
        public final TreePath path;

        Hit(ClassInfo cls, MethodInfo method, FieldInfo field, TreePath path) {
            this.cls = cls;
            this.method = method;
            this.field = field;
            this.path = path;
        }

        public Tree leaf() { return path.getLeaf(); }

        public Tree parent() { return path.getParentPath() == null ? null : path.getParentPath().getLeaf(); }

        public int line(JavaIndex ix) { return ix.line(cls.src, leaf()); }

        /** Skips parentheses and casts. */
        public TreePath up() {
            TreePath p = path.getParentPath();
            while (p != null && (p.getLeaf().getKind() == Tree.Kind.PARENTHESIZED || p.getLeaf().getKind() == Tree.Kind.TYPE_CAST)) p = p.getParentPath();
            return p;
        }
    }

    /** All nodes matching `want` in every method body and field initializer of `c` (not of nested classes). */
    public static List<Hit> find(ClassInfo c, Predicate<Tree> want) {
        List<Hit> out = new ArrayList<>();
        for (MethodInfo m : c.methods) {
            if (m.body == null) continue;
            TreePath root = new TreePath(new TreePath(c.src.cu), m.tree);
            scan(root, m.tree.getBody(), want, out, c, m, null);
        }
        for (FieldInfo f : c.fields.values()) {
            if (f.init == null) continue;
            TreePath root = new TreePath(new TreePath(c.src.cu), f.tree);
            scan(root, f.init, want, out, c, null, f);
        }
        return out;
    }

    /** Matches inside one method body. */
    public static List<Hit> find(ClassInfo c, MethodInfo m, Predicate<Tree> want) {
        List<Hit> out = new ArrayList<>();
        if (m.body == null) return out;
        scan(new TreePath(new TreePath(c.src.cu), m.tree), m.tree.getBody(), want, out, c, m, null);
        return out;
    }

    /** Matches inside an arbitrary subtree (`subtree` = the subtree's own path; the subtree itself is tested too). */
    public static List<Hit> find(ClassInfo c, MethodInfo m, TreePath subtree, Predicate<Tree> want) {
        List<Hit> out = new ArrayList<>();
        walk(subtree, want, out, c, m, null);
        return out;
    }

    private static void scan(TreePath root, Tree body, Predicate<Tree> want, List<Hit> out, ClassInfo c, MethodInfo m, FieldInfo f) {
        walk(new TreePath(root, body), want, out, c, m, f);
    }

    private static void walk(TreePath rootPath, Predicate<Tree> want, List<Hit> out, ClassInfo c, MethodInfo m, FieldInfo f) {
        if (want.test(rootPath.getLeaf())) out.add(new Hit(c, m, f, rootPath));
        new TreePathScanner<Void, Void>() {
            @Override public Void scan(Tree t, Void v) {
                if (t == null) return null;
                // local classes are not part of this method; anonymous classes (new Action() { ... }) are
                if (t.getKind() == Tree.Kind.CLASS && !(getCurrentPath().getLeaf() instanceof NewClassTree)) return null;
                TreePath here = new TreePath(getCurrentPath(), t);
                if (want.test(t)) out.add(new Hit(c, m, f, here));
                return super.scan(t, v);
            }
        }.scan(rootPath, null);
    }

    /** "x.setPosition" -> receiver "x" (dotted), or null. "this.x" is returned as "x". */
    public static String receiver(MethodInvocationTree mit) {
        ExpressionTree sel = mit.getMethodSelect();
        if (!(sel instanceof com.sun.source.tree.MemberSelectTree)) return null;
        String d = JavaIndex.dotted(((com.sun.source.tree.MemberSelectTree) sel).getExpression());
        if (d == null) return null;
        return d.startsWith("this.") ? d.substring(5) : d;
    }

    public static String methodName(MethodInvocationTree mit) {
        ExpressionTree sel = mit.getMethodSelect();
        if (sel instanceof com.sun.source.tree.MemberSelectTree) return ((com.sun.source.tree.MemberSelectTree) sel).getIdentifier().toString();
        if (sel instanceof com.sun.source.tree.IdentifierTree) return ((com.sun.source.tree.IdentifierTree) sel).getName().toString();
        return "";
    }

    public static boolean isCall(Tree t, String... names) {
        if (!(t instanceof MethodInvocationTree)) return false;
        String n = methodName((MethodInvocationTree) t);
        for (String x : names) if (x.equals(n)) return true;
        return names.length == 0;
    }

    /** The declared name of a local variable / field tree. */
    public static String varName(Tree t) {
        return t instanceof VariableTree ? ((VariableTree) t).getName().toString() : null;
    }
}
