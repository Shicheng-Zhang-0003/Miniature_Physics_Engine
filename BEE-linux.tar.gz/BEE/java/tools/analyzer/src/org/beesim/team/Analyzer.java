package org.beesim.team;

import org.beesim.team.Hardware.Device;
import org.beesim.team.JavaIndex.ClassInfo;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * project -> robot model (JSON): every fact with file + line + confidence, the Pedro support status for the exact
 * version, conflicts with BEE's Garage settings (the code wins), questions the user must answer before export,
 * warnings, and bugs found in the team's code (reported, never copied).
 */
public final class Analyzer {
    public static final int MODEL_VERSION = 1;

    public static Map<String, Object> analyze(Path project, Map<String, Object> garage) throws Exception {
        ProjectReader pr = ProjectReader.read(project);
        return analyze(pr, garage, pr.root != null ? pr.root : project.toString());
    }

    public static Map<String, Object> analyze(ProjectReader pr, Map<String, Object> garage, String root) throws Exception {
        List<Map<String, Object>> conflicts = new ArrayList<>();
        List<Map<String, Object>> warnings = new ArrayList<>();
        List<Map<String, Object>> questions = new ArrayList<>();

        GradleScanner gs = GradleScanner.scan(pr.gradle);
        warnings.addAll(gs.warnings);
        Map<String, Object> libs = gs.libraries(conflicts);

        JavaIndex ix = JavaIndex.build(pr.java);
        for (String e : ix.parseErrors) warnings.add(Json.obj("kind", "parse_error", "message", "Could not fully read " + e));
        Eval ev = new Eval(ix);
        Hardware hw = new Hardware(ix, ev);
        hw.run();
        warnings.addAll(hw.warnings);
        PedroSetup ps = new PedroSetup(ix, ev);
        ps.run();
        warnings.addAll(ps.warnings);
        Subsystems subs = new Subsystems(ix, ev, hw);
        subs.run();
        warnings.addAll(subs.warnings);
        OpModes om = new OpModes(ix, ev, subs, ps);
        om.run();
        warnings.addAll(om.warnings);
        KotlinScanner ks = KotlinScanner.scan(pr.kotlin);

        Map<String, Object> model = new LinkedHashMap<>();
        model.put("bee_model_version", MODEL_VERSION);
        model.put("project", Json.obj("root", root, "java_files", pr.java.size(), "kotlin_files", pr.kotlin.size(), "build_files", new ArrayList<>(pr.gradle.keySet()),
                "skipped_sdk_files", pr.skipped));
        model.put("libraries", libs);
        model.put("repositories", gs.repositories);
        model.put("dependencies", gs.deps);
        model.put("pedro", pedroStatus(libs, gs, ps, ix, warnings));
        model.put("hardware", hw.json());
        model.put("bulk_caching", hw.bulkCaching);
        model.put("robot_wrapper", subs.wrapperJson());
        model.put("subsystems", subs.json());
        model.put("opmodes", om.opmodes);
        model.put("start_poses", new ArrayList<>(om.startPoses.values()));
        model.put("shooting_poses", om.shootingPoses);
        model.put("coordinates", om.coordinates);
        model.put("loop", om.loop);
        model.put("scoring", om.scoring);
        model.put("intake", om.intake);
        model.put("paradigm", om.paradigm);
        model.put("team_actions", om.teamActions);
        model.put("runner", om.runner);
        model.put("kotlin", ks.json());
        model.put("team_bugs", om.teamBugs);
        // the Garage robot (only used to write Pedro constants for a team that has none)
        model.put("garage", garage == null ? null : Json.obj("alliance", garage.get("alliance"), "width_in", garage.get("width_in"), "length_in", garage.get("length_in"), "motors", garage.get("motors"), "drive", garage.get("drive"), "odometry", garage.get("odometry"),
                "mass_kg", garage.get("mass_kg"), "max_speed_in_s", garage.get("max_speed_in_s"), "strafe_eff", garage.get("strafe_eff"), "pedro", garage.get("pedro")));

        Map<String, Object> limits = new LinkedHashMap<>();
        if (om.scoring != null && om.scoring.get("capacity") != null) limits.put("capacity", om.scoring.get("capacity"));
        // an explicit constant wins: MAX_ARTIFACTS = 3, CAPACITY = 3
        for (Subsystems.Sub s : subs.subs.values())
            for (Map<String, Object> c : s.constants) {
                @SuppressWarnings("unchecked") List<String> tags = (List<String>) c.get("tags");
                if (tags.contains("count") && (tags.contains("max") || ((String) c.get("ref")).toUpperCase(Locale.ROOT).contains("CAPACITY")))
                    limits.put("capacity", Fact.of((int) Math.round((double) c.get("value")), (String) c.get("file"), (int) c.get("line"), Fact.HIGH, (String) c.get("ref")));
            }
        model.put("game_limits", limits);

        garageConflicts(model, garage, hw, ps, subs, conflicts);
        questions(model, om, ps, hw, ks, questions);
        model.put("conflicts", conflicts);
        model.put("warnings", warnings);
        model.put("questions", questions);
        return model;
    }

    // ---------------- Pedro: exact version -> verified API table ----------------

    @SuppressWarnings("unchecked")
    static Map<String, Object> pedroStatus(Map<String, Object> libs, GradleScanner gs, PedroSetup ps, JavaIndex ix, List<Map<String, Object>> warnings) {
        Map<String, Object> dep = (Map<String, Object>) libs.get("pedro_ftc");
        if (dep == null) dep = (Map<String, Object>) libs.get("pedro_revhub");
        if (dep == null) dep = (Map<String, Object>) libs.get("pedro_core");
        Map<String, Object> out = new LinkedHashMap<>();
        List<String> verified = PedroApi.verified();
        out.put("verified_versions", verified);
        out.put("constants", ps.json);
        if (dep == null) {
            boolean copied = false;
            for (ClassInfo c : ix.classes()) if (c.pkg.startsWith("com.pedropathing")) copied = true;
            out.put("status", copied ? "unsupported" : "absent");
            out.put("message", copied ? "Pedro Pathing's source code is copied into the project (old Pedro 1.x setup). BEE only exports for the published Pedro 2.x / 3.x libraries."
                    : "This project does not use Pedro Pathing.");
            out.put("gradle_to_add", gradleLines());
            return out;
        }
        String v = (String) dep.get("version");
        out.put("dependency", dep);
        out.put("version", v);
        if (v == null || v.isEmpty()) {
            out.put("status", "unsupported");
            out.put("message", "The Pedro Pathing version could not be read from " + dep.get("file") + ":" + dep.get("line") + " (" + dep.get("evidence") + "). Write it as a plain version (e.g. 2.0.4).");
            return out;
        }
        out.put("family", String.valueOf(Version.major(v)));
        if (verified.contains(v)) {
            out.put("status", "supported");
            out.put("api_version", v);
            out.put("message", "Pedro Pathing " + v + ": API verified against the published artifacts.");
        } else {
            String near = null;
            for (String x : verified) if (Version.majorMinor(x).equals(Version.majorMinor(v)) && (near == null || Math.abs(Version.parts(x)[2] - Version.parts(v)[2]) <= Math.abs(Version.parts(near)[2] - Version.parts(v)[2]))) near = x;
            if (near != null) {
                out.put("status", "needs_confirmation");
                out.put("api_version", near);
                out.put("message", "Pedro Pathing " + v + " was not verified by BEE. The closest verified release is " + near + " (same " + Version.majorMinor(v) + ".x line). "
                        + "Export only if you accept that BEE uses the " + near + " API; it then checks every call against that table.");
            } else {
                out.put("status", "unsupported");
                out.put("message", "Pedro Pathing " + v + " is not a version BEE knows (verified: " + String.join(", ", verified) + "). Export is disabled so BEE does not write code that may not compile.");
            }
        }
        // Pedro 2.x is on Maven Central (2.0.2+) or Pedro's own repo (2.0.0 / 2.0.1): is that repository declared?
        boolean central = false, pedroRepo = false;
        for (Map<String, Object> r : gs.repositories) {
            String u = String.valueOf(r.get("url"));
            central |= u.contains("repo1.maven.org") || u.contains("mavenCentral");
            pedroRepo |= u.contains("maven.pedropathing.com");
        }
        boolean needsPedroRepo = Version.compare(v, "2.0.2") < 0;
        if (needsPedroRepo ? !pedroRepo : !central)
            warnings.add(Json.obj("kind", "repository", "message", "Pedro Pathing " + v + " is published on " + (needsPedroRepo ? "https://maven.pedropathing.com" : "Maven Central (mavenCentral())")
                    + ", which is not in the repositories this project declares."));
        out.put("tuning", tuning(String.valueOf(out.getOrDefault("api_version", "")), ps));
        if (ps.json == null) {
            out.put("constants_status", "missing");
            warnings.add(Json.obj("kind", "pedro_constants_missing", "message", "Pedro Pathing is a dependency, but no class creates a Follower. BEE will generate the constants in the " + v + " format; tune them on the robot."));
        } else {
            out.put("constants_status", "found");
        }
        return out;
    }

    /**
     * The tuning parameters that exist in this exact Pedro version (from the verified API), each with the team's
     * current value from its constants — for BEE's version-aware tuning screen.
     */
    static Map<String, Object> tuning(String apiVersion, PedroSetup ps) {
        org.beesim.team.gen.PedroAdapter ad = apiVersion.isEmpty() ? null : org.beesim.team.gen.PedroAdapter.forVersion(apiVersion);
        if (ad == null) return null;
        List<Object> fields = new ArrayList<>();
        for (Map<String, Object> f : ad.tuningSchema()) {
            Map<String, Object> x = new LinkedHashMap<>(f);
            String key = (String) f.get("key");
            Val v;
            if (key.contains("#")) {
                Val ctor = ps.values.get(key.substring(0, key.indexOf('#')));
                int i = Integer.parseInt(key.substring(key.indexOf('#') + 1));
                v = ctor != null && ctor.kind == Val.K.OBJ && i < ctor.args.size() ? ctor.args.get(i) : null;
            } else {
                v = ps.values.get(key);
            }
            if (v != null && v.isNum()) x.put("team_value", v.num);
            else if (v != null && v.kind == Val.K.OBJ) {
                List<Object> a = new ArrayList<>();
                for (Val y : v.args) a.add(y != null && y.isNum() ? (Object) y.num : null);
                x.put("team_value", a);
            }
            if (v != null && v.file != null) { x.put("file", v.file); x.put("line", v.line); }
            fields.add(x);
        }
        return Json.obj("adapter", ad.label(), "version", apiVersion, "family", String.valueOf(Version.major(apiVersion)), "fields", fields);
    }

    static List<Object> gradleLines() {
        List<Object> out = new ArrayList<>();
        out.add(Json.obj("version", "2.1.2", "repositories", List.of("mavenCentral()"),
                "dependencies", List.of("implementation 'com.pedropathing:ftc:2.1.2'"), "verified", PedroApi.verified().contains("2.1.2")));
        out.add(Json.obj("version", "3.0.1", "repositories", List.of("mavenCentral()"),
                "dependencies", List.of("implementation 'com.pedropathing:core:3.0.1'", "implementation 'com.pedropathing:revhub:3.0.1'"), "verified", PedroApi.verified().contains("3.0.1")));
        return out;
    }

    // ---------------- code vs Garage: the code wins ----------------

    @SuppressWarnings("unchecked")
    static void garageConflicts(Map<String, Object> model, Map<String, Object> g, Hardware hw, PedroSetup ps, Subsystems subs, List<Map<String, Object>> out) {
        if (g == null || g.isEmpty()) return;
        // drive motors: names and directions
        Map<String, Object> motors = Json.map(g.get("motors"));
        Map<String, Object> dirs = Json.map(Json.map(g.get("drive")).get("dirs"));
        String[][] wheels = {{"fl", "leftFront"}, {"bl", "leftRear"}, {"fr", "rightFront"}, {"br", "rightRear"}};
        for (String[] w : wheels) {
            Val name = ps.values.get("MecanumConstants." + w[1] + "MotorName");
            Val dir = ps.values.get("MecanumConstants." + w[1] + "MotorDirection");
            if (name == null) {
                String w3 = Map.of("fl", "frontLeft", "bl", "backLeft", "fr", "frontRight", "br", "backRight").get(w[0]);
                name = ps.values.get("MecanumConfig." + w3 + "Name");
                dir = ps.values.get("MecanumConfig." + w3 + "Direction");
            }
            String gName = null;
            for (Map.Entry<String, Object> e : motors.entrySet()) if (w[0].equals(e.getValue())) gName = e.getKey();
            if (name != null && name.kind == Val.K.STR && gName != null && !gName.equals(name.str))
                out.add(conflict("drive_motor_name", w[0] + " drive motor", gName, name.str, name.file, name.line, name.ref));
            String gDir = (String) dirs.get(w[0]);
            if (dir != null && dir.kind == Val.K.ENUM && gDir != null && !gDir.equalsIgnoreCase(dir.str))
                out.add(conflict("drive_motor_direction", w[0] + " drive motor direction", gDir, dir.str.toLowerCase(Locale.ROOT), dir.file != null ? dir.file : (String) Json.map(Json.map(model.get("pedro")).get("constants")).get("file"), dir.line, dir.ref));
        }
        num(out, "mass", "Robot mass (kg)", g.get("mass_kg"), ps.values.get("FollowerConstants.mass"), 0.05);
        num(out, "max_velocity", "Max forward velocity (in/s)", g.get("max_speed_in_s"), ps.values.get("MecanumConstants.xVelocity"), 0.5);
        Map<String, Object> odo = Json.map(g.get("odometry"));
        num(out, "pinpoint_forward_pod_y", "Pinpoint forward pod Y offset (in)", odo.get("par_y_in"), ps.values.get("PinpointConstants.forwardPodY"), 0.01);
        num(out, "pinpoint_strafe_pod_x", "Pinpoint strafe pod X offset (in)", odo.get("perp_x_in"), ps.values.get("PinpointConstants.strafePodX"), 0.01);
        Val pinName = ps.values.get("PinpointConstants.hardwareMapName");
        if (pinName != null && pinName.kind == Val.K.STR && odo.get("pinpoint_name") != null && !pinName.str.equals(odo.get("pinpoint_name")))
            out.add(conflict("pinpoint_name", "Pinpoint name", odo.get("pinpoint_name"), pinName.str, pinName.file, pinName.line, pinName.ref));
        // feeder / gate positions: the Garage's push / rest vs the team's open / closed constants
        Map<String, Object> mc = Json.map(g.get("mech_cfg"));
        for (Subsystems.Sub s : subs.subs.values()) {
            for (Map<String, Object> sv : s.servoStates) {
                Map<String, Object> open = (Map<String, Object>) sv.get("open"), closed = (Map<String, Object>) sv.get("closed");
                if (open != null && mc.get("feeder_push") != null && Json.num(mc.get("feeder_push"), -1) != Json.num(open.get("value"), -2))
                    out.add(conflict("gate_open_position", "Gate \"" + sv.get("device") + "\" open position", "feeder_push = " + mc.get("feeder_push"), open.get("ref") + " = " + open.get("value"),
                            (String) open.get("file"), (int) open.get("line"), (String) open.get("ref")));
                if (closed != null && mc.get("feeder_rest") != null && Json.num(mc.get("feeder_rest"), -1) != Json.num(closed.get("value"), -2))
                    out.add(conflict("gate_closed_position", "Gate \"" + sv.get("device") + "\" closed position", "feeder_rest = " + mc.get("feeder_rest"), closed.get("ref") + " = " + closed.get("value"),
                            (String) closed.get("file"), (int) closed.get("line"), (String) closed.get("ref")));
            }
        }
        // devices the code has but the Garage does not know (and the reverse)
        Map<String, Object> mech = Json.map(g.get("mechanisms"));
        java.util.Set<String> known = new java.util.HashSet<>(motors.keySet());
        known.addAll(mech.keySet());
        for (Object d : Json.list(g.get("devices"))) known.add(String.valueOf(Json.map(d).get("name")));
        for (Object s : Json.list(g.get("sensors"))) known.add(String.valueOf(Json.map(s).get("name")));
        known.add(String.valueOf(odo.get("pinpoint_name")));
        known.add(String.valueOf(Json.map(g.get("camera")).get("name")));
        known.add(String.valueOf(g.get("imu_name")));
        for (Device d : hw.devices) {
            if (d.name == null || known.contains(d.name) || "hub".equals(d.kind)) continue;
            out.add(Json.obj("kind", "device_missing_in_garage", "what", "Device \"" + d.name + "\"", "garage", null, "code", d.javaType + " \"" + d.name + "\"",
                    "message", "The code uses " + d.javaType + " \"" + d.name + "\" (" + d.file + ":" + d.line + "), which the Garage robot does not have. The export uses the code.",
                    "file", d.file, "line", d.line, "resolution", "code"));
        }
    }

    private static void num(List<Map<String, Object>> out, String kind, String what, Object garage, Val code, double tol) {
        if (garage == null || code == null || !code.isNum()) return;
        double g = Json.num(garage, Double.NaN);
        if (Double.isNaN(g) || Math.abs(g - code.num) <= tol) return;
        out.add(conflict(kind, what, g, code.num, code.file, code.line, code.ref));
    }

    private static Map<String, Object> conflict(String kind, String what, Object garage, Object code, String file, int line, String ref) {
        return Json.obj("kind", kind, "what", what, "garage", garage, "code", code, "ref", ref, "file", file, "line", line, "resolution", "code",
                "message", what + ": the Garage says " + garage + ", your code says " + code + (file != null ? " (" + file + ":" + line + ")" : "") + ". The export uses your code.");
    }

    // ---------------- questions: anything ambiguous is asked, never guessed ----------------

    @SuppressWarnings("unchecked")
    static void questions(Map<String, Object> model, OpModes om, PedroSetup ps, Hardware hw, KotlinScanner ks, List<Map<String, Object>> q) {
        Map<String, Object> pedro = Json.map(model.get("pedro"));
        if ("needs_confirmation".equals(pedro.get("status")))
            q.add(question("pedro_api_version", "Use the verified Pedro " + pedro.get("api_version") + " API for your Pedro " + pedro.get("version") + "?", true,
                    List.of(opt("yes", "Yes, use the " + pedro.get("api_version") + " API"), opt("no", "No, do not export")), null, (String) pedro.get("message"), null, 0));
        // test shots: the flywheel much slower, for testing the autonomous without launching pieces at full speed
        boolean speedKnown = false;
        for (Object o : Json.list(model.get("subsystems"))) if (!Json.list(Json.map(o).get("speed_setters")).isEmpty()) speedKnown = true;
        for (Object o : Json.list(model.get("hardware"))) {
            String n = String.valueOf(Json.map(Json.map(o).get("name")).get("value")).toLowerCase(Locale.ROOT);
            if (n.contains("fly") || n.contains("shoot") || n.contains("launch") || n.contains("outtake")) speedKnown = true;
        }
        if (om.scoring != null)
            q.add(question("shot_mode", "Real shots, or test shots? Test shots run the flywheel much slower (pieces just roll out), to try the autonomous safely. Never use a test export in a match.",
                    true, List.of(opt("real", "Real shots (competition)"), opt("test_30", "Test shots: flywheel at 30%"), opt("test_15", "Test shots: flywheel at 15%")), "real",
                    speedKnown ? "BEE slows the flywheel through your own speed methods." : "BEE could not find how your flywheel speed is set: test shots are not possible.", null, 0));
        // the start pose: the team's own poses, or BEE's start converted
        List<Object> opts = new ArrayList<>();
        for (Map<String, Object> p : om.startPoses.values()) {
            String label = (p.get("name") != null ? p.get("name") : "pose") + String.format(Locale.ROOT, "  (%.1f, %.1f, %.0f°)", (double) p.get("x"), (double) p.get("y"), Math.toDegrees((double) p.get("heading")));
            opts.add(opt(p.get("ref") != null ? (String) p.get("ref") : "pose@" + p.get("file") + ":" + p.get("line"), label + "  used by " + p.get("used_by")));
        }
        opts.add(opt("bee_start", om.startPoses.isEmpty() ? "BEE's start position from the Auto Builder, converted to Pedro field coordinates (check the field orientation)"
                : "Not recommended: BEE's start converted from BEE's map (a different field than your game's) — prefer one of your poses above"));
        q.add(question("start_pose", "Where does this autonomous start? BEE's path is relative to the start; the export places it on the field from this pose.",
                true, opts, opts.size() == 2 ? ((Map<String, Object>) opts.get(0)).get("value") : null,
                om.startPoses.isEmpty() ? "No start pose found in your autonomous code." : om.startPoses.size() + " start poses found in your autonomous code.", null, 0));
        // alliance (if the team's code sets it)
        boolean setsAlliance = false;
        for (Map<String, Object> o : om.opmodes) if (o.get("alliance") != null) setsAlliance = true;
        if (setsAlliance) {
            // the Garage robot's alliance is the default; one of the team's start poses decides it when chosen
            Object ga = Json.map(model.get("garage")).get("alliance");
            q.add(question("alliance", "Which alliance is this autonomous for? Your autos set the alliance in code (it changes which goal the turret aims at).", true,
                    List.of(opt("red", "Red"), opt("blue", "Blue")), "red".equals(ga) || "blue".equals(ga) ? ga : null,
                    "Taken from the start pose when you pick one of yours" + (ga != null ? "; otherwise the Garage robot's alliance (" + ga + ")." : "."), null, 0));
        }
        // left/right mirror of BEE's relative path (a field where blue is the mirror image of red)
        q.add(question("mirror_path", "Mirror the BEE path left ↔ right? On a field where the blue side is the mirror image of the red side, a path drawn for one side must be mirrored for the other.",
                true, List.of(opt("no", "No, drive it as drawn"), opt("yes", "Yes, mirror it (left becomes right)")), "no",
                "BEE checks that the path stays inside the field from the start you chose, and tells you which start / mirror fits.", null, 0));
        // the intake between shots: the team's autos run it on the way to collect, BEE paths often leave it on "keep"
        Map<String, Object> it = om.intake;
        if (it != null && it.get("on") != null && it.get("off") != null && om.scoring != null)
            q.add(question("intake_between_shots", "When your BEE path drives from one shot to the next without setting the intake, run the intake on the way (as your autos do: "
                    + Json.map(it.get("on")).get("call").toString().replace("{robot}", "robot") + " after a shot, " + Json.map(it.get("off")).get("call").toString().replace("{robot}", "robot") + " before the next)?",
                    true, List.of(opt("yes", "Yes, collect between shots"), opt("no", "No, only where my path says so")), "yes",
                    "Your autos: intake on at " + Json.map(it.get("on")).get("file") + ":" + Json.map(it.get("on")).get("line"), (String) Json.map(it.get("on")).get("file"), (int) Json.num(Json.map(it.get("on")).get("line"), 0)));
        // the team's per-loop logic (aiming...) copied into the export
        Map<String, Object> loop = om.loop;
        if (loop != null && loop.get("logic") != null && !Json.list(Json.map(loop.get("logic")).get("statements")).isEmpty()) {
            Map<String, Object> lg = Json.map(loop.get("logic"));
            q.add(question("copy_loop_logic", "Copy your per-loop logic from " + JavaIndex.simpleName(String.valueOf(loop.get("source"))) + "." + lg.get("method") + "() (e.g. aiming / flywheel speed from the camera) into the export?",
                    true, List.of(opt("yes", "Yes, run it every loop like my auto does"), opt("no", "No")), "yes",
                    Json.list(lg.get("statements")).size() + " statements, " + lg.get("file"), (String) lg.get("file"), 0));
        }
        // shooting guard: what if the guard (turret locked...) never becomes true?
        Map<String, Object> sc = om.scoring;
        if (sc != null && sc.get("guard") != null)
            q.add(question("guard_timeout", "Your auto only shoots when " + sc.get("guard") + ". If that is not true in time, what should the export do?", true,
                    List.of(opt("shoot", "Shoot anyway after the time limit"), opt("skip", "Skip this shot and go on")), "shoot",
                    "Guard at " + sc.get("file") + ":" + sc.get("guard_line"), (String) sc.get("file"), (int) sc.get("guard_line")));
        // preconditions with a fallback constant: Flywheel.velocity <- setFlywheelParameters(FALLBACK_VELOCITY, FALLBACK_ANGLE),
        // only for methods the export will really call (the scoring sequence)
        java.util.Set<String> used = new java.util.HashSet<>();
        if (sc != null) usedCalls(Json.list(sc.get("sequence")), used);
        for (Object s : Json.list(model.get("subsystems"))) {
            for (Object p : Json.list(Json.map(s).get("preconditions"))) {
                Map<String, Object> pm = Json.map(p);
                if (!used.contains(Json.map(s).get("class") + "#" + pm.get("method"))) continue;
                Map<String, Object> setter = Json.map(Json.list(pm.get("setters")).get(0));
                List<String> vals = new ArrayList<>();
                boolean all = true;
                for (Object f : Json.list(setter.get("fallbacks"))) {
                    if (f == null) { all = false; continue; }
                    vals.add(String.valueOf(Json.map(f).get("ref")));
                }
                String id = "precondition:" + JavaIndex.simpleName(String.valueOf(Json.map(s).get("class"))) + "." + pm.get("field");
                q.add(question(id, pm.get("message") + (all ? " Call " + setter.get("method") + "(" + String.join(", ", vals) + ") at init?" : " Which value should the export set?"),
                        true, all ? List.of(opt("fallback", "Yes: " + setter.get("method") + "(" + String.join(", ", vals) + ")"), opt("none", "No")) : List.of(opt("none", "Leave it")),
                        all ? "fallback" : null, (String) pm.get("message"), (String) pm.get("file"), (int) pm.get("line")));
            }
        }
        // low-confidence facts: shown for confirmation
        for (Device d : hw.devices) {
            if (Fact.rank(d.confidence) >= Fact.rank(Fact.HIGH)) continue;
            q.add(question("device:" + d.file + ":" + d.line, "Is \"" + d.name + "\" (" + d.javaType + ") the right hardware name? " + String.join(" → ", d.via), false,
                    List.of(opt("yes", "Yes"), opt("no", "No, fix it in my code")), "yes", d.evidence, d.file, d.line));
        }
        if (Json.map(model.get("paradigm")).get("value") != null && "mixed".equals(Json.map(model.get("paradigm")).get("value")))
            q.add(question("paradigm", "Your code uses both Road Runner Actions and FTCLib commands. Which should the autonomous use?", true,
                    List.of(opt("rr_actions", "Road Runner Actions"), opt("ftclib_commands", "FTCLib commands")), null, "", null, 0));
        if (!ks.devices.isEmpty())
            q.add(question("kotlin_facts", "Some of your robot is written in Kotlin; BEE read it with a simpler scanner (" + ks.devices.size() + " devices, " + ks.classes.size()
                    + " classes). Check them in the list and confirm.", true, List.of(opt("yes", "They are right"), opt("no", "Something is wrong")), null, "", null, 0));
        if (ps.factory != null && ps.warnings.stream().anyMatch(w -> "multiple_factories".equals(w.get("kind")))) {
            List<Object> fo = new ArrayList<>();
            for (Object c : Json.list(ps.warnings.stream().filter(w -> "multiple_factories".equals(w.get("kind"))).findFirst().get().get("candidates"))) fo.add(opt(String.valueOf(c), String.valueOf(c)));
            q.add(question("follower_factory", "Several methods create a Follower. Which one does the robot use?", true, fo, null, "", null, 0));
        }
    }

    static void usedCalls(List<Object> seq, java.util.Set<String> out) {
        for (Object o : seq) {
            Map<String, Object> st = Json.map(o);
            if ("parallel".equals(st.get("op"))) for (Object b : Json.list(st.get("branches"))) usedCalls(Json.list(b), out);
            else if (st.get("subsystem") != null) out.add(st.get("subsystem") + "#" + st.get("method"));
        }
    }

    static Map<String, Object> opt(String v, String label) { return Json.obj("value", v, "label", label); }

    static Map<String, Object> question(String id, String prompt, boolean required, List<Object> options, Object dflt, String why, String file, int line) {
        return Json.obj("id", id, "prompt", prompt, "required", required, "options", options, "default", dflt, "why", why, "file", file, "line", line);
    }
}
