package org.beesim.team;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Libraries and exact versions from ALL the build files: build.gradle(.kts), build.dependencies.gradle,
 * settings.gradle, gradle.properties, gradle/libs.versions.toml (version catalogs) and repositories { } blocks.
 *
 * Handles 'g:a:v', "g:a:$v", "g:a:${v}", group:/name:/version: maps, Kotlin DSL ("g:a:v"), variables from
 * def / val / ext { } / ext.x = / gradle.properties, and catalog aliases (libs.pedro.ftc).
 */
public final class GradleScanner {

    /** coordinate -> library id. A group with "*" matches every artifact of that group. */
    static final String[][] CATALOG = {
            {"com.pedropathing:ftc", "pedro_ftc"},
            {"com.pedropathing:core", "pedro_core"},
            {"com.pedropathing:revhub", "pedro_revhub"},
            {"com.pedropathing:telemetry", "pedro_telemetry"},
            {"com.pedropathing:tuning", "pedro_tuning"},
            {"com.pedropathing:ivy", "pedro_ivy"},
            {"com.acmerobotics.roadrunner:core", "roadrunner_core"},
            {"com.acmerobotics.roadrunner:actions", "roadrunner_actions"},
            {"com.acmerobotics.roadrunner:ftc", "roadrunner_ftc"},
            {"com.acmerobotics.dashboard:dashboard", "ftc_dashboard"},
            {"org.ftclib.ftclib:core", "ftclib"},
            {"org.ftclib.ftclib:vision", "ftclib_vision"},
            {"org.solverslib:*", "solverslib"},
            {"dev.nextftc:*", "nextftc"},
            {"com.bylazar:*", "panels"},
            {"org.firstinspires.ftc:RobotCore", "ftc_sdk"},
    };

    public final List<Map<String, Object>> deps = new ArrayList<>();
    public final List<Map<String, Object>> repositories = new ArrayList<>();
    public final List<Map<String, Object>> warnings = new ArrayList<>();
    private final Map<String, String> vars = new HashMap<>();
    private final Map<String, String[]> catalog = new HashMap<>();  // alias (dotted) -> {group, artifact, version or ""}

    private static final Pattern CONF = Pattern.compile("\\b(implementation|api|compileOnly|runtimeOnly|testImplementation|debugImplementation|releaseImplementation|annotationProcessor|kapt|ksp)\\b\\s*\\(?\\s*");

    public static GradleScanner scan(Map<String, String> files) {
        GradleScanner g = new GradleScanner();
        // 1. variables (gradle.properties, ext, def, val) and catalogs first: dependencies may use them
        for (Map.Entry<String, String> e : files.entrySet()) {
            String f = e.getKey();
            String t = stripComments(e.getValue(), f.endsWith(".toml") || f.endsWith(".properties"));
            if (f.endsWith("gradle.properties")) g.properties(t);
            else if (f.endsWith(".toml")) g.toml(t);
            else g.variables(t);
        }
        // 2. dependencies and repositories
        for (Map.Entry<String, String> e : files.entrySet()) {
            String f = e.getKey();
            if (f.endsWith(".toml") || f.endsWith(".properties")) continue;
            String t = stripComments(e.getValue(), false);
            g.dependencies(f, t);
            g.repositories(f, t);
        }
        return g;
    }

    // ---------------- variables ----------------

    private void properties(String t) {
        for (String line : t.split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) vars.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
        }
    }

    private static final Pattern VAR = Pattern.compile("(?:\\bdef|\\bval|\\bvar|\\bext\\.|\\bproject\\.ext\\.|\\brootProject\\.ext\\.)\\s*(\\w+)\\s*(?::\\s*\\w+\\s*)?=\\s*['\"]([^'\"$]+)['\"]");
    private static final Pattern EXT_BLOCK = Pattern.compile("\\bext\\s*\\{([^}]*)\\}");
    private static final Pattern ASSIGN = Pattern.compile("(\\w+)\\s*=\\s*['\"]([^'\"$]+)['\"]");
    private static final Pattern EXTRA = Pattern.compile("extra\\[\\s*\"(\\w+)\"\\s*\\]\\s*=\\s*\"([^\"$]+)\"");

    private void variables(String t) {
        Matcher m = VAR.matcher(t);
        while (m.find()) vars.put(m.group(1), m.group(2));
        m = EXT_BLOCK.matcher(t);
        while (m.find()) {
            Matcher a = ASSIGN.matcher(m.group(1));
            while (a.find()) vars.put(a.group(1), a.group(2));
        }
        m = EXTRA.matcher(t);
        while (m.find()) vars.put(m.group(1), m.group(2));
    }

    private static final Pattern TOML_SECTION = Pattern.compile("^\\s*\\[(\\w+)\\]\\s*$");
    private static final Pattern TOML_KV = Pattern.compile("^\\s*([\\w.-]+)\\s*=\\s*(.+?)\\s*$");

    private void toml(String t) {
        String section = "";
        Map<String, String> versions = new HashMap<>();
        List<String[]> libs = new ArrayList<>();
        for (String line : t.split("\n")) {
            Matcher s = TOML_SECTION.matcher(line);
            if (s.matches()) { section = s.group(1); continue; }
            Matcher kv = TOML_KV.matcher(line);
            if (!kv.matches()) continue;
            String k = kv.group(1), v = kv.group(2);
            if (section.equals("versions")) versions.put(k, unquote(v));
            else if (section.equals("libraries")) libs.add(new String[]{k, v});
        }
        for (String[] lib : libs) {
            String alias = lib[0].replace('-', '.').replace('_', '.');
            String v = lib[1];
            String group = "", artifact = "", version = "";
            if (v.startsWith("\"")) {
                String[] p = unquote(v).split(":");
                if (p.length >= 2) { group = p[0]; artifact = p[1]; }
                if (p.length >= 3) version = p[2];
            } else {
                String module = tomlField(v, "module");
                if (!module.isEmpty()) {
                    String[] p = module.split(":");
                    group = p[0];
                    artifact = p.length > 1 ? p[1] : "";
                } else {
                    group = tomlField(v, "group");
                    artifact = tomlField(v, "name");
                }
                version = tomlField(v, "version");
                String ref = tomlField(v, "version.ref");
                if (!ref.isEmpty()) version = versions.getOrDefault(ref, "");
            }
            catalog.put(alias, new String[]{group, artifact, version});
        }
    }

    private static String tomlField(String inline, String key) {
        Matcher m = Pattern.compile("(?:^|[{,\\s])" + Pattern.quote(key) + "\\s*=\\s*\"([^\"]*)\"").matcher(inline);
        return m.find() ? m.group(1) : "";
    }

    private static String unquote(String s) {
        s = s.trim();
        if (s.length() >= 2 && (s.startsWith("\"") || s.startsWith("'"))) return s.substring(1, s.length() - 1);
        return s;
    }

    // ---------------- dependencies ----------------

    private static final Pattern STR_DEP = Pattern.compile("^(['\"])([\\w.\\-]+):([\\w.\\-]+)(?::([^'\"@]+))?(?:@\\w+)?\\1");
    private static final Pattern MAP_DEP = Pattern.compile("^group\\s*:\\s*['\"]([^'\"]+)['\"]\\s*,\\s*name\\s*:\\s*['\"]([^'\"]+)['\"](?:\\s*,\\s*version\\s*:\\s*['\"]([^'\"]+)['\"])?");
    private static final Pattern CATALOG_DEP = Pattern.compile("^libs\\.([\\w.]+)");

    private void dependencies(String file, String t) {
        Matcher c = CONF.matcher(t);
        while (c.find()) {
            String rest = t.substring(c.end());
            int line = lineOf(t, c.start());
            String conf = c.group(1);
            Matcher m;
            if ((m = STR_DEP.matcher(rest)).find()) {
                String raw = m.group(4) == null ? "" : m.group(4);
                String v = resolve(raw);
                add(file, line, conf, m.group(2), m.group(3), v, raw.equals(v) ? Fact.HIGH : (v.isEmpty() ? Fact.LOW : Fact.MEDIUM),
                        m.group(0) + (raw.equals(v) ? "" : "  (" + raw + " = " + v + ")"));
            } else if ((m = MAP_DEP.matcher(rest)).find()) {
                String raw = m.group(3) == null ? "" : m.group(3);
                String v = resolve(raw);
                add(file, line, conf, m.group(1), m.group(2), v, raw.equals(v) ? Fact.HIGH : Fact.MEDIUM, m.group(0));
            } else if ((m = CATALOG_DEP.matcher(rest)).find()) {
                String alias = m.group(1);
                String[] lib = catalog.get(alias);
                if (lib == null) {
                    warnings.add(Json.obj("file", file, "line", line, "message", "Version catalog alias libs." + alias + " is not in gradle/libs.versions.toml"));
                } else {
                    add(file, line, conf, lib[0], lib[1], lib[2], lib[2].isEmpty() ? Fact.LOW : Fact.HIGH, "libs." + alias + " -> " + lib[0] + ":" + lib[1] + ":" + lib[2]);
                }
            }
        }
    }

    /** "$x", "${x}", "${rootProject.ext.x}", "$rootProject.x" -> value; "" when unknown. */
    private String resolve(String raw) {
        if (!raw.contains("$")) return raw;
        Matcher m = Pattern.compile("\\$\\{?\\s*(?:rootProject\\.|project\\.)?(?:ext\\.)?(\\w+)\\s*\\}?").matcher(raw);
        StringBuilder sb = new StringBuilder();
        int last = 0;
        while (m.find()) {
            String v = vars.get(m.group(1));
            if (v == null) return "";
            sb.append(raw, last, m.start()).append(v);
            last = m.end();
        }
        return sb.append(raw.substring(last)).toString();
    }

    private void add(String file, int line, String conf, String group, String artifact, String version, String confidence, String evidence) {
        Map<String, Object> d = new LinkedHashMap<>();
        d.put("group", group);
        d.put("artifact", artifact);
        d.put("version", version);
        d.put("configuration", conf);
        d.put("library", libraryId(group, artifact));
        d.put("file", file);
        d.put("line", line);
        d.put("confidence", confidence);
        d.put("evidence", evidence.trim());
        deps.add(d);
    }

    public static String libraryId(String group, String artifact) {
        for (String[] c : CATALOG) {
            String[] ga = c[0].split(":");
            if (ga[0].equals(group) && (ga[1].equals("*") || ga[1].equals(artifact))) return c[1];
        }
        return "";
    }

    // ---------------- repositories ----------------

    private static final Pattern REPO_URL = Pattern.compile("maven\\s*(?:\\{[^}]*?url\\s*(?:=\\s*)?(?:uri\\s*\\()?\\s*['\"]([^'\"]+)['\"]|\\(\\s*['\"]([^'\"]+)['\"])");
    private static final Pattern REPO_NAMED = Pattern.compile("\\b(mavenCentral|google|mavenLocal|jcenter|gradlePluginPortal)\\s*\\(\\s*\\)");

    private void repositories(String file, String t) {
        Matcher m = REPO_URL.matcher(t);
        while (m.find()) {
            String url = m.group(1) != null ? m.group(1) : m.group(2);
            repositories.add(Json.obj("url", url, "file", file, "line", lineOf(t, m.start())));
        }
        m = REPO_NAMED.matcher(t);
        while (m.find()) {
            String url = switch (m.group(1)) {
                case "mavenCentral" -> "https://repo1.maven.org/maven2";
                case "google" -> "https://dl.google.com/dl/android/maven2";
                case "jcenter" -> "https://jcenter.bintray.com";
                default -> m.group(1);
            };
            repositories.add(Json.obj("url", url, "name", m.group(1), "file", file, "line", lineOf(t, m.start())));
        }
    }

    // ---------------- summary ----------------

    /**
     * library id -> {version, group, artifact, file, line, confidence, evidence}. When the same library is declared twice
     * with different versions, the summary keeps the highest one and the model reports a conflict.
     */
    public Map<String, Object> libraries(List<Map<String, Object>> conflicts) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (Map<String, Object> d : deps) {
            String id = (String) d.get("library");
            if (id.isEmpty()) continue;
            String key = id.equals("panels") || id.equals("nextftc") || id.equals("solverslib") ? id + ":" + d.get("artifact") : id;
            @SuppressWarnings("unchecked")
            Map<String, Object> old = (Map<String, Object>) out.get(key);
            if (old != null && !old.get("version").equals(d.get("version"))) {
                conflicts.add(Json.obj("kind", "library_version", "library", key,
                        "message", key + " is declared with two versions: " + old.get("version") + " (" + old.get("file") + ":" + old.get("line") + ") and "
                                + d.get("version") + " (" + d.get("file") + ":" + d.get("line") + "). Gradle uses the highest.",
                        "sources", List.of(Fact.src((String) old.get("file"), (int) old.get("line")), Fact.src((String) d.get("file"), (int) d.get("line")))));
                if (Version.compare((String) d.get("version"), (String) old.get("version")) <= 0) continue;
            }
            out.put(key, d);
        }
        return out;
    }

    // ---------------- utils ----------------

    static int lineOf(String t, int pos) {
        int n = 1;
        for (int i = 0; i < pos && i < t.length(); i++) if (t.charAt(i) == '\n') n++;
        return n;
    }

    /** Removes // and block comments (keeps line breaks so line numbers stay right) and skips text in quotes. */
    static String stripComments(String t, boolean hashComments) {
        StringBuilder sb = new StringBuilder(t.length());
        int n = t.length();
        for (int i = 0; i < n; i++) {
            char c = t.charAt(i);
            if (c == '"' || c == '\'') {
                int j = i + 1;
                while (j < n && t.charAt(j) != c && t.charAt(j) != '\n') j += t.charAt(j) == '\\' ? 2 : 1;
                sb.append(t, i, Math.min(j + 1, n));
                i = j;
            } else if (!hashComments && c == '/' && i + 1 < n && t.charAt(i + 1) == '/') {
                while (i < n && t.charAt(i) != '\n') i++;
                if (i < n) sb.append('\n');
            } else if (hashComments && c == '#') {
                while (i < n && t.charAt(i) != '\n') i++;
                if (i < n) sb.append('\n');
            } else if (!hashComments && c == '/' && i + 1 < n && t.charAt(i + 1) == '*') {
                int e = t.indexOf("*/", i + 2);
                int end = e < 0 ? n : e + 2;
                for (int k = i; k < end; k++) if (t.charAt(k) == '\n') sb.append('\n');
                i = end - 1;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
