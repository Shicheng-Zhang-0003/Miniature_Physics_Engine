package org.beesim.team;

/** Maven-style version comparison, good enough for x.y.z(-qualifier). */
public final class Version {
    private Version() {}

    public static int[] parts(String v) {
        String core = v.split("[-+]")[0];
        String[] p = core.split("\\.");
        int[] out = new int[3];
        for (int i = 0; i < 3 && i < p.length; i++) {
            try { out[i] = Integer.parseInt(p[i].replaceAll("\\D.*", "")); } catch (NumberFormatException e) { out[i] = 0; }
        }
        return out;
    }

    public static int compare(String a, String b) {
        int[] x = parts(a), y = parts(b);
        for (int i = 0; i < 3; i++) if (x[i] != y[i]) return Integer.compare(x[i], y[i]);
        // 2.1.0-beta.1 < 2.1.0
        boolean qa = a.contains("-"), qb = b.contains("-");
        if (qa != qb) return qa ? -1 : 1;
        return a.compareTo(b);
    }

    public static int major(String v) {
        return parts(v)[0];
    }

    public static String majorMinor(String v) {
        int[] p = parts(v);
        return p[0] + "." + p[1];
    }
}
