package org.beesim.team;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * The Pedro Pathing API exactly as published, per version (resources/pedro-api/<version>.json, written by
 * tools/verify_pedro_api.py from the real artifacts with javap). Nothing about Pedro is taken from memory:
 * the generator asks this table before it emits a class or a method.
 */
public final class PedroApi {
    public final String version;
    public final Map<String, Object> doc;
    private final Map<String, Object> classes;

    private PedroApi(String version, Map<String, Object> doc) {
        this.version = version;
        this.doc = doc;
        this.classes = Json.map(doc.get("classes"));
    }

    private static Path dir;

    public static void setDir(Path d) { dir = d; }

    public static Path dir() {
        if (dir != null) return dir;
        String p = System.getProperty("bee.pedroApi");
        if (p != null) return Path.of(p);
        return Path.of("java/tools/analyzer/resources/pedro-api");
    }

    /** All verified versions, sorted. */
    public static List<String> verified() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.forEach(f -> {
                String n = f.getFileName().toString();
                if (n.endsWith(".json")) out.add(n.substring(0, n.length() - 5));
            });
        } catch (IOException e) {
            return out;
        }
        out.sort(Version::compare);
        return out;
    }

    private static final Map<String, PedroApi> CACHE = new TreeMap<>();

    public static PedroApi load(String version) {
        return CACHE.computeIfAbsent(version, v -> {
            try {
                return new PedroApi(v, Json.map(Json.parse(Files.readString(dir().resolve(v + ".json")))));
            } catch (IOException e) {
                return null;
            }
        });
    }

    public boolean hasClass(String fqn) { return classes.containsKey(fqn); }

    public List<String> members(String fqn) {
        List<String> out = new ArrayList<>();
        for (Object o : Json.list(Json.map(classes.get(fqn)).get("members"))) out.add((String) o);
        return out;
    }

    /**
     * Does `fqn` have a public method / constructor `name` taking exactly these parameter types (fully qualified,
     * e.g. "com.pedropathing.geometry.Pose", "double", "boolean")? name "<init>" = constructor.
     */
    public boolean has(String fqn, String name, String... paramTypes) {
        String want = String.join(", ", paramTypes);
        for (String m : members(fqn)) {
            int p = m.indexOf('(');
            if (p < 0) continue;
            String head = m.substring(0, p);
            String mname = head.substring(head.lastIndexOf(' ') + 1);
            if (name.equals("<init>") ? !(mname.equals(fqn)) : !mname.equals(name)) continue;
            String args = m.substring(p + 1, m.lastIndexOf(')')).replaceAll("\\.\\.\\.", "[]");
            if (args.equals(want.replace("...", "[]"))) return true;
        }
        return false;
    }

    /** Names of the parameters (from the sources jar), e.g. PathConstraints <init>/4. */
    public List<String> paramNames(String fqn, String name, int n) {
        List<String> out = new ArrayList<>();
        for (Object o : Json.list(Json.map(Json.map(classes.get(fqn)).get("params")).get(name + "/" + n))) out.add((String) o);
        return out;
    }

    public String fieldDefault(String fqn, String field) {
        Object v = Json.map(Json.map(classes.get(fqn)).get("field_defaults")).get(field);
        return v == null ? null : v.toString();
    }

    public List<Object> artifacts() { return Json.list(doc.get("artifacts")); }
}
