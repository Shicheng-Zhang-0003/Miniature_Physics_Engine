package org.beesim.team.gen;

import org.beesim.team.PedroApi;
import org.beesim.team.Version;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The ONLY place where Pedro Pathing code text is written. The generated OpMode depends on this small surface:
 * create / get the follower, set the start pose, update, a line path with linear or constant heading, follow it
 * (with a max power), isBusy, the current pose, hold where it is, and turn in place.
 *
 * Each adapter lists the members it emits ({@link #required()}); {@link #check(PedroApi)} verifies every one of them
 * against the API table of the team's exact version before anything is generated. A new Pedro version = a new
 * table (tools/verify_pedro_api.py) and, only if the API really changed, a new adapter.
 */
public abstract class PedroAdapter {
    protected final PedroApi api;

    protected PedroAdapter(PedroApi api) { this.api = api; }

    public static PedroAdapter forVersion(String apiVersion) {
        PedroApi api = PedroApi.load(apiVersion);
        if (api == null) return null;
        int major = Version.major(apiVersion);
        if (major == 2) return new Pedro2Adapter(api);
        if (major == 3) return new Pedro3Adapter(api);
        return null;
    }

    public String version() { return api.version; }

    /** {class fqn, member name or "<init>", parameter types...} */
    public abstract List<String[]> required();

    /** Members this adapter would emit but the version's table does not have. Empty = safe to generate. */
    public List<String> check() {
        List<String> missing = new ArrayList<>();
        for (String[] r : required()) {
            String[] params = new String[r.length - 2];
            System.arraycopy(r, 2, params, 0, params.length);
            if (r[1].equals("@class")) {
                if (!api.hasClass(r[0])) missing.add(r[0]);
            } else if (r[1].equals("@extends")) {
                if (!isA(r[0], r[2])) missing.add(r[0] + " is a " + r[2]);
            } else if (!api.has(r[0], r[1], params)) {
                missing.add(r[0] + "." + r[1] + "(" + String.join(", ", params) + ")");
            }
        }
        return missing;
    }

    /** class `fqn` extends / implements `sup` (following the table's super / interfaces). */
    protected boolean isA(String fqn, String sup) {
        for (int guard = 0; fqn != null && !fqn.isEmpty() && guard < 8; guard++) {
            if (fqn.equals(sup)) return true;
            Map<String, Object> c = org.beesim.team.Json.map(org.beesim.team.Json.map(api.doc.get("classes")).get(fqn));
            String ifs = String.valueOf(c.getOrDefault("interfaces", ""));
            for (String i : ifs.split(",")) if (i.trim().replaceAll("<.*>", "").equals(sup)) return true;
            fqn = String.valueOf(c.getOrDefault("super", "")).replaceAll("<.*>", "");
        }
        return false;
    }

    // ---- the surface used by the generator ----
    public abstract List<String> imports();

    public abstract String poseType();

    public abstract String pathType();

    public abstract String newPose(String x, String y, String h);

    public abstract String x(String pose);

    public abstract String y(String pose);

    public abstract String heading(String pose);

    /** A straight path a -> b. headingMode "linear" (a.heading -> b.heading) or "constant" (b.heading). */
    public abstract String line(String follower, String a, String b, String headingMode);

    /** Start following; maxPower in (0, 1]. Returns statements. */
    public abstract List<String> follow(String follower, String path, double maxPower, List<String> notes);

    /** Start following with the max power held in a variable (FollowPath helper). */
    public abstract List<String> followWithPower(String follower, String path, String powerVar);

    /** Does follow honor a max power below 1? */
    public abstract boolean supportsMaxPower();

    public abstract String isBusy(String follower);

    public abstract String pose(String follower);

    public abstract List<String> holdHere(String follower);

    /** Start turning in place to `radians` (field heading). */
    public abstract List<String> turnTo(String follower, String radians);

    /** True while the turn started by turnTo is not finished. */
    public abstract String turning(String follower, String radians);

    public abstract String update(String follower);

    public abstract String setStartingPose(String follower, String pose);

    /** Tuning parameters that EXIST in this version: key, label, unit, builder.method, sign rule, sim key. */
    public abstract List<Map<String, Object>> tuningSchema();

    public abstract String label();
}
