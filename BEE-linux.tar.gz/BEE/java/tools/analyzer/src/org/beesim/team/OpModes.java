package org.beesim.team;

import com.sun.source.tree.AssignmentTree;
import com.sun.source.tree.BlockTree;
import com.sun.source.tree.CaseTree;
import com.sun.source.tree.EnhancedForLoopTree;
import com.sun.source.tree.ExpressionStatementTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.IdentifierTree;
import com.sun.source.tree.IfTree;
import com.sun.source.tree.LambdaExpressionTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.ReturnTree;
import com.sun.source.tree.StatementTree;
import com.sun.source.tree.SwitchTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.tree.WhileLoopTree;
import com.sun.source.util.TreePath;
import org.beesim.team.JavaIndex.ClassInfo;
import org.beesim.team.JavaIndex.FieldInfo;
import org.beesim.team.JavaIndex.MethodInfo;
import org.beesim.team.Subsystems.Api;
import org.beesim.team.Subsystems.Effect;
import org.beesim.team.Subsystems.Sub;
import org.beesim.team.Walk.Hit;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The team's OpModes are the ground truth for how the robot really scores: start poses and their units, how the
 * alliance is set, the order of the per-loop calls, the scoring call (robot.shootAll()) flattened into its steps
 * (with which gate opens when), the action runner, intake on/off as the autos do it, and bugs worth a warning.
 */
public final class OpModes {
    private final JavaIndex ix;
    private final Eval ev;
    private final Subsystems subs;
    private final PedroSetup pedro;

    public final List<Map<String, Object>> opmodes = new ArrayList<>();
    public final Map<String, Map<String, Object>> startPoses = new LinkedHashMap<>();   // ref -> pose
    public Map<String, Object> scoring;     // the scoring call + flattened sequence + capacity
    public Map<String, Object> loop;        // order of the per-loop calls of the reference auto
    public Map<String, Object> runner;      // how the team runs Actions / Commands
    public Map<String, Object> intake;      // intake on / off as the autos do it
    public Map<String, Object> paradigm;
    public Map<String, Object> teamActions; // the team's OWN Action class (not Road Runner's): how to run one
    private ClassInfo teamAction;
    public Map<String, Object> coordinates;
    public final List<Map<String, Object>> teamBugs = new ArrayList<>();
    public final List<Map<String, Object>> warnings = new ArrayList<>();
    public final List<Map<String, Object>> pathPoses = new ArrayList<>();

    static final Set<String> SEQ = Set.of("SequentialAction", "SequentialCommandGroup", "SequentialGroup", "Sequential");
    static final Set<String> PAR = Set.of("ParallelAction", "ParallelCommandGroup", "ParallelGroup", "Parallel", "ParallelDeadlineGroup", "ParallelRaceGroup", "RaceAction");
    static final Map<String, Double> SLEEP = Map.of("SleepAction", 1.0, "WaitCommand", 0.001, "Delay", 1.0, "WaitAction", 1.0);

    public OpModes(JavaIndex ix, Eval ev, Subsystems subs, PedroSetup pedro) { this.ix = ix; this.ev = ev; this.subs = subs; this.pedro = pedro; }

    public void run() {
        findTeamAction();
        List<ClassInfo> autos = new ArrayList<>();
        for (ClassInfo c : ix.classes()) {
            if (!subs.isOpMode(c) || c.isAbstract) continue;
            if (ix.isA(c, "SelectableOpMode") && c.methods("loop").isEmpty() && c.methods("runOpMode").isEmpty()) {
                opmodes.add(Json.obj("class", c.fqn, "kind", c.annotations.contains("TeleOp") ? "teleop" : "auto", "style", "selector", "file", c.src.path, "line", c.line));
                continue;
            }
            boolean auto = c.annotations.contains("Autonomous") || selectedBy(c, "Autonomous") || c.simple.toLowerCase(Locale.ROOT).contains("auto");
            boolean tele = c.annotations.contains("TeleOp") || selectedBy(c, "TeleOp");
            boolean linear = ix.isA(c, "LinearOpMode") || !c.methods("runOpMode").isEmpty();
            Map<String, Object> om = Json.obj("class", c.fqn, "simple", c.simple, "package", c.pkg, "kind", auto ? "auto" : tele ? "teleop" : "other",
                    "style", linear ? "linear" : "iterative", "base", c.superName, "file", c.src.path, "line", c.line, "test_like", testLike(c));
            opmodes.add(om);
            if (auto) {
                autos.add(c);
                analyzeAuto(c, om);
            }
        }
        // the reference auto: the most complete one (scores, runs actions), not a test
        ClassInfo ref = null;
        int best = -1;
        for (ClassInfo c : autos) {
            Map<String, Object> om = find(c);
            int score = (om.get("scoring_call") != null ? 4 : 0) + (om.get("loop_order") != null ? 2 : 0) + (om.get("start_pose") != null ? 1 : 0) - (Boolean.TRUE.equals(om.get("test_like")) ? 5 : 0);
            if (score > best) { best = score; ref = c; }
        }
        if (ref != null) {
            Map<String, Object> om = find(ref);
            om.put("reference", true);
            // imports of the BaseOpMode too: its loop statements are copied as well
            Set<String> srcImports = new LinkedHashSet<>();
            for (ClassInfo k = ref; k != null; k = ix.superOf(k)) srcImports.addAll(k.src.imports);
            loop = Json.obj("source", ref.fqn, "file", ref.src.path, "order", om.get("loop_order"), "logic", om.get("loop_logic"), "fields", om.get("loop_fields"),
                    "start_statements", om.get("start_statements"), "init_statements", om.get("init_statements"), "source_imports", new ArrayList<>(srcImports),
                    "robot_init_calls", om.get("robot_init_calls"), "stop_statements", om.get("stop_statements"));
        }
        startPoseConstants();
        scoringAndParadigm(autos, ref);
        coordinateConvention();
        for (ClassInfo c : autos) lint(c);
    }

    private boolean selectedBy(ClassInfo c, String annotation) {
        // SelectableOpMode: a.add("Far Side", RedFarSide::new) inside a class annotated @Autonomous
        for (ClassInfo s : ix.classes()) {
            if (!s.annotations.contains(annotation) || s == c) continue;
            for (Hit h : Walk.find(s, t -> t.getKind() == Tree.Kind.MEMBER_REFERENCE)) if (h.leaf().toString().startsWith(c.simple + "::")) return true;
        }
        return false;
    }

    private static boolean testLike(ClassInfo c) {
        String p = (c.src.path + "/" + c.simple).toLowerCase(Locale.ROOT);
        for (String w : new String[]{"test", "tuning", "tuner", "calibrat", "example", "sample", "simple"}) if (p.contains(w)) return true;
        return false;
    }

    private Map<String, Object> find(ClassInfo c) {
        for (Map<String, Object> m : opmodes) if (c.fqn.equals(m.get("class"))) return m;
        return null;
    }

    // ---------------- one autonomous ----------------

    private void analyzeAuto(ClassInfo c, Map<String, Object> om) {
        Subsystems.Wrapper w = subs.wrapper;
        // the robot wrapper field and the start pose it is built with
        String robotVar = null;
        // also inherited: protected Robot robot; in a BaseOpMode the autos extend
        for (ClassInfo k = c; k != null && robotVar == null; k = ix.superOf(k))
            for (FieldInfo f : k.fields.values()) if (w != null && ix.resolveType(f.type, k) == w.cls) robotVar = f.name;
        om.put("robot_var", robotVar);
        for (Hit h : Walk.find(c, t -> t instanceof NewClassTree || t instanceof MethodInvocationTree || t instanceof AssignmentTree)) {
            Tree t = h.leaf();
            if (t instanceof NewClassTree && w != null && ix.resolveType(((NewClassTree) t).getIdentifier().toString(), c) == w.cls) {
                om.put("robot_ctor", Json.obj("text", ix.text(c.src, t), "in", h.method == null ? null : h.method.name, "line", h.line(ix)));
                for (ExpressionTree a : ((NewClassTree) t).getArguments()) poseArg(a, c, om, h);
            } else if (t instanceof MethodInvocationTree && (Walk.methodName((MethodInvocationTree) t).equals("setStartingPose") || Walk.methodName((MethodInvocationTree) t).equals("setPose"))
                    && ((MethodInvocationTree) t).getArguments().size() == 1) {
                poseArg(((MethodInvocationTree) t).getArguments().get(0), c, om, h);
            } else if (t instanceof AssignmentTree) {
                // Config.color = Config.Color.BLUE
                AssignmentTree a = (AssignmentTree) t;
                String target = JavaIndex.dotted(a.getVariable());
                Val v = ev.eval(a.getExpression(), c);
                if (target != null && v != null && v.kind == Val.K.ENUM && (v.str.contains("RED") || v.str.contains("BLUE"))) {
                    om.put("alliance", Json.obj("value", v.str.contains("RED") ? "red" : "blue", "statement", ix.text(c.src, t) + ";", "target", target,
                            "value_ref", JavaIndex.dotted(a.getExpression()), "in", h.method == null ? null : h.method.name, "file", c.src.path, "line", h.line(ix)));
                }
            }
        }
        // BezierLine / BezierCurve poses used by the paths
        for (Hit h : Walk.find(c, t -> t instanceof NewClassTree && (t.toString().startsWith("new BezierLine") || t.toString().startsWith("new BezierCurve")))) {
            for (ExpressionTree a : ((NewClassTree) h.leaf()).getArguments()) {
                Val v = ev.eval(a, c);
                if (v != null && v.kind == Val.K.POSE) pathPoses.add(Json.obj("ref", v.ref, "x", v.x, "y", v.y, "h", v.h, "has_heading", v.poseHasHeading, "file", c.src.path, "line", h.line(ix)));
            }
        }
        // the per-loop body (an inherited loop() too: the auto's BaseOpMode runs the robot)
        List<MethodInfo> loops = ix.methods(c, "loop");
        MethodInfo loopM = loops.isEmpty() ? null : loops.get(0);
        List<Stmt> body = loopM == null || loopM.body == null ? null : flat(loopM.owner, loopM, 0);
        MethodInfo linear = first(c, "runOpMode");
        if (body == null && linear != null) {
            for (Hit h : Walk.find(c, linear, t -> t instanceof WhileLoopTree)) {
                String cond = ((WhileLoopTree) h.leaf()).getCondition().toString();
                if (cond.contains("opModeIsActive") && ((WhileLoopTree) h.leaf()).getStatement() instanceof BlockTree) {
                    body = new ArrayList<>();
                    for (StatementTree st : ((BlockTree) ((WhileLoopTree) h.leaf()).getStatement()).getStatements()) body.add(new Stmt(c, linear, st));
                    loopM = linear;
                    break;
                }
            }
        }
        if (body != null) classifyLoop(loopM, body, om, robotVar);
        List<MethodInfo> starts = ix.methods(c, "start");
        if (!starts.isEmpty() && starts.get(0).body != null) om.put("start_statements", cloneable(flat(starts.get(0).owner, starts.get(0), 0), robotVar));
        // stop(): robot.stop() ends the team's background threads (async odometry...): the export must do it too
        List<MethodInfo> stops = ix.methods(c, "stop");
        if (!stops.isEmpty() && stops.get(0).body != null) om.put("stop_statements", cloneable(flat(stops.get(0).owner, stops.get(0), 0), robotVar));
        List<MethodInfo> inits = ix.methods(c, "init");
        if (!inits.isEmpty() && inits.get(0).body != null) {
            List<Stmt> initFlat = flat(inits.get(0).owner, inits.get(0), 0);
            om.put("init_statements", cloneable(initFlat, robotVar));
            // robot.init() right after new Robot(hardwareMap): the export builds the robot the same way
            List<String> after = new ArrayList<>();
            for (Stmt s : initFlat) {
                if (robotVar == null || !(s.st instanceof ExpressionStatementTree) || !(((ExpressionStatementTree) s.st).getExpression() instanceof MethodInvocationTree)) continue;
                MethodInvocationTree mi = (MethodInvocationTree) ((ExpressionStatementTree) s.st).getExpression();
                if (robotVar.equals(Walk.receiver(mi)) && mi.getArguments().isEmpty() && Walk.methodName(mi).startsWith("init")) after.add(Walk.methodName(mi));
            }
            if (!after.isEmpty()) om.put("robot_init_calls", after);
        }
        // the scoring call: add(robot.shootAll()) / schedule(...) / robot.shoot() inside the state machine
        for (Hit h : Walk.find(c, t -> t instanceof MethodInvocationTree)) {
            MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
            String fn = Walk.methodName(mi);
            if (fn.equals("add") || fn.equals("schedule") || fn.equals("runBlocking") || fn.equals("run")) {
                for (ExpressionTree a : mi.getArguments()) {
                    if (!(a instanceof MethodInvocationTree)) continue;
                    String an = Walk.methodName((MethodInvocationTree) a).toLowerCase(Locale.ROOT);
                    if (isScoringName(an)) recordScoring(c, h, (MethodInvocationTree) a, mi, om, robotVar);
                }
            } else if (isScoringName(fn.toLowerCase(Locale.ROOT)) && om.get("scoring_call") == null && !(h.parent() instanceof MethodInvocationTree)) {
                recordScoring(c, h, mi, null, om, robotVar);
            }
            // intake on / off exactly as the autos do it
            String r = Walk.receiver(mi);
            if (r != null && !r.contains(".") && (fn.equals("setPower") || fn.equals("setVelocity"))) {
                // teams without subsystems: intake.setPower(1.0) on a motor of the OpMode itself
                Hardware.Device dev = null;
                for (Hardware.Device x : hwAll()) if (x.field != null && x.field.equals(r) && (x.declaredIn == c || x.owner == c)) dev = x;
                String low = r.toLowerCase(Locale.ROOT) + " " + String.valueOf(dev == null ? "" : dev.name).toLowerCase(Locale.ROOT);
                if (dev != null && (low.contains("intake") || low.contains("roller") || low.contains("sweep"))) {
                    Val v = mi.getArguments().isEmpty() ? null : ev.eval(mi.getArguments().get(0), c);
                    boolean off = v != null && v.isNum() && v.num == 0;
                    if (intake == null) intake = new LinkedHashMap<>();
                    String key = off ? "off" : "on";
                    String arg = v == null ? null : v.ref != null ? v.ref : v.isNum() ? String.valueOf(v.num) : null;
                    if (!intake.containsKey(key) && arg != null)
                        intake.put(key, Json.obj("call", r + "." + fn + "(" + arg + ")", "device", dev.name, "field", r, "import", v.imp, "file", c.src.path, "line", h.line(ix),
                                "confidence", Fact.MEDIUM, "evidence", "the motor \"" + dev.name + "\" used in " + c.simple));
                }
            }
            if (r != null && robotVar != null && r.startsWith(robotVar + ".")) {
                Sub s = subOf(r.substring(robotVar.length() + 1));
                if (s != null && "intake".equals(s.role) && (fn.equals("setPower") || fn.startsWith("turnOn") || fn.startsWith("turnOff") || fn.equals("on") || fn.equals("off"))) {
                    Val v = mi.getArguments().isEmpty() ? null : ev.eval(mi.getArguments().get(0), c);
                    boolean off = fn.startsWith("turnOff") || fn.equals("off") || (v != null && v.isNum() && v.num == 0);
                    if (intake == null) intake = new LinkedHashMap<>();
                    String key = off ? "off" : "on";
                    if (!intake.containsKey(key))
                        intake.put(key, Json.obj("call", ix.text(c.src, mi).replaceFirst("^" + robotVar + "\\.", "{robot}."), "file", c.src.path, "line", h.line(ix), "confidence", Fact.HIGH,
                                "evidence", "used in " + c.simple));
                }
            }
        }
    }

    static boolean isScoringName(String n) {
        return n.startsWith("shoot") || n.startsWith("score") || n.startsWith("launch") || n.startsWith("fire") || n.startsWith("outtake") || n.equals("deposit");
    }

    private static MethodInfo first(ClassInfo c, String name) {
        List<MethodInfo> l = c.methods(name);
        return l.isEmpty() ? null : l.get(0);
    }

    private void poseArg(ExpressionTree a, ClassInfo c, Map<String, Object> om, Hit h) {
        Val v = ev.eval(a, c);
        if (v == null || v.kind != Val.K.POSE) return;
        String key = v.ref != null ? v.ref : v.privateRef != null ? v.privateRef : c.simple + ":" + h.line(ix);
        Map<String, Object> p = Json.obj("ref", v.ref, "name", key, "import", v.imp, "x", v.x, "y", v.y, "heading", v.h, "uses_toRadians", v.usesToRadians,
                "file", v.file == null ? c.src.path : v.file, "line", v.file == null ? h.line(ix) : v.line, "used_by", new ArrayList<String>());
        om.put("start_pose", p);
        Map<String, Object> old = startPoses.get(key);
        if (old == null) { startPoses.put(key, p); old = p; }
        @SuppressWarnings("unchecked") List<String> used = (List<String>) old.get("used_by");
        used.add(c.fqn);
    }

    public final List<Map<String, Object>> shootingPoses = new ArrayList<>();

    /** Every static Pose constant named like a start pose is a candidate, even when no working auto uses it. */
    private void startPoseConstants() {
        // where the team shoots from (shootingPose, SCORE_POSE...): BEE paths are compared with these
        for (ClassInfo c : ix.classes())
            for (FieldInfo f : c.fields.values()) {
                String n = f.name.toLowerCase(Locale.ROOT);
                if (!f.isStatic || !(n.contains("shoot") || n.contains("score") || n.contains("launch"))) continue;
                Val v = ev.fieldValue(f, 0);
                if (v != null && v.kind == Val.K.POSE)
                    shootingPoses.add(Json.obj("name", v.ref != null ? v.ref : v.privateRef, "x", v.x, "y", v.y, "file", v.file, "line", v.line));
            }
        for (ClassInfo c : ix.classes()) {
            for (FieldInfo f : c.fields.values()) {
                if (!f.isStatic || !f.name.toLowerCase(Locale.ROOT).contains("start")) continue;
                Val v = ev.fieldValue(f, 0);
                if (v == null || v.kind != Val.K.POSE) continue;
                String key = v.ref != null ? v.ref : v.privateRef;
                if (startPoses.containsKey(key)) continue;
                boolean dup = false;
                for (Map<String, Object> p : startPoses.values()) if (v.file != null && v.file.equals(p.get("file")) && Integer.valueOf(v.line).equals(p.get("line"))) dup = true;
                if (dup) continue;
                startPoses.put(key, Json.obj("ref", v.ref, "name", key, "import", v.imp, "x", v.x, "y", v.y, "heading", v.h, "uses_toRadians", v.usesToRadians,
                        "file", v.file, "line", v.line, "used_by", new ArrayList<String>()));
            }
        }
        // the alliance each pose belongs to: the auto that starts there sets it, or the name says it
        for (Map<String, Object> p : startPoses.values()) {
            String al = null, why = null;
            for (Object u : Json.list(p.get("used_by"))) {
                Map<String, Object> om = null;
                for (Map<String, Object> o : opmodes) if (u.equals(o.get("class"))) om = o;
                if (om != null && om.get("alliance") != null) { al = (String) Json.map(om.get("alliance")).get("value"); why = "set by " + JavaIndex.simpleName((String) u); }
            }
            String name = String.valueOf(p.get("ref")).toLowerCase(Locale.ROOT);
            if (al == null && name.contains("blue") != name.contains("red")) { al = name.contains("blue") ? "blue" : "red"; why = "from the name"; }
            p.put("alliance", al);
            p.put("alliance_evidence", why);
        }
    }

    // ---------------- loop order ----------------

    /** One statement and where it is written (an auto's own loop, or the BaseOpMode loop it inherits). */
    static final class Stmt {
        final ClassInfo c;
        final MethodInfo m;
        final StatementTree st;

        Stmt(ClassInfo c, MethodInfo m, StatementTree st) { this.c = c; this.m = m; this.st = st; }
    }

    /** The statements a method runs, with `super.loop();` replaced by the project superclass's own method (BaseOpMode.loop). */
    private List<Stmt> flat(ClassInfo c, MethodInfo m, int depth) {
        List<Stmt> out = new ArrayList<>();
        if (m == null || m.body == null) return out;
        for (StatementTree st : m.body.getStatements()) {
            String sup = superCall(st);
            List<MethodInfo> sm = sup == null || depth > 4 ? List.of() : ix.methods(ix.superOf(c), sup);
            if (!sm.isEmpty() && sm.get(0).body != null) out.addAll(flat(sm.get(0).owner, sm.get(0), depth + 1));
            else out.add(new Stmt(c, m, st));
        }
        return out;
    }

    /** "loop" for `super.loop();` (no arguments), else null. */
    private static String superCall(StatementTree st) {
        if (!(st instanceof ExpressionStatementTree) || !(((ExpressionStatementTree) st).getExpression() instanceof MethodInvocationTree)) return null;
        MethodInvocationTree mi = (MethodInvocationTree) ((ExpressionStatementTree) st).getExpression();
        if (!mi.getArguments().isEmpty() || !(mi.getMethodSelect() instanceof MemberSelectTree)) return null;
        MemberSelectTree ms = (MemberSelectTree) mi.getMethodSelect();
        return ms.getExpression().toString().equals("super") ? ms.getIdentifier().toString() : null;
    }

    private void classifyLoop(MethodInfo m, List<Stmt> body, Map<String, Object> om, String robotVar) {
        List<Object> order = new ArrayList<>();
        List<Stmt> logic = new ArrayList<>();
        int i = 0;
        for (Stmt s : body) {
            ClassInfo c = s.c;
            StatementTree st = s.st;
            String kind = kindOf(c, st, robotVar);
            Map<String, Object> e = Json.obj("kind", kind, "text", ix.text(c.src, st), "line", ix.line(c.src, st), "file", c.src.path, "index", i++);
            if (kind.equals("update") || kind.equals("runner")) {
                MethodInvocationTree mi = (MethodInvocationTree) ((ExpressionStatementTree) st).getExpression();
                e.put("receiver", Walk.receiver(mi));
                e.put("method", Walk.methodName(mi));
                if (kind.equals("runner")) e.put("runner", runnerOf(c, mi));
                // runner.update() of the team's own ActionRunner: runs its own Actions, not Road Runner's
                if (kind.equals("runner") && Walk.receiver(mi) != null && teamRunner(c, Walk.receiver(mi)) != null) e.put("team_runner", true);
            }
            order.add(e);
            if (kind.equals("logic")) logic.add(s);
        }
        om.put("loop_order", order);
        om.put("loop_method", m.name);
        if (!logic.isEmpty()) om.put("loop_logic", cloneable(logic, robotVar));
    }

    /** cloneable() over statements written in several classes (an auto + its BaseOpMode), merged in order. */
    @SuppressWarnings("unchecked")
    private Map<String, Object> cloneable(List<Stmt> sts, String robotVar) {
        Map<String, Object> out = null;
        for (int a = 0; a < sts.size(); ) {
            int b = a;
            while (b < sts.size() && sts.get(b).m == sts.get(a).m) b++;
            List<StatementTree> part = new ArrayList<>();
            for (int k = a; k < b; k++) part.add(sts.get(k).st);
            Map<String, Object> r = cloneable(sts.get(a).c, sts.get(a).m, part, robotVar, Set.of());
            if (out == null) out = r;
            else {
                ((List<Object>) out.get("statements")).addAll((List<Object>) r.get("statements"));
                ((List<Object>) out.get("rejected")).addAll((List<Object>) r.get("rejected"));
                ((Map<String, Object>) out.get("fields")).putAll((Map<String, Object>) r.get("fields"));
                for (Object imp : (List<Object>) r.get("imports")) if (!((List<Object>) out.get("imports")).contains(imp)) ((List<Object>) out.get("imports")).add(imp);
            }
            a = b;
        }
        return out;
    }

    private String kindOf(ClassInfo c, StatementTree st, String robotVar) {
        String txt = st.toString();
        if (txt.contains("CommandScheduler") && txt.replaceAll("\\s", "").endsWith(".run();") && st instanceof ExpressionStatementTree) return "runner";
        // the team's own autonomous behavior (paths, scoring): never copied, BEE's path replaces it
        java.util.regex.Matcher calls = java.util.regex.Pattern.compile("\\.(\\w+)\\(").matcher(txt);
        while (calls.find()) {
            String fn = calls.group(1);
            if (fn.equals("followPath") || fn.equals("schedule") || fn.equals("holdPoint") || fn.equals("turnTo") || fn.equals("setPathState") || isScoringName(fn.toLowerCase(Locale.ROOT)))
                return "state_machine";
        }
        if (st instanceof EnhancedForLoopTree && txt.contains("clearBulkCache")) return "bulk_clear";
        if (st instanceof ExpressionStatementTree && ((ExpressionStatementTree) st).getExpression() instanceof MethodInvocationTree) {
            MethodInvocationTree mi = (MethodInvocationTree) ((ExpressionStatementTree) st).getExpression();
            String fn = Walk.methodName(mi);
            String r = Walk.receiver(mi);
            if (fn.equals("clearBulkCache") || fn.matches("(?i)(clear|reset)\\w*(bulk|lynx)\\w*")) return "bulk_clear";
            if (r != null && (r.equals("telemetry") || r.startsWith("telemetry.") || r.contains("Telemetry"))) return "telemetry";
            if ((fn.equals("update") || fn.equals("periodic")) && r != null) return teamRunner(c, r) != null ? "runner" : "update";
            // robot.updatePositionAndShootingDistance(): the robot's own per-loop work, like robot.update()
            if (r != null && r.equals(robotVar) && fn.startsWith("update") && mi.getArguments().isEmpty()) return "update";
            if (fn.equals("run") && r != null && r.contains("CommandScheduler")) return "runner";
            for (ExpressionTree a : mi.getArguments()) {
                String d = JavaIndex.dotted(a);
                FieldInfo f = d == null ? null : c.fields.get(d);
                if (f != null && f.type.contains("Action")) return "runner";
            }
            if (r == null) {
                MethodInfo own = first(c, fn);
                if (own != null && own.body != null) {
                    String b = own.body.toString();
                    if (b.contains("switch") || b.contains("followPath") || b.contains("State")) return "state_machine";
                    return "helper";
                }
            }
        }
        if (st instanceof IfTree && ((IfTree) st).getElseStatement() == null) {
            // if (Config.Telemetry.TELEMETRY_ACTIVE) { telemetry.addData(...); ... } : only telemetry inside
            String then = ((IfTree) st).getThenStatement().toString();
            if (then.contains("telemetry") && then.replaceAll("telemetry\\.[^;]*;", "").replaceAll("[{}\\s]", "").isEmpty()) return "telemetry";
        }
        if (st instanceof VariableTree && ((VariableTree) st).getType().toString().equals("TelemetryPacket")) return "runner_support";
        return "logic";
    }

    /**
     * runner.update() where `runner` is the team's own action runner (an ActionRunner of the project with a method that
     * takes one of its Actions, like startGroup(Action)): that class, else null.
     */
    private ClassInfo teamRunner(ClassInfo c, String recv) {
        if (recv.contains(".")) return null;
        FieldInfo f = ix.field(c, recv);
        ClassInfo t = f == null ? null : ix.resolveType(f.type, c);
        if (t == null || teamAction == null) return null;
        for (MethodInfo mm : t.methods)
            if (mm.isPublic && mm.params.size() == 1 && ix.resolveType(mm.params.get(0).getType().toString(), t) == teamAction) return t;
        return null;
    }

    private Map<String, Object> runnerOf(ClassInfo c, MethodInvocationTree mi) {
        String fn = JavaIndex.dotted(mi.getMethodSelect());
        Map<String, Object> r = Json.obj("call", ix.text(c.src, mi), "function", fn);
        String recv = Walk.receiver(mi);
        if (recv != null) {
            ClassInfo owner = ix.resolveType(recv, c);
            if (owner != null) { r.put("class", owner.fqn); r.put("import", owner.importName()); r.put("ref", owner.ref()); }
        }
        List<String> args = new ArrayList<>();
        for (ExpressionTree a : mi.getArguments()) args.add(a.toString());
        r.put("args", args);
        return r;
    }

    /**
     * Statements the generated OpMode can reuse as they are: every name they use is the robot, a static reference
     * (Config..., Utilities...), an OpMode member (telemetry, hardwareMap), a local they declare, or a field of the
     * OpMode that we copy along (with its initializer). Statements that call the team's state machine are not reused.
     */
    private Map<String, Object> cloneable(ClassInfo c, MethodInfo m, List<? extends StatementTree> sts, String robotVar, Set<String> extraOk) {
        List<Object> ok = new ArrayList<>();
        List<Object> rejected = new ArrayList<>();
        Map<String, Object> fields = new LinkedHashMap<>();
        Set<String> imports = new LinkedHashSet<>();
        Set<String> locals = new LinkedHashSet<>();
        for (StatementTree st : sts) {
            String kind = kindOf(c, st, robotVar);
            if (!kind.equals("logic")) continue;
            Set<String> need = new LinkedHashSet<>();
            Set<String> declared = new LinkedHashSet<>(locals);
            String why = null;
            TreePath sp = new TreePath(new TreePath(new TreePath(c.src.cu), m.tree), st);
            for (Hit h : Walk.find(c, m, sp, t -> t instanceof VariableTree || t instanceof LambdaExpressionTree)) {
                if (h.leaf() instanceof VariableTree) declared.add(((VariableTree) h.leaf()).getName().toString());
                else for (VariableTree p : ((LambdaExpressionTree) h.leaf()).getParameters()) declared.add(p.getName().toString());
            }
            for (Hit h : Walk.find(c, m, sp, t -> t instanceof IdentifierTree || t instanceof MethodInvocationTree
                    || t instanceof MemberSelectTree && ((MemberSelectTree) t).getExpression().toString().equals("this"))) {
                if (h.leaf() instanceof MethodInvocationTree) {
                    MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
                    // this.addMonitors() / super.start(): methods of the OpMode, same as addMonitors()
                    boolean own = mi.getMethodSelect() instanceof MemberSelectTree
                            && Set.of("this", "super").contains(((MemberSelectTree) mi.getMethodSelect()).getExpression().toString());
                    if (mi.getMethodSelect() instanceof IdentifierTree || own) {
                        String fn = Walk.methodName(mi);
                        if (first(c, fn) != null) why = "calls " + c.simple + "." + fn + "()";
                        else if (!fn.equals("sleep") && !fn.equals("idle") && !fn.equals("opModeIsActive") && !fn.equals("isStopRequested") && !fn.equals("getRuntime")) why = "calls " + fn + "()";
                    }
                    continue;
                }
                // this.runner is the field runner
                String n = h.leaf() instanceof MemberSelectTree ? ((MemberSelectTree) h.leaf()).getIdentifier().toString() : ((IdentifierTree) h.leaf()).getName().toString();
                Tree parent = h.parent();
                if (parent instanceof MethodInvocationTree && ((MethodInvocationTree) parent).getMethodSelect() == h.leaf()) continue;
                if (declared.contains(n) || extraOk.contains(n) || n.equals(robotVar) || n.equals("this")) continue;
                if (Set.of("telemetry", "hardwareMap", "gamepad1", "gamepad2", "Math", "String", "Double", "Integer", "Boolean", "List", "ArrayList", "System").contains(n)) continue;
                FieldInfo f = ix.field(c, n);
                if (f != null && !f.isStatic) {
                    if (ix.resolveType(f.type, c) == (subs.wrapper == null ? null : subs.wrapper.cls)) continue;
                    String t = JavaIndex.simpleName(f.type);
                    if (t.contains("State") || t.contains("Timer") || t.contains("Path") || t.contains("Action") || t.contains("Follower")) { why = "uses the auto's own '" + n + "' (" + t + ")"; continue; }
                    need.add(n);
                    continue;
                }
                if (Character.isUpperCase(n.charAt(0))) {
                    ClassInfo tc = ix.resolveType(n, c);
                    if (tc != null) imports.add(tc.importName());
                    else {
                        String fq = JavaIndex.importedFqn(n, c);
                        if (!fq.isEmpty()) imports.add(fq);
                    }
                    continue;
                }
                if (f != null) continue; // static field of the OpMode class
                why = "uses '" + n + "' (not available outside " + c.simple + ")";
            }
            if (st instanceof VariableTree) locals.add(((VariableTree) st).getName().toString());
            if (why != null) {
                rejected.add(Json.obj("text", ix.text(c.src, st), "line", ix.line(c.src, st), "file", c.src.path, "reason", why));
                continue;
            }
            for (String n : need) {
                FieldInfo f = c.fields.get(n);
                if (f == null) continue;
                fields.put(n, Json.obj("type", f.type, "init", f.init == null ? null : ix.text(c.src, f.init), "line", f.line,
                        "decl", f.type + " " + n + (f.init == null ? "" : " = " + ix.text(c.src, f.init)) + ";"));
                if (f.init != null) {
                    // only names that start an expression (Config in Config.Flywheel.X), not members after a dot
                    java.util.regex.Matcher tm = java.util.regex.Pattern.compile("(?<![\\w.])([A-Z]\\w*)").matcher(f.init.toString());
                    while (tm.find()) {
                        String tok = tm.group(1);
                        ClassInfo tc = ix.resolveType(tok, c);
                        if (tc != null) imports.add(tc.importName());
                    }
                }
                String ft = JavaIndex.simpleName(f.type);
                ClassInfo tc = ix.resolveType(ft, c);
                if (tc != null) imports.add(tc.importName());
                else if (!JavaIndex.importedFqn(ft, c).isEmpty()) imports.add(JavaIndex.importedFqn(ft, c));
            }
            ok.add(Json.obj("text", ix.text(c.src, st), "line", ix.line(c.src, st), "file", c.src.path, "fields", new ArrayList<>(need)));
        }
        return Json.obj("method", m.name, "class", c.fqn, "file", c.src.path, "statements", ok, "rejected", rejected, "fields", fields, "imports", new ArrayList<>(imports));
    }

    // ---------------- scoring ----------------

    private void recordScoring(ClassInfo c, Hit h, MethodInvocationTree call, MethodInvocationTree outer, Map<String, Object> om, String robotVar) {
        if (om.get("scoring_call") != null) return;
        String r = Walk.receiver(call);
        String text = ix.text(c.src, call);
        Map<String, Object> sc = Json.obj("call", robotVar != null && text.startsWith(robotVar + ".") ? "{robot}" + text.substring(robotVar.length()) : text,
                "method", Walk.methodName(call), "receiver", r, "through", outer == null ? null : Walk.methodName(outer), "file", c.src.path, "line", h.line(ix),
                "opmode", c.fqn);
        // the guard around it: if (robot.turret.isLocked() && shootIterations == 0) { ... }
        for (TreePath p = h.path.getParentPath(); p != null; p = p.getParentPath()) {
            if (p.getLeaf() instanceof IfTree) {
                ExpressionTree cond = ((IfTree) p.getLeaf()).getCondition();
                List<String> keep = new ArrayList<>();
                for (String part : splitAnd(cond)) {
                    String t = part.trim();
                    // a mechanism condition (turret aimed...), not the path being done: BEE sequences the paths itself
                    String fol = subs.wrapper == null ? null : subs.wrapper.followerField;
                    boolean pathCond = fol != null && t.contains(robotVar + "." + fol + ".") || t.contains("follower");
                    if (robotVar != null && !pathCond && t.matches("!?\\(?" + robotVar + "\\.[\\w.]+\\(\\)\\)?")) keep.add(t.replace(robotVar + ".", "{robot}."));
                }
                if (!keep.isEmpty()) {
                    sc.put("guard", keep);
                    sc.put("guard_text", ix.text(c.src, cond));
                    sc.put("guard_line", ix.line(c.src, cond));
                }
                break;
            }
            if (p.getLeaf() instanceof CaseTree || p.getLeaf() instanceof com.sun.source.tree.MethodTree) break;
        }
        // the timeout the team waits for afterwards: pathTimer.getElapsedTimeSeconds() > Config.Turret.LOCK_TIMEOUT
        for (Hit t : Walk.find(c, x -> x.getKind() == Tree.Kind.GREATER_THAN && x.toString().contains("Elapsed") || x.getKind() == Tree.Kind.GREATER_THAN && x.toString().contains("seconds()"))) {
            com.sun.source.tree.BinaryTree b = (com.sun.source.tree.BinaryTree) t.leaf();
            Val v = ev.eval(b.getRightOperand(), c);
            if (v != null && v.isNum()) {
                sc.put("wait_timeout", Json.obj("ref", v.ref, "value", v.num, "import", v.imp, "text", ix.text(c.src, b), "line", t.line(ix)));
                break;
            }
        }
        // what it really does
        if (r != null && robotVar != null && r.equals(robotVar) && subs.wrapper != null) {
            Api a = apiOf(subs.wrapper.cls, Walk.methodName(call), call.getArguments().size());
            if (a != null) {
                sc.put("defined_in", Json.obj("class", subs.wrapper.cls.fqn, "file", subs.wrapper.cls.src.path, "line", a.mi.line, "returns", a.mi.returnType, "kind", a.kind));
                List<Object> seq = flattenMethod(subs.wrapper.cls, a.mi, 0);
                sc.put("sequence", seq);
            }
        } else if (r != null && robotVar != null && r.startsWith(robotVar + ".")) {
            Sub s = subOf(r.substring(robotVar.length() + 1));
            if (s != null) {
                Api a = apiOf(s.cls, Walk.methodName(call), call.getArguments().size());
                if (a != null) sc.put("sequence", flattenMethod(s.cls, a.mi, 0));
            }
        } else if (r == null) {
            MethodInfo own = first(c, Walk.methodName(call));
            if (own != null) sc.put("sequence", flattenMethod(c, own, 0));
        }
        om.put("scoring_call", sc);
    }

    private static List<String> splitAnd(ExpressionTree e) {
        List<String> out = new ArrayList<>();
        if (e.getKind() == Tree.Kind.PARENTHESIZED) return splitAnd(((com.sun.source.tree.ParenthesizedTree) e).getExpression());
        if (e.getKind() == Tree.Kind.CONDITIONAL_AND) {
            out.addAll(splitAnd(((com.sun.source.tree.BinaryTree) e).getLeftOperand()));
            out.addAll(splitAnd(((com.sun.source.tree.BinaryTree) e).getRightOperand()));
        } else out.add(e.toString());
        return out;
    }

    private Sub subOf(String path) {
        if (subs.wrapper == null) return null;
        ClassInfo c = subs.wrapper.subsystems.get(path.split("\\.")[0]);
        return c == null ? null : subs.subs.get(c);
    }

    private Api apiOf(ClassInfo c, String name, int n) {
        Sub s = subs.subs.get(c);
        return s == null ? null : s.method(name, n);
    }

    /** The steps a scoring method really performs, in order (Action / Command trees, or a blocking method's statements). */
    List<Object> flattenMethod(ClassInfo c, MethodInfo m, int depth) {
        List<Object> out = new ArrayList<>();
        if (m.body == null || depth > 5) return out;
        List<? extends StatementTree> sts = m.body.getStatements();
        if (sts.size() == 1 && sts.get(0) instanceof ReturnTree) {
            flatten(c, ((ReturnTree) sts.get(0)).getExpression(), out, depth);
            return out;
        }
        // a sync / blocking method: its statements in order
        for (StatementTree st : sts) {
            if (st instanceof ExpressionStatementTree) flatten(c, ((ExpressionStatementTree) st).getExpression(), out, depth);
            else if (st instanceof ReturnTree && ((ReturnTree) st).getExpression() != null) flatten(c, ((ReturnTree) st).getExpression(), out, depth);
            else out.add(Json.obj("op", "opaque", "text", ix.text(c.src, st), "line", ix.line(c.src, st)));
        }
        return out;
    }

    private void flatten(ClassInfo c, ExpressionTree e, List<Object> out, int depth) {
        if (e instanceof NewClassTree) {
            NewClassTree n = (NewClassTree) e;
            String t = JavaIndex.simpleName(n.getIdentifier().toString().replaceAll("<.*>", ""));
            if (SEQ.contains(t)) {
                for (ExpressionTree a : n.getArguments()) flatten(c, a, out, depth);
                return;
            }
            if (PAR.contains(t)) {
                List<Object> par = new ArrayList<>();
                for (ExpressionTree a : n.getArguments()) {
                    List<Object> branch = new ArrayList<>();
                    flatten(c, a, branch, depth);
                    par.add(branch);
                }
                out.add(Json.obj("op", "parallel", "branches", par, "kind", t, "line", ix.line(c.src, e)));
                return;
            }
            if (SLEEP.containsKey(t) && n.getArguments().size() == 1) {
                Val v = ev.eval(n.getArguments().get(0), c);
                double scale = SLEEP.get(t);
                out.add(Json.obj("op", "sleep", "seconds", v == null || !v.isNum() ? null : v.num * scale, "ref", v == null ? null : v.ref, "import", v == null ? null : v.imp,
                        "scale", scale, "text", ix.text(c.src, e), "line", ix.line(c.src, e)));
                return;
            }
            out.add(Json.obj("op", "opaque", "text", ix.text(c.src, e), "line", ix.line(c.src, e)));
            return;
        }
        if (e instanceof MethodInvocationTree) {
            MethodInvocationTree mi = (MethodInvocationTree) e;
            String fn = Walk.methodName(mi);
            String r = Walk.receiver(mi);
            if (fn.equals("sleep") && r == null || "Thread".equals(r) && fn.equals("sleep")) {
                Val v = mi.getArguments().isEmpty() ? null : ev.eval(mi.getArguments().get(0), c);
                out.add(Json.obj("op", "sleep", "seconds", v == null || !v.isNum() ? null : v.num / 1000.0, "ref", v == null ? null : v.ref, "import", v == null ? null : v.imp,
                        "scale", 0.001, "text", ix.text(c.src, e), "line", ix.line(c.src, e)));
                return;
            }
            if (r == null) {
                // own method returning an Action / Command: inline it
                for (MethodInfo own : c.methods(fn)) if (own.params.size() == mi.getArguments().size()) { out.addAll(flattenMethod(c, own, depth + 1)); return; }
            }
            Map<String, Object> step = Json.obj("op", "call", "target", r, "method", fn, "text", ix.text(c.src, e), "line", ix.line(c.src, e), "class", c.fqn);
            List<Object> args = new ArrayList<>();
            for (ExpressionTree a : mi.getArguments()) {
                Val v = ev.eval(a, c);
                args.add(Json.obj("text", a.toString(), "value", v == null ? null : v.json()));
            }
            step.put("args", args);
            // which subsystem, and what that method does (gates!)
            Sub s = null;
            if (r != null) {
                FieldInfo f = ix.field(c, r.split("\\.")[0]);
                ClassInfo t = f == null ? null : ix.resolveType(f.type, c);
                s = t == null ? null : subs.subs.get(t);
                if (s == null && subs.subs.containsKey(c)) {
                    // a device of this class itself (plain teams: gate.setPosition(OPEN))
                    Hardware.Device d = null;
                    for (Hardware.Device x : subs.subs.get(c).devices) if (x.field.equals(r)) d = x;
                    if (d != null) deviceStep(step, d, fn, mi, c);
                }
                if (s == null && f != null && Hardware.KINDS.containsKey(JavaIndex.simpleName(f.type))) {
                    for (Hardware.Device x : hwAll()) if ((x.declaredIn == c || x.owner == c) && r.equals(x.field)) deviceStep(step, x, fn, mi, c);
                }
            }
            if (s != null) {
                step.put("subsystem", s.cls.fqn);
                step.put("role", s.role);
                Api a = s.method(fn, mi.getArguments().size());
                if (a != null) {
                    step.put("kind", a.kind);
                    step.put("returns", a.mi.returnType);
                    Integer label = null;
                    if (a.switchParam != null) {
                        int pi = a.mi.paramIndex(a.switchParam);
                        Val v = pi >= 0 && pi < mi.getArguments().size() ? ev.eval(mi.getArguments().get(pi), c) : null;
                        if (v != null && v.isNum()) label = (int) v.num;
                    }
                    List<String> states = new ArrayList<>();
                    for (Effect ef : a.effects) {
                        if (ef.device == null || !ef.op.equals("setPosition")) continue;
                        if (a.switchParam != null && (label == null || !label.equals(ef.caseLabel))) continue;
                        gate(step, s, ef, label);
                        if (step.get("gate") != null) states.add((String) Json.map(step.get("gate")).get("state"));
                    }
                    // push then retract in one method (a kicker): one piece per call
                    if (states.contains("open") && states.contains("closed")) {
                        Map<String, Object> g = new LinkedHashMap<>(Json.map(step.get("gate")));
                        g.put("state", "pulse");
                        step.put("gate", g);
                    }
                }
            }
            out.add(step);
            return;
        }
        if (e instanceof LambdaExpressionTree) {
            out.add(Json.obj("op", "inline", "text", ix.text(c.src, e), "line", ix.line(c.src, e)));
            return;
        }
        out.add(Json.obj("op", "opaque", "text", ix.text(c.src, e), "line", ix.line(c.src, e)));
    }

    private List<Hardware.Device> hwAll() { return subs.hardware().devices; }

    private List<Hardware.Device> hwDevices() {
        List<Hardware.Device> all = new ArrayList<>();
        for (Sub s : subs.subs.values()) all.addAll(s.devices);
        return all;
    }

    private void deviceStep(Map<String, Object> step, Hardware.Device d, String fn, MethodInvocationTree mi, ClassInfo c) {
        step.put("device", d.name);
        if (!fn.equals("setPosition") || mi.getArguments().isEmpty()) return;
        Val v = ev.eval(mi.getArguments().get(0), c);
        if (v == null) return;
        String named = v.ref != null ? v.ref : v.privateRef;
        List<String> tg = named == null ? List.of() : Subsystems.tags(JavaIndex.simpleName(named), d.field);
        String state = tg.contains("open") ? "open" : tg.contains("closed") ? "closed" : tg.contains("idle") ? "closed" : tg.contains("push") ? "open" : null;
        if (state != null) step.put("gate", Json.obj("device", d.name, "state", state, "position_ref", v.ref, "position_name", named, "position", v.isNum() ? v.num : null));
    }

    private void gate(Map<String, Object> step, Sub s, Effect ef, Integer label) {
        String state = null;
        Map<String, Object> pos = null;
        for (Map<String, Object> sv : s.servoStates) {
            if (!ef.device.name.equals(sv.get("device"))) continue;
            for (String k : new String[]{"open", "closed", "push", "idle"}) {
                @SuppressWarnings("unchecked") Map<String, Object> p = (Map<String, Object>) sv.get(k);
                String named = ef.value == null ? null : ef.value.ref != null ? ef.value.ref : ef.value.privateRef;
                if (p != null && named != null && (named.equals(p.get("ref")) || named.equals(p.get("private_ref")))) { state = k.equals("push") ? "open" : k.equals("idle") ? "closed" : k; pos = p; }
            }
        }
        String efName = ef.value == null ? null : ef.value.ref != null ? ef.value.ref : ef.value.privateRef;
        if (state == null && efName != null) {
            List<String> tg = Subsystems.tags(JavaIndex.simpleName(efName), ef.device.field);
            state = tg.contains("open") ? "open" : tg.contains("closed") ? "closed" : null;
        }
        if (state == null) return;
        step.put("gate", Json.obj("index", label, "device", ef.device.name, "field", ef.device.field, "state", state,
                "position_ref", ef.value == null ? null : ef.value.ref, "position", ef.value != null && ef.value.isNum() ? ef.value.num : null,
                "evidence", s.cls.simple + "." + ef.text.trim() + " (" + s.cls.src.path + ":" + ef.line + ")"));
    }

    // ---------------- the team's own Action framework ----------------

    /** A project class Action with update(now) and inTerminalState() (a home-made framework, run by its own ActionRunner). */
    private void findTeamAction() {
        for (ClassInfo c : ix.classes()) {
            if (!c.simple.equals("Action")) continue;
            MethodInfo up = null, done = null, reset = null;
            for (MethodInfo mm : c.methods) {
                if (!mm.isPublic || mm.isStatic || mm.isCtor) continue;
                String rt = JavaIndex.simpleName(String.valueOf(mm.returnType));
                if (mm.name.equals("update") && mm.params.size() <= 1
                        && (mm.params.isEmpty() || mm.params.get(0).getType().toString().equals("long"))) up = mm;
                if (mm.params.isEmpty() && rt.equals("boolean") && Set.of("inTerminalState", "isDone", "isFinished", "isComplete", "isTerminal", "done").contains(mm.name)) done = mm;
                if (mm.params.isEmpty() && mm.name.equals("reset")) reset = mm;
            }
            if (up == null || done == null) continue;
            teamAction = c;
            String arg = up.params.isEmpty() ? "" : up.params.get(0).getName().toString().toLowerCase(Locale.ROOT).contains("nano") ? "System.nanoTime()" : "System.currentTimeMillis()";
            teamActions = Json.obj("class", c.fqn, "ref", c.ref(), "import", c.importName(), "file", c.src.path, "line", c.line,
                    "update", "update(" + arg + ")", "done", done.name + "()", "reset", reset == null ? null : "reset()",
                    "evidence", c.simple + "." + up.signature() + " / " + done.name + "() (" + c.src.path + ":" + up.line + ")");
            return;
        }
    }

    /**
     * No auto calls robot.shoot...() itself: follow the static helpers the autos call (AutonomyActions.autonomousRoutine(robot)
     * -> farSideScript(r) -> ShootingActions.shootPreloaded(r, true)) to a scoring method that takes the Robot. An overload
     * that takes only the Robot is preferred (it shoots what is loaded); the call is rebuilt with {robot}.
     */
    private Map<String, Object> scoringViaHelpers(List<ClassInfo> autos, ClassInfo ref) {
        if (subs.wrapper == null) return null;
        List<Object[]> found = new ArrayList<>();  // {MethodInfo scoring, MethodInfo calledFrom, int line}
        for (Map.Entry<MethodInfo, Object[]> e : reachable(autos, ref).entrySet()) {
            MethodInfo cand = e.getKey();
            if (cand.isStatic && isScoringName(cand.name.toLowerCase(Locale.ROOT)) && robotParam(cand) >= 0 && e.getValue() != null) found.add(new Object[]{cand, e.getValue()[0], e.getValue()[1]});
        }
        if (found.isEmpty()) return null;
        // the simplest overload of a found method: only the Robot (shootPreloaded(Robot r) next to shootPreloaded(r, true))
        MethodInfo best = null;
        Object[] via = null;
        for (Object[] f : found) {
            MethodInfo mm = (MethodInfo) f[0];
            for (MethodInfo o : mm.owner.methods(mm.name))
                if (o.isStatic && o.isPublic && o.params.size() == 1 && robotParam(o) == 0 && (best == null || best.params.size() > 1)) { best = o; via = f; }
        }
        if (best == null) { via = found.get(0); best = (MethodInfo) via[0]; }
        if (best.params.size() != 1) return null;  // other arguments BEE cannot choose (gate order, colors...)
        String rt = JavaIndex.simpleName(String.valueOf(best.returnType));
        ClassInfo rc = ix.resolveType(rt, best.owner);
        String kind = teamAction != null && rc != null && isTeamActionType(rc) ? "team_action"
                : rt.equals("Action") ? "action" : rt.contains("Command") ? "command" : rt.equals("void") ? "sync" : null;
        if (kind == null) return null;
        MethodInfo from = (MethodInfo) via[1];
        return Json.obj("call", best.owner.ref() + "." + best.name + "({robot})", "method", best.name, "import", best.owner.importName(),
                "file", best.owner.src.path, "line", best.line, "opmode", null, "confidence", Fact.MEDIUM,
                "evidence", "your autos reach it through " + from.owner.simple + "." + from.name + "() (" + from.owner.src.path + ":" + via[2] + ")",
                "defined_in", Json.obj("class", best.owner.fqn, "file", best.owner.src.path, "line", best.line, "returns", best.returnType, "kind", kind),
                "sequence", new ArrayList<>());
    }

    private boolean isTeamActionType(ClassInfo c) {
        for (int g = 0; c != null && g < 8; g++, c = ix.superOf(c)) if (c == teamAction) return true;
        return false;
    }

    private int robotParam(MethodInfo mm) {
        for (int i = 0; i < mm.params.size(); i++) if (ix.resolveType(mm.params.get(i).getType().toString(), mm.owner) == subs.wrapper.cls) return i;
        return -1;
    }

    /**
     * Every project method the autos reach (Auto2.start() -> AutonomyActions.autonomousRoutine(robot) -> farSideScript(r)...),
     * in breadth-first order from the reference auto: method -> {the method that calls it, the line} (null for the autos' own).
     */
    private Map<MethodInfo, Object[]> reachable(List<ClassInfo> autos, ClassInfo ref) {
        if (reach != null) return reach;
        reach = new LinkedHashMap<>();
        List<ClassInfo> order = new ArrayList<>(autos);
        if (ref != null) { order.remove(ref); order.add(0, ref); }
        java.util.ArrayDeque<MethodInfo> queue = new java.util.ArrayDeque<>();
        for (ClassInfo c : order) for (MethodInfo mm : c.methods) if (!reach.containsKey(mm)) { reach.put(mm, null); queue.add(mm); }
        while (!queue.isEmpty() && reach.size() < 800) {
            MethodInfo from = queue.poll();
            ClassInfo fc = from.owner;
            if (from.body == null) continue;
            for (Hit h : Walk.find(fc, from, t -> t instanceof MethodInvocationTree)) {
                MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
                String recv = Walk.receiver(mi);
                ClassInfo target = recv == null ? fc : Character.isUpperCase(recv.charAt(0)) && !recv.contains(".") ? ix.resolveType(recv, fc) : null;
                if (target == null) continue;
                for (MethodInfo cand : target.methods(Walk.methodName(mi))) {
                    if (cand.params.size() != mi.getArguments().size() || reach.containsKey(cand)) continue;
                    reach.put(cand, new Object[]{from, h.line(ix)});
                    queue.add(cand);
                }
            }
        }
        return reach;
    }

    private Map<MethodInfo, Object[]> reach;

    /**
     * No auto turns the intake on / off itself: the helpers they reach do (IntakeActions.startIntake(r) ->
     * r.intake.turnOnSync(false)), rebuilt with {robot}; else the intake's own no-argument on / off methods.
     */
    private void intakeFromApi() {
        if (subs.wrapper == null) return;
        Set<String> intakeFields = new LinkedHashSet<>();
        for (Map.Entry<String, ClassInfo> e : subs.wrapper.subsystems.entrySet()) {
            Sub s = subs.subs.get(e.getValue());
            if (s != null && "intake".equals(s.role)) intakeFields.add(e.getKey());
        }
        if (reach != null) for (MethodInfo mm : reach.keySet()) {
            int rp = robotParam(mm);
            if (rp < 0 || mm.body == null) continue;
            String rv = mm.params.get(rp).getName().toString();
            for (Hit h : Walk.find(mm.owner, mm, t -> t instanceof MethodInvocationTree)) {
                MethodInvocationTree mi = (MethodInvocationTree) h.leaf();
                String recv = Walk.receiver(mi);
                if (recv == null || !recv.startsWith(rv + ".") || !intakeFields.contains(recv.substring(rv.length() + 1))) continue;
                String fn = Walk.methodName(mi), n = fn.toLowerCase(Locale.ROOT);
                Val v = mi.getArguments().isEmpty() ? null : ev.eval(mi.getArguments().get(0), mm.owner);
                String key = n.startsWith("turnoff") || n.equals("off") || n.equals("stop") || (n.equals("setpower") && v != null && v.isNum() && v.num == 0) ? "off"
                        : n.startsWith("turnon") || n.equals("on") || n.equals("start") || (n.equals("setpower") && v != null && v.isNum() && v.num > 0) ? "on" : null;
                if (key == null || mi.getArguments().size() > 1) continue;
                String arg = "";
                if (!mi.getArguments().isEmpty()) {
                    if (v == null) continue;
                    arg = v.ref != null ? v.ref : v.isNum() ? String.valueOf(v.num) : v.kind == Val.K.BOOL ? mi.getArguments().get(0).toString() : null;
                    if (arg == null) continue;
                }
                if (intake == null) intake = new LinkedHashMap<>();
                if (!intake.containsKey(key))
                    intake.put(key, Json.obj("call", "{robot}." + recv.substring(rv.length() + 1) + "." + fn + "(" + arg + ")", "file", mm.owner.src.path, "line", h.line(ix), "confidence", Fact.MEDIUM,
                            "import", v == null ? null : v.imp, "evidence", "as in " + mm.owner.simple + "." + mm.name + "()"));
            }
        }
        for (Map.Entry<String, ClassInfo> e : subs.wrapper.subsystems.entrySet()) {
            Sub s = subs.subs.get(e.getValue());
            if (s == null || !"intake".equals(s.role)) continue;
            for (Api a : s.api) {
                MethodInfo mm = a.mi;
                if (!mm.isPublic || !mm.params.isEmpty() || !"void".equals(String.valueOf(mm.returnType))) continue;
                String n = mm.name.toLowerCase(Locale.ROOT);
                String key = n.startsWith("turnon") || n.equals("on") || n.equals("start") ? "on" : n.startsWith("turnoff") || n.equals("off") || n.equals("stop") ? "off" : null;
                if (key == null) continue;
                if (intake == null) intake = new LinkedHashMap<>();
                if (!intake.containsKey(key))
                    intake.put(key, Json.obj("call", "{robot}." + e.getKey() + "." + mm.name + "()", "file", s.cls.src.path, "line", mm.line, "confidence", Fact.MEDIUM,
                            "evidence", s.cls.simple + "." + mm.name + "() (no auto calls the intake directly)"));
            }
        }
    }

    // ---------------- scoring summary, paradigm ----------------

    @SuppressWarnings("unchecked")
    private void scoringAndParadigm(List<ClassInfo> autos, ClassInfo ref) {
        Map<String, Object> sc = null;
        if (ref != null) sc = (Map<String, Object>) find(ref).get("scoring_call");
        if (sc == null) for (ClassInfo c : autos) if (find(c).get("scoring_call") != null) { sc = (Map<String, Object>) find(c).get("scoring_call"); break; }
        // the autos score through static helpers: AutonomyActions.autonomousRoutine(robot) -> ShootingActions.shootPreloaded(r)
        if (sc == null) sc = scoringViaHelpers(autos, ref);
        if (intake == null || intake.get("on") == null || intake.get("off") == null) intakeFromApi();
        // no auto scores: a scoring method of the wrapper is still the team's own sequence
        if (sc == null && subs.wrapper != null) {
            Sub ws = subs.subs.get(subs.wrapper.cls);
            for (Api a : ws.api) {
                if (!a.mi.isPublic || !isScoringName(a.mi.name.toLowerCase(Locale.ROOT)) || !a.mi.params.isEmpty()) continue;
                sc = Json.obj("call", "{robot}." + a.mi.name + "()", "method", a.mi.name, "file", ws.cls.src.path, "line", a.mi.line, "confidence", Fact.MEDIUM,
                        "evidence", "public method of " + ws.cls.simple + " (no autonomous uses it)", "sequence", flattenMethod(ws.cls, a.mi, 0),
                        "defined_in", Json.obj("class", ws.cls.fqn, "returns", a.mi.returnType, "kind", a.kind));
                break;
            }
        }
        if (sc != null) {
            List<Object> seq = (List<Object>) sc.get("sequence");
            List<Object> gates = new ArrayList<>();
            List<String> devices = new ArrayList<>();
            collectGates(seq, gates, devices);
            // one piece leaves per opening (a gate) or per push (a kicker that fires several times)
            int opened = 0;
            List<String> openedDevs = new ArrayList<>();
            for (Object g : gates) {
                Map<String, Object> gm = (Map<String, Object>) g;
                if ("open".equals(gm.get("state")) || "pulse".equals(gm.get("state"))) { opened++; openedDevs.add((String) gm.get("device")); }
            }
            Map<String, Object> s = new LinkedHashMap<>(sc);
            s.put("gate_events", gates);
            s.put("gate_order", new ArrayList<>(openedDevs));
            s.put("capacity", opened > 0 ? Fact.of(opened, (String) sc.get("file"), (int) sc.get("line"), Fact.MEDIUM,
                    opened + " pieces leave in " + sc.get("method") + "() (gate openings, in order: " + openedDevs + ")") : null);
            if (!sc.containsKey("confidence")) s.put("confidence", Fact.HIGH);
            scoring = s;
        }
        // paradigm: how the team runs mechanism sequences
        boolean actions = false, commands = false, nextftc = false;
        String runnerCall = null;
        for (Map<String, Object> om : opmodes) {
            List<Object> order = (List<Object>) om.get("loop_order");
            if (order != null) for (Object o : order) {
                Map<String, Object> e = (Map<String, Object>) o;
                if ("runner".equals(e.get("kind")) && !Boolean.TRUE.equals(e.get("team_runner"))) {
                    String t = (String) e.get("text");
                    if (t.contains("CommandScheduler")) commands = true;
                    else { actions = true; if (runner == null) runner = (Map<String, Object>) e.get("runner"); }
                }
            }
        }
        for (ClassInfo c : ix.classes()) {
            for (String imp : c.src.imports) {
                if (imp.startsWith("com.acmerobotics.roadrunner.") && (imp.endsWith(".Action") || imp.endsWith("SequentialAction"))) actions |= subs.subs.containsKey(c);
                if (imp.startsWith("com.arcrobotics.ftclib.command") || imp.startsWith("com.seattlesolvers.solverslib.command")) commands = true;
                if (imp.startsWith("dev.nextftc.")) nextftc = true;
            }
        }
        String p = nextftc ? "nextftc" : commands && !actions ? "ftclib_commands" : actions && !commands ? "rr_actions" : actions ? "mixed" : "plain";
        paradigm = Fact.of(p, ref == null ? null : ref.src.path, ref == null ? 0 : ref.line, p.equals("mixed") ? Fact.LOW : Fact.HIGH,
                "actions=" + actions + ", commands=" + commands + ", nextftc=" + nextftc + (runner != null ? ", runner " + runner.get("function") : "")
                        + (teamAction != null ? ", own " + teamAction.simple + " class (" + teamAction.src.path + ")" : ""));
    }

    @SuppressWarnings("unchecked")
    private static void collectGates(List<Object> seq, List<Object> gates, List<String> devs) {
        if (seq == null) return;
        for (Object o : seq) {
            Map<String, Object> st = (Map<String, Object>) o;
            if ("parallel".equals(st.get("op"))) {
                for (Object b : (List<Object>) st.get("branches")) collectGates((List<Object>) b, gates, devs);
            } else if (st.get("gate") != null) {
                gates.add(st.get("gate"));
            }
        }
    }

    // ---------------- coordinates ----------------

    private void coordinateConvention() {
        List<Map<String, Object>> all = new ArrayList<>(startPoses.values());
        all.addAll(pathPoses);
        if (all.isEmpty()) return;
        boolean field = true, rad = false, deg = false;
        String file = null;
        int line = 0;
        for (Map<String, Object> p : all) {
            double x = (double) p.get("x"), y = (double) p.get("y");
            Object hObj = p.containsKey("heading") ? p.get("heading") : p.get("h");
            double h = hObj == null ? 0 : (double) hObj;
            if (x < -1 || x > 145 || y < -1 || y > 145) field = false;
            if (Boolean.TRUE.equals(p.get("uses_toRadians"))) rad = true;
            if (Math.abs(h) > 2 * Math.PI + 0.01) deg = true;
            if (file == null) { file = (String) p.get("file"); line = (int) p.get("line"); }
        }
        boolean nonNeg = true;
        for (Map<String, Object> p : all) if ((double) p.get("x") < 0 || (double) p.get("y") < 0) nonNeg = false;
        String system = field && nonNeg ? "pedro_field" : "relative";
        coordinates = Json.obj("system", Fact.of(system, file, line, field && nonNeg ? Fact.HIGH : Fact.MEDIUM,
                        all.size() + " poses " + (field && nonNeg ? "all inside 0..144 in" : "outside 0..144 in (relative to the start?)")),
                "heading_units", Fact.of(deg ? "degrees" : "radians", file, line, deg ? Fact.LOW : rad ? Fact.HIGH : Fact.MEDIUM,
                        deg ? "a heading larger than 2π: written in degrees (Pedro expects radians)" : rad ? "headings written with Math.toRadians" : "headings within ±2π"));
        if (deg) teamBugs.add(Json.obj("kind", "heading_degrees", "file", file, "line", line, "message",
                "A Pose heading is larger than 2π: it looks like degrees, but Pedro Pose headings are radians. Use Math.toRadians(...)."));
    }

    // ---------------- team bugs (reported, never copied) ----------------

    private void lint(ClassInfo c) {
        // 1. a field the loop / start uses but nothing creates -> NullPointerException
        for (FieldInfo f : c.fields.values()) {
            if (f.isStatic || f.init != null) continue;
            ClassInfo t = ix.resolveType(f.type, c);
            String st = JavaIndex.simpleName(f.type);
            if (t == null && !st.equals("Timer") && !st.equals("ElapsedTime") && !st.equals("Follower")) continue;
            boolean assigned = !Walk.find(c, x -> x instanceof AssignmentTree && f.name.equals(stripThis(JavaIndex.dotted(((AssignmentTree) x).getVariable())))).isEmpty();
            if (assigned) continue;
            List<Hit> uses = Walk.find(c, x -> x instanceof MemberSelectTree && f.name.equals(stripThis(JavaIndex.dotted(((MemberSelectTree) x).getExpression()))));
            if (uses.isEmpty()) continue;
            Hit u = uses.get(0);
            teamBugs.add(Json.obj("kind", "never_created", "class", c.fqn, "file", c.src.path, "line", u.line(ix), "message",
                    c.simple + "." + f.name + " is used (line " + u.line(ix) + ") but never created: init() does not assign it, so the OpMode crashes with a NullPointerException."));
        }
        for (Hit h : Walk.find(c, x -> x instanceof SwitchTree)) {
            List<? extends CaseTree> cases = ((SwitchTree) h.leaf()).getCases();
            // 2. fall-through into the next case
            for (int i = 0; i + 1 < cases.size(); i++) {
                List<? extends StatementTree> sts = cases.get(i).getStatements();
                if (sts == null || sts.isEmpty()) continue;
                StatementTree last = sts.get(sts.size() - 1);
                if (last instanceof BlockTree && !((BlockTree) last).getStatements().isEmpty()) last = ((BlockTree) last).getStatements().get(((BlockTree) last).getStatements().size() - 1);
                Tree.Kind k = last.getKind();
                if (k == Tree.Kind.BREAK || k == Tree.Kind.RETURN || k == Tree.Kind.CONTINUE || k == Tree.Kind.THROW || k == Tree.Kind.YIELD) continue;
                if (cases.get(i + 1).getStatements() == null || cases.get(i + 1).getStatements().isEmpty()) continue;
                teamBugs.add(Json.obj("kind", "switch_fallthrough", "class", c.fqn, "file", c.src.path, "line", ix.line(c.src, cases.get(i)), "message",
                        "case " + cases.get(i).getExpressions() + " has no break: it falls through into case " + cases.get(i + 1).getExpressions() + " in the same loop iteration."));
            }
            for (CaseTree ct : cases) {
                List<? extends StatementTree> sts = ct.getStatements();
                if (sts == null) continue;
                timerResetBeforeCheck(c, h, ct, sts);
                repeatedStart(c, h, ct);
            }
        }
    }

    private static String stripThis(String d) {
        return d == null ? null : d.startsWith("this.") ? d.substring(5) : d;
    }

    /** 3. timer.reset() and later `timer.elapsed() > LIMIT` in the same per-loop branch: the limit is never reached. */
    private void timerResetBeforeCheck(ClassInfo c, Hit sw, CaseTree ct, List<? extends StatementTree> sts) {
        String all = sts.toString();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\w+)\\.(resetTimer|reset)\\(\\)").matcher(all);
        while (m.find()) {
            String timer = m.group(1);
            int resetAt = m.start();
            int checkAt = all.indexOf(timer + ".", m.end());
            while (checkAt >= 0 && !(all.startsWith(timer + ".getElapsedTime", checkAt) || all.startsWith(timer + ".seconds", checkAt) || all.startsWith(timer + ".milliseconds", checkAt) || all.startsWith(timer + ".time", checkAt)))
                checkAt = all.indexOf(timer + ".", checkAt + 1);
            if (checkAt < 0 || resetAt > checkAt) continue;
            // only when the reset is not guarded by a one-time condition: same block level as the check
            int line = ix.line(c.src, ct);
            for (Hit h : Walk.find(c, sw.method, new TreePath(sw.path, ct), t -> t instanceof MethodInvocationTree && t.toString().equals(timer + "." + m.group(2) + "()"))) { line = h.line(ix); break; }
            teamBugs.add(Json.obj("kind", "timer_reset_every_loop", "class", c.fqn, "file", c.src.path, "line", line, "message",
                    timer + " is reset every loop in case " + ct.getExpressions() + " before it is compared with a time limit, so the time limit is never reached."));
            return;
        }
    }

    /** 4. an Action / Command started in a per-loop branch without a once-only guard: it starts again every loop. */
    private void repeatedStart(ClassInfo c, Hit sw, CaseTree ct) {
        for (Hit h : Walk.find(c, sw.method, new TreePath(sw.path, ct), t -> t instanceof MethodInvocationTree
                && (Walk.methodName((MethodInvocationTree) t).equals("add") || Walk.methodName((MethodInvocationTree) t).equals("schedule"))
                && !((MethodInvocationTree) t).getArguments().isEmpty() && ((MethodInvocationTree) t).getArguments().get(0) instanceof MethodInvocationTree)) {
            boolean once = false;
            List<String> conds = new ArrayList<>();
            for (TreePath p = h.path; p != null && !(p.getLeaf() instanceof CaseTree); p = p.getParentPath()) {
                if (!(p.getLeaf() instanceof IfTree)) continue;
                IfTree it = (IfTree) p.getLeaf();
                String cond = it.getCondition().toString();
                conds.add(cond);
                String then = it.getThenStatement().toString();
                // a counter / flag the same branch changes makes it once-only (shootIterations++)
                for (String id : cond.split("[^\\w]+")) if (!id.isEmpty() && !Character.isDigit(id.charAt(0)) && (then.contains(id + "++") || then.contains(id + " = ") || then.contains(id + " += "))) once = true;
            }
            if (once || conds.isEmpty()) continue;
            teamBugs.add(Json.obj("kind", "action_started_every_loop", "class", c.fqn, "file", c.src.path, "line", h.line(ix), "message",
                    "In case " + ct.getExpressions() + " " + ((MethodInvocationTree) h.leaf()).getArguments().get(0) + " is started again on every loop while "
                            + String.join(" and ", conds) + ", so several copies run at once."));
        }
    }
}
