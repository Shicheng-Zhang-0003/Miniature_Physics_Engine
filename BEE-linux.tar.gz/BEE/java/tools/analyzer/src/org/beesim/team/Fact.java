package org.beesim.team;

import java.util.Map;

/** Every fact in the robot model says where it came from and how sure the analysis is. */
public final class Fact {
    public static final String HIGH = "high";
    public static final String MEDIUM = "medium";
    public static final String LOW = "low";

    private Fact() {}

    public static Map<String, Object> of(Object value, String file, int line, String confidence, String evidence) {
        return Json.obj("value", value, "file", file, "line", line, "confidence", confidence, "evidence", evidence);
    }

    public static Map<String, Object> src(String file, int line) {
        return Json.obj("file", file, "line", line);
    }

    public static int rank(String confidence) {
        return HIGH.equals(confidence) ? 2 : MEDIUM.equals(confidence) ? 1 : 0;
    }

    public static String min(String a, String b) {
        return rank(a) <= rank(b) ? a : b;
    }
}
