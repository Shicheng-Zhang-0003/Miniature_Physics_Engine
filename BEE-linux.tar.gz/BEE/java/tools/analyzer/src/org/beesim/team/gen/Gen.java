package org.beesim.team.gen;

import java.util.List;
import java.util.Locale;

/** Small text helpers for writing Java. */
public final class Gen {
    private Gen() {}

    /** A double literal: 12.5, -3.0, 0.0001 (never 1.0E-4 surprises in the code teams read). */
    public static String num(double v) {
        if (Math.abs(v) < 1e-12) return "0.0";
        String s = String.format(Locale.ROOT, "%.6f", v).replaceAll("0+$", "");
        if (s.endsWith(".")) s += "0";
        return s;
    }

    public static String q(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /** Joins expressions as arguments; one per line (indented one level, relative) when long or nested. */
    public static String args(List<String> items, String ind) {
        if (items.isEmpty()) return "";
        int len = 0;
        boolean multi = false;
        for (String i : items) { len += i.length(); multi |= i.contains("\n"); }
        if (len < 70 && !multi) return String.join(", ", items);
        StringBuilder sb = new StringBuilder("\n");
        for (int i = 0; i < items.size(); i++) {
            sb.append("    ").append(items.get(i).replace("\n", "\n    "));
            if (i + 1 < items.size()) sb.append(',');
            sb.append('\n');
        }
        return sb.toString();
    }

    public static String ident(String s) {
        StringBuilder out = new StringBuilder();
        for (char c : s.toCharArray()) if (Character.isLetterOrDigit(c) || c == '_') out.append(c);
        if (out.length() == 0 || Character.isDigit(out.charAt(0))) out.insert(0, "BeeAuto");
        return out.toString();
    }
}
