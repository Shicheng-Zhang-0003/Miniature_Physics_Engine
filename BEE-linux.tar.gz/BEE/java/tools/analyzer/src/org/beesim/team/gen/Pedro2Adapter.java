package org.beesim.team.gen;

import org.beesim.team.Json;
import org.beesim.team.PedroApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Pedro Pathing 2.0.x – 2.1.x (com.pedropathing:ftc + core). Verified API (see resources/pedro-api/2.*.json):
 * geometry.Pose(x, y, heading) with getX/getY/getHeading, follower.pathBuilder().addPath(new BezierLine(a, b))
 * .setLinearHeadingInterpolation(h0, h1).build() -> PathChain, followPath(PathChain, [maxPower,] holdEnd),
 * isBusy(), getPose(), breakFollowing(), holdPoint(Pose), turnTo(radians), update(), setStartingPose(Pose).
 */
public final class Pedro2Adapter extends PedroAdapter {
    static final String F = "com.pedropathing.follower.Follower";
    static final String POSE = "com.pedropathing.geometry.Pose";
    static final String CHAIN = "com.pedropathing.paths.PathChain";
    static final String PB = "com.pedropathing.paths.PathBuilder";
    static final String LINE = "com.pedropathing.geometry.BezierLine";
    static final String CURVE = "com.pedropathing.geometry.Curve";
    static final String FC = "com.pedropathing.follower.FollowerConstants";
    static final String MC = "com.pedropathing.ftc.drivetrains.MecanumConstants";
    static final String PC = "com.pedropathing.paths.PathConstraints";
    static final String PIDF = "com.pedropathing.control.PIDFCoefficients";
    static final String FPIDF = "com.pedropathing.control.FilteredPIDFCoefficients";

    Pedro2Adapter(PedroApi api) { super(api); }

    @Override public String label() { return "Pedro Pathing " + api.version + " (2.x adapter)"; }

    @Override public List<String[]> required() {
        List<String[]> r = new ArrayList<>();
        r.add(new String[]{F, "update"});
        r.add(new String[]{F, "setStartingPose", POSE});
        r.add(new String[]{F, "pathBuilder"});
        r.add(new String[]{F, "followPath", CHAIN, "boolean"});
        r.add(new String[]{F, "followPath", CHAIN, "double", "boolean"});
        r.add(new String[]{F, "isBusy"});
        r.add(new String[]{F, "getPose"});
        r.add(new String[]{F, "breakFollowing"});
        r.add(new String[]{F, "holdPoint", POSE});
        r.add(new String[]{F, "turnTo", "double"});
        r.add(new String[]{POSE, "<init>", "double", "double", "double"});
        r.add(new String[]{POSE, "getX"});
        r.add(new String[]{POSE, "getY"});
        r.add(new String[]{POSE, "getHeading"});
        r.add(new String[]{LINE, "<init>", POSE, POSE});
        r.add(new String[]{LINE, "@extends", CURVE});
        r.add(new String[]{PB, "addPath", CURVE});
        r.add(new String[]{PB, "setLinearHeadingInterpolation", "double", "double"});
        r.add(new String[]{PB, "setConstantHeadingInterpolation", "double"});
        r.add(new String[]{PB, "build"});
        return r;
    }

    @Override public List<String> imports() {
        return List.of(F, POSE, LINE, CHAIN);
    }

    @Override public String poseType() { return "Pose"; }

    @Override public String pathType() { return "PathChain"; }

    @Override public String newPose(String x, String y, String h) { return "new Pose(" + x + ", " + y + ", " + h + ")"; }

    @Override public String x(String p) { return p + ".getX()"; }

    @Override public String y(String p) { return p + ".getY()"; }

    @Override public String heading(String p) { return p + ".getHeading()"; }

    @Override public String line(String f, String a, String b, String mode) {
        String interp = mode.equals("constant") ? ".setConstantHeadingInterpolation(" + heading(b) + ")"
                : ".setLinearHeadingInterpolation(" + heading(a) + ", " + heading(b) + ")";
        return f + ".pathBuilder().addPath(new BezierLine(" + a + ", " + b + "))" + interp + ".build()";
    }

    @Override public List<String> follow(String f, String path, double maxPower, List<String> notes) {
        if (maxPower >= 0.999) return List.of(f + ".followPath(" + path + ", true);");
        return List.of(f + ".followPath(" + path + ", " + Gen.num(maxPower) + ", true);");
    }

    @Override public List<String> followWithPower(String f, String path, String powerVar) {
        return List.of(f + ".followPath(" + path + ", " + powerVar + ", true);");
    }

    @Override public boolean supportsMaxPower() { return true; }

    @Override public String isBusy(String f) { return f + ".isBusy()"; }

    @Override public String pose(String f) { return f + ".getPose()"; }

    @Override public List<String> holdHere(String f) {
        return List.of(f + ".breakFollowing();", f + ".holdPoint(" + f + ".getPose());");
    }

    @Override public List<String> turnTo(String f, String rad) { return List.of(f + ".turnTo(" + rad + ");"); }

    /** 2.x: turnTo() sets isBusy until the heading error is under turnHeadingErrorThreshold (Follower.update). */
    @Override public String turning(String f, String rad) { return f + ".isBusy()"; }

    @Override public String update(String f) { return f + ".update();"; }

    @Override public String setStartingPose(String f, String p) { return f + ".setStartingPose(" + p + ");"; }

    @Override public List<Map<String, Object>> tuningSchema() {
        List<Map<String, Object>> s = new ArrayList<>();
        add(s, FC, "mass", "double", "Robot mass", "kg", "any", "mass_kg", "identity");
        add(s, FC, "forwardZeroPowerAcceleration", "double", "Forward zero-power acceleration", "in/s²", "negative", "naturalForwardDeceleration", "negate");
        add(s, FC, "lateralZeroPowerAcceleration", "double", "Lateral zero-power acceleration", "in/s²", "negative", "naturalStrafeDeceleration", "negate");
        add(s, MC, "xVelocity", "double", "Max forward velocity (xVelocity)", "in/s", "positive", "maxAchievableForwardVelocity", "identity");
        add(s, MC, "yVelocity", "double", "Max strafe velocity (yVelocity)", "in/s", "positive", "maxAchievableStrafeVelocity", "identity");
        add(s, MC, "maxPower", "double", "Max drive power", "", "positive", null, null);
        add(s, FC, "centripetalScaling", "double", "Centripetal scaling", "", "positive", null, null);
        add(s, FC, "translationalPIDFCoefficients", PIDF, "Translational PIDF", "", "any", null, null);
        add(s, FC, "headingPIDFCoefficients", PIDF, "Heading PIDF", "", "any", null, null);
        add(s, FC, "drivePIDFCoefficients", FPIDF, "Drive PIDF (filtered)", "", "any", null, null);
        // PathConstraints(tValueConstraint, timeoutConstraint, brakingStrength, brakingStart): names from the sources jar
        List<String> names = api.paramNames(PC, "<init>", 4);
        for (int i = 0; i < names.size(); i++) {
            s.add(Json.obj("key", "PathConstraints.<init>/4#" + i, "builder", "PathConstraints", "method", "<init>", "arg", i, "type", "double",
                    "label", "PathConstraints " + names.get(i), "unit", "", "sign", "positive", "sim_key", null, "sim_transform", null, "verified", api.has(PC, "<init>", "double", "double", "double", "double"),
                    "default", null));
        }
        return s;
    }

    private void add(List<Map<String, Object>> s, String cls, String method, String type, String label, String unit, String sign, String simKey, String transform) {
        if (!api.has(cls, method, type)) return;  // not in this version: not shown
        String simple = cls.substring(cls.lastIndexOf('.') + 1);
        s.add(Json.obj("key", simple + "." + method, "builder", simple, "method", method, "type", type.contains(".") ? type.substring(type.lastIndexOf('.') + 1) : type,
                "label", label, "unit", unit, "sign", sign, "sim_key", simKey, "sim_transform", transform, "verified", true,
                "default", api.fieldDefault(cls, method)));
    }
}
