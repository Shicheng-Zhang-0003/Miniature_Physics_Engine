package org.beesim.team.gen;

import org.beesim.team.Json;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * BEE's autonomous (Auto Builder JSON) as a list of steps with poses RELATIVE TO THE START:
 * x = inches forward, y = inches to the left, h = degrees (+ = left / counter-clockwise), like the Auto Builder.
 * Mirrors AutoCodegen.program / blocks_from_points / point_acts in auto_builder/auto_codegen.gd.
 */
public final class Program {

    public abstract static class Step {
        public String label = "";
    }

    public static final class Drive extends Step {
        public double x0, y0, h0, x, y, h, maxPower, dist, dh;
        public String headingMode;  // linear / constant
        public int point;           // point index (goto) or -1 (move)
    }

    public static final class Turn extends Step {
        public double h0, h, dh;
    }

    public static final class Intake extends Step {
        public boolean on;
    }

    public static final class Shoot extends Step {
        public int n;
    }

    public static final class Wait extends Step {
        public double s;
    }

    public static final class Together extends Step {
        public final List<Step> body = new ArrayList<>();
        public boolean any;  // TOGETHER (ANY): done when the FIRST one is done
    }

    public final List<Step> steps = new ArrayList<>();
    public final List<String> errors = new ArrayList<>();
    private double cx, cy, ch;  // the planned pose (relative), as the program goes on
    private final List<Object> points;

    public static Program of(Map<String, Object> path) {
        Program p = new Program(Json.list(path.get("points")));
        List<Object> blocks = "blocks".equals(path.get("mode")) && path.get("blocks") instanceof List ? Json.list(path.get("blocks")) : blocksFromPoints(p.points);
        p.add(blocks, p.steps, "");
        if (p.steps.isEmpty() && p.errors.isEmpty()) p.errors.add("The autonomous is empty: draw a path or add blocks in the Auto Builder.");
        return p;
    }

    private Program(List<Object> points) { this.points = points; }

    /** auto_codegen.gd point_acts */
    static Map<String, Object> pointActs(Map<String, Object> p) {
        if (p.containsKey("do_intake"))
            return Json.obj("intake", Json.str(p.get("do_intake"), "keep"), "shots", (int) Json.num(p.get("do_shots"), 0), "wait", Json.num(p.get("do_wait"), 0), "during", Boolean.TRUE.equals(p.get("during")));
        Map<String, Object> a = Json.obj("intake", "keep", "shots", 0, "wait", 0.0, "during", false);
        switch (Json.str(p.get("action"), "none")) {
            case "intake_on": a.put("intake", "on"); break;
            case "intake_off": a.put("intake", "off"); break;
            case "shoot": a.put("shots", (int) Json.num(p.get("shots"), 4)); break;
            case "wait": a.put("wait", Json.num(p.get("wait"), 1.0)); break;
            default: break;
        }
        return a;
    }

    /** auto_codegen.gd blocks_from_points */
    static List<Object> blocksFromPoints(List<Object> pts) {
        List<Object> out = new ArrayList<>();
        for (int i = 0; i < pts.size(); i++) {
            Map<String, Object> a = pointActs(Json.map(pts.get(i)));
            List<Object> mech = new ArrayList<>();
            if (!"keep".equals(a.get("intake"))) mech.add(Json.obj("t", "intake", "on", "on".equals(a.get("intake"))));
            if ((int) a.get("shots") > 0) mech.add(Json.obj("t", "shoot", "n", a.get("shots"), "wait", !(Boolean) a.get("during")));
            if ((Boolean) a.get("during") && !mech.isEmpty()) {
                List<Object> body = new ArrayList<>(mech);
                body.add(Json.obj("t", "goto", "p", i));
                out.add(Json.obj("t", "together", "body", body));
            } else {
                out.add(Json.obj("t", "goto", "p", i));
                out.addAll(mech);
            }
            if ((double) a.get("wait") > 0) out.add(Json.obj("t", "wait", "s", a.get("wait")));
        }
        return out;
    }

    private void add(List<Object> blocks, List<Step> out, String where) {
        for (int bi = 0; bi < blocks.size(); bi++) {
            Map<String, Object> b = Json.map(blocks.get(bi));
            String t = Json.str(b.get("t"), "");
            String here = where + (where.isEmpty() ? "" : " > ") + "block " + (bi + 1) + " (" + t + ")";
            switch (t) {
                case "goto": {
                    int pi = (int) Json.num(b.get("p"), -1);
                    if (pi < 0 || pi >= points.size()) { errors.add(here + ": point " + (pi + 1) + " does not exist any more"); break; }
                    Map<String, Object> p = Json.map(points.get(pi));
                    Drive d = drive(Json.num(p.get("x"), 0), Json.num(p.get("y"), 0), Json.num(p.get("h"), 0), "linear", clamp(Json.num(p.get("speed"), 0.6), 0.1, 1.0));
                    d.point = pi;
                    d.label = "point " + (pi + 1);
                    out.add(d);
                    break;
                }
                case "move": {
                    double in = Json.num(b.get("in"), 12);
                    String dir = Json.str(b.get("dir"), "forward");
                    double fx = 0, fy = 0;
                    switch (dir) {
                        case "back": fx = -in; break;
                        case "left": fy = in; break;
                        case "right": fy = -in; break;
                        default: fx = in;
                    }
                    double c = Math.cos(Math.toRadians(ch)), s = Math.sin(Math.toRadians(ch));
                    Drive d = drive(cx + fx * c - fy * s, cy + fx * s + fy * c, ch, "constant", clamp(Json.num(b.get("speed"), 0.5), 0.1, 1.0));
                    d.point = -1;
                    d.label = "move " + dir + " " + Gen.num(in) + " in";
                    out.add(d);
                    break;
                }
                case "turn": {
                    Turn tr = new Turn();
                    tr.h0 = ch;
                    tr.h = Json.num(b.get("deg"), 0);
                    tr.dh = Math.abs(wrap(tr.h - ch));
                    tr.label = "turn to " + Gen.num(tr.h) + "°";
                    ch = tr.h;
                    out.add(tr);
                    break;
                }
                case "intake": {
                    Intake it = new Intake();
                    it.on = !Boolean.FALSE.equals(b.get("on"));
                    it.label = "intake " + (it.on ? "on" : "off");
                    out.add(it);
                    break;
                }
                case "shoot": {
                    Shoot sh = new Shoot();
                    sh.n = Math.max(1, (int) Json.num(b.get("n"), 1));
                    sh.label = "shoot " + sh.n;
                    out.add(sh);
                    break;
                }
                case "wait": {
                    Wait w = new Wait();
                    w.s = Math.max(0, Json.num(b.get("s"), 1));
                    w.label = "wait " + Gen.num(w.s) + " s";
                    out.add(w);
                    break;
                }
                case "together": {
                    Together tg = new Together();
                    tg.any = "any".equals(Json.str(b.get("mode"), "all"));
                    tg.label = tg.any ? "together (any)" : "together";
                    add(Json.list(b.get("body")), tg.body, here);
                    out.add(tg);
                    break;
                }
                case "repeat": {
                    int n = (int) Json.num(b.get("n"), 1);
                    if (n < 0 || n > 20) { errors.add(here + ": repeat " + n + " times is not supported (1..20)"); break; }
                    for (int k = 0; k < n; k++) add(Json.list(b.get("body")), out, here + " #" + (k + 1));
                    break;
                }
                default:
                    // wait_until / drive_until / chase / if / repeat_until / mech need sensors or devices that the team
                    // export does not map yet: refuse instead of guessing
                    errors.add(here + ": the \"" + t + "\" block is not supported by the team-code export yet. Remove it, or use the BASIC export.");
            }
        }
    }

    private Drive drive(double x, double y, double h, String mode, double maxPower) {
        Drive d = new Drive();
        d.x0 = cx; d.y0 = cy; d.h0 = ch;
        d.x = x; d.y = y; d.h = h;
        d.headingMode = mode;
        d.maxPower = maxPower;
        d.dist = Math.hypot(x - cx, y - cy);
        d.dh = Math.abs(wrap(h - ch));
        cx = x; cy = y; ch = h;
        return d;
    }

    static double wrap(double deg) {
        double d = ((deg + 180) % 360 + 360) % 360 - 180;
        return d;
    }

    static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
