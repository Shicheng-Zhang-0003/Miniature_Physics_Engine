package org.beesim.team;

import com.sun.source.tree.BinaryTree;
import com.sun.source.tree.ConditionalExpressionTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.IdentifierTree;
import com.sun.source.tree.LiteralTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.ParenthesizedTree;
import com.sun.source.tree.ReturnTree;
import com.sun.source.tree.StatementTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.TypeCastTree;
import com.sun.source.tree.UnaryTree;
import org.beesim.team.JavaIndex.ClassInfo;
import org.beesim.team.JavaIndex.FieldInfo;
import org.beesim.team.JavaIndex.MethodInfo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Constant folding over the team's code: literals, arithmetic, static fields (Config.Indexer.OPEN_POSITION,
 * nested classes), Math.*, new Pose(..), enum constants and small static helpers (Utilities.ticksToDeg(...)).
 * Instance fields count only when they have a constant initializer. Returns null when it cannot know the value.
 */
public final class Eval {
    private final JavaIndex ix;
    private final Set<FieldInfo> busy = new HashSet<>();

    public Eval(JavaIndex ix) { this.ix = ix; }

    public Val eval(ExpressionTree e, ClassInfo ctx) { return eval(e, ctx, new HashMap<>(), 0); }

    public Val eval(ExpressionTree e, ClassInfo ctx, Map<String, Val> locals, int depth) {
        if (e == null || depth > 6) return null;
        try {
            return ev(e, ctx, locals, depth);
        } catch (RuntimeException ex) {
            return null;
        }
    }

    private Val ev(ExpressionTree e, ClassInfo ctx, Map<String, Val> locals, int depth) {
        switch (e.getKind()) {
            case INT_LITERAL: case LONG_LITERAL: case FLOAT_LITERAL: case DOUBLE_LITERAL:
                return Val.num(((Number) ((LiteralTree) e).getValue()).doubleValue());
            case STRING_LITERAL:
                return Val.str((String) ((LiteralTree) e).getValue());
            case BOOLEAN_LITERAL:
                return Val.bool((Boolean) ((LiteralTree) e).getValue());
            case PARENTHESIZED:
                return eval(((ParenthesizedTree) e).getExpression(), ctx, locals, depth);
            case TYPE_CAST: {
                Val v = eval(((TypeCastTree) e).getExpression(), ctx, locals, depth);
                String t = ((TypeCastTree) e).getType().toString();
                if (v != null && v.isNum() && (t.equals("int") || t.equals("long"))) {
                    Val r = Val.num((long) v.num);
                    return r;
                }
                return v;
            }
            case UNARY_MINUS: {
                Val v = eval(((UnaryTree) e).getExpression(), ctx, locals, depth);
                return v != null && v.isNum() ? Val.num(-v.num) : null;
            }
            case UNARY_PLUS:
                return eval(((UnaryTree) e).getExpression(), ctx, locals, depth);
            case LOGICAL_COMPLEMENT: {
                Val v = eval(((UnaryTree) e).getExpression(), ctx, locals, depth);
                return v != null && v.kind == Val.K.BOOL ? Val.bool(!v.bool) : null;
            }
            case PLUS: case MINUS: case MULTIPLY: case DIVIDE: case REMAINDER:
            case LESS_THAN: case GREATER_THAN: case LESS_THAN_EQUAL: case GREATER_THAN_EQUAL:
            case EQUAL_TO: case NOT_EQUAL_TO: case CONDITIONAL_AND: case CONDITIONAL_OR:
                return binary((BinaryTree) e, ctx, locals, depth);
            case CONDITIONAL_EXPRESSION: {
                ConditionalExpressionTree c = (ConditionalExpressionTree) e;
                Val cond = eval(c.getCondition(), ctx, locals, depth);
                if (cond == null || cond.kind != Val.K.BOOL) return null;
                return eval(cond.bool ? c.getTrueExpression() : c.getFalseExpression(), ctx, locals, depth);
            }
            case IDENTIFIER:
                return ident(((IdentifierTree) e).getName().toString(), ctx, locals, depth);
            case MEMBER_SELECT:
                return select((MemberSelectTree) e, ctx, locals, depth);
            case METHOD_INVOCATION:
                return call((MethodInvocationTree) e, ctx, locals, depth);
            case NEW_CLASS:
                return newObj((NewClassTree) e, ctx, locals, depth);
            default:
                return null;
        }
    }

    private Val binary(BinaryTree b, ClassInfo ctx, Map<String, Val> locals, int depth) {
        Val l = eval(b.getLeftOperand(), ctx, locals, depth), r = eval(b.getRightOperand(), ctx, locals, depth);
        if (l == null || r == null) return null;
        if (b.getKind() == Tree.Kind.PLUS && (l.kind == Val.K.STR || r.kind == Val.K.STR))
            return Val.str((l.kind == Val.K.STR ? l.str : l.toString()) + (r.kind == Val.K.STR ? r.str : r.toString()));
        if (l.kind == Val.K.BOOL && r.kind == Val.K.BOOL) {
            switch (b.getKind()) {
                case CONDITIONAL_AND: return Val.bool(l.bool && r.bool);
                case CONDITIONAL_OR: return Val.bool(l.bool || r.bool);
                case EQUAL_TO: return Val.bool(l.bool == r.bool);
                case NOT_EQUAL_TO: return Val.bool(l.bool != r.bool);
                default: return null;
            }
        }
        if (l.kind == Val.K.ENUM && r.kind == Val.K.ENUM) {
            boolean eq = l.str.equals(r.str);
            if (b.getKind() == Tree.Kind.EQUAL_TO) return Val.bool(eq);
            if (b.getKind() == Tree.Kind.NOT_EQUAL_TO) return Val.bool(!eq);
            return null;
        }
        if (!l.isNum() || !r.isNum()) return null;
        double x = l.num, y = r.num;
        switch (b.getKind()) {
            case PLUS: return Val.num(x + y);
            case MINUS: return Val.num(x - y);
            case MULTIPLY: return Val.num(x * y);
            case DIVIDE: return y == 0 ? null : Val.num(isInt(b.getLeftOperand(), x) && isInt(b.getRightOperand(), y) ? (long) (x / y) : x / y);
            case REMAINDER: return y == 0 ? null : Val.num(x % y);
            case LESS_THAN: return Val.bool(x < y);
            case GREATER_THAN: return Val.bool(x > y);
            case LESS_THAN_EQUAL: return Val.bool(x <= y);
            case GREATER_THAN_EQUAL: return Val.bool(x >= y);
            case EQUAL_TO: return Val.bool(x == y);
            case NOT_EQUAL_TO: return Val.bool(x != y);
            default: return null;
        }
    }

    /** Integer division only when both sides are integer literals (1/2 == 0 in Java). */
    private static boolean isInt(ExpressionTree e, double v) {
        return e.getKind() == Tree.Kind.INT_LITERAL || e.getKind() == Tree.Kind.LONG_LITERAL;
    }

    private Val ident(String name, ClassInfo ctx, Map<String, Val> locals, int depth) {
        if (locals.containsKey(name)) return locals.get(name);
        for (ClassInfo c = ctx; c != null; c = c.outer) {
            FieldInfo f = ix.field(c, name);
            if (f != null) return fieldValue(f, depth);
        }
        return null;
    }

    /** The value of a field, with a reference to it when the generated code can use the symbol. */
    public Val fieldValue(FieldInfo f, int depth) {
        // a constant of a team enum: Config.Color.BLUE
        if ("enum".equals(f.owner.kind) && JavaIndex.simpleName(f.type).equals(f.owner.simple)) {
            Val v = Val.enumConst(f.owner.ref(), f.name);
            return v.withRef(f.owner.ref() + "." + f.name, f.owner.importName(), f.owner.src.path, f.line);
        }
        if (f.init == null || busy.contains(f)) return null;
        // a mutable instance field is state, not a constant (unless it is final)
        if (!f.isStatic && !f.isFinal) return null;
        busy.add(f);
        try {
            Val v = eval(f.init, f.owner, new HashMap<>(), depth + 1);
            if (v == null) return null;
            // a private constant cannot be named from another class: keep its value, not its name
            boolean visible = f.isStatic && !f.isPrivate && !f.owner.isPrivate();
            String ref = visible ? f.owner.ref() + "." + f.name : null;
            Val out = v.withRef(ref, visible ? f.owner.importName() : null, f.owner.src.path, f.line);
            if (f.isStatic && !visible) out.privateRef = f.owner.ref() + "." + f.name;
            return out;
        } finally {
            busy.remove(f);
        }
    }

    private Val select(MemberSelectTree s, ClassInfo ctx, Map<String, Val> locals, int depth) {
        String member = s.getIdentifier().toString();
        String target = JavaIndex.dotted(s.getExpression());
        if (target == null) return null;
        if (target.equals("Math")) {
            if (member.equals("PI")) return Val.num(Math.PI);
            if (member.equals("E")) return Val.num(Math.E);
        }
        ClassInfo c = ix.resolveType(target, ctx);
        if (c != null) {
            FieldInfo f = ix.field(c, member);
            if (f != null) return fieldValue(f, depth);
            return null;
        }
        // this.x
        if (target.equals("this") && ctx != null) {
            FieldInfo f = ix.field(ctx, member);
            return f == null ? null : fieldValue(f, depth);
        }
        // an enum constant of a library type: DcMotorSimple.Direction.REVERSE, GoBildaPinpointDriver.EncoderDirection.FORWARD
        // (goBILDA_4_BAR_POD: enum constants are not always upper case)
        if (Character.isUpperCase(JavaIndex.simpleName(target).charAt(0)) && Character.isJavaIdentifierStart(member.charAt(0)) && !target.equals("Math")) {
            Val v = Val.enumConst(target, member);
            v.ref = target + "." + member;
            String head = target.split("\\.")[0];
            String fq = ctx == null ? "" : JavaIndex.importedFqn(head, ctx);
            v.imp = fq.isEmpty() ? null : fq;
            return v;
        }
        return null;
    }

    private Val call(MethodInvocationTree m, ClassInfo ctx, Map<String, Val> locals, int depth) {
        String fn = JavaIndex.dotted(m.getMethodSelect());
        if (fn == null) return null;
        List<? extends ExpressionTree> a = m.getArguments();
        if (fn.startsWith("Math.")) {
            double[] x = new double[a.size()];
            for (int i = 0; i < a.size(); i++) {
                Val v = eval(a.get(i), ctx, locals, depth);
                if (v == null || !v.isNum()) return null;
                x[i] = v.num;
            }
            switch (fn.substring(5)) {
                case "toRadians": { Val v = Val.num(Math.toRadians(x[0])); v.usesToRadians = true; return v; }
                case "toDegrees": return Val.num(Math.toDegrees(x[0]));
                case "abs": return Val.num(Math.abs(x[0]));
                case "sqrt": return Val.num(Math.sqrt(x[0]));
                case "sin": return Val.num(Math.sin(x[0]));
                case "cos": return Val.num(Math.cos(x[0]));
                case "tan": return Val.num(Math.tan(x[0]));
                case "atan2": return Val.num(Math.atan2(x[0], x[1]));
                case "hypot": return Val.num(Math.hypot(x[0], x[1]));
                case "pow": return Val.num(Math.pow(x[0], x[1]));
                case "min": return Val.num(Math.min(x[0], x[1]));
                case "max": return Val.num(Math.max(x[0], x[1]));
                case "round": return Val.num(Math.round(x[0]));
                default: return null;
            }
        }
        // a small static helper of the team: double ticksToDeg(double p, double t, double g) { return p * 360 / (t * g); }
        int dot = fn.lastIndexOf('.');
        ClassInfo owner = dot < 0 ? ctx : ix.resolveType(fn.substring(0, dot), ctx);
        String name = dot < 0 ? fn : fn.substring(dot + 1);
        if (owner == null || depth > 4) return null;
        for (MethodInfo mi : ix.methods(owner, name)) {
            if (!mi.isStatic || mi.params.size() != a.size() || mi.body == null) continue;
            List<? extends StatementTree> st = mi.body.getStatements();
            if (st.size() != 1 || !(st.get(0) instanceof ReturnTree)) continue;
            Map<String, Val> bound = new HashMap<>();
            for (int i = 0; i < a.size(); i++) {
                Val v = eval(a.get(i), ctx, locals, depth);
                if (v == null) return null;
                bound.put(mi.params.get(i).getName().toString(), v);
            }
            return eval(((ReturnTree) st.get(0)).getExpression(), mi.owner, bound, depth + 1);
        }
        return null;
    }

    private Val newObj(NewClassTree n, ClassInfo ctx, Map<String, Val> locals, int depth) {
        String t = n.getIdentifier().toString().replaceAll("<.*>", "");
        List<? extends ExpressionTree> a = n.getArguments();
        if (JavaIndex.simpleName(t).equals("Pose") && (a.size() == 2 || a.size() == 3 || a.isEmpty())) {
            Val v = new Val();
            v.kind = Val.K.POSE;
            v.type = t;
            if (a.isEmpty()) return v;
            Val x = eval(a.get(0), ctx, locals, depth), y = eval(a.get(1), ctx, locals, depth);
            if (x == null || y == null || !x.isNum() || !y.isNum()) return null;
            v.x = x.num;
            v.y = y.num;
            if (a.size() == 3) {
                Val h = eval(a.get(2), ctx, locals, depth);
                if (h == null || !h.isNum()) return null;
                v.h = h.num;
                v.poseHasHeading = true;
                v.usesToRadians = h.usesToRadians || a.get(2).toString().contains("toRadians");
            }
            return v;
        }
        Val v = new Val();
        v.kind = Val.K.OBJ;
        v.type = t;
        for (ExpressionTree e : a) {
            Val x = eval(e, ctx, locals, depth);
            v.args.add(x);
        }
        return v;
    }
}
