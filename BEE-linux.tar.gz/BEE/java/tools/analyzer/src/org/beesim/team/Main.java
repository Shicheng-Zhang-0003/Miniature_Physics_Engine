package org.beesim.team;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/**
 * BEE team-code tool.
 *
 *   analyze  <project dir|zip> <out model.json> [--garage profile.json]
 *   generate <model.json> <answers.json> <path.json> <out dir>     (writes the OpMode + report.json)
 *
 * Exit code 0 = OK, 2 = bad usage, 3 = the export is refused (unsupported Pedro, unanswered question...): report.json says why.
 */
public final class Main {
    public static void main(String[] args) throws Exception {
        if (args.length < 1) usage();
        switch (args[0]) {
            case "analyze": {
                if (args.length < 3) usage();
                Map<String, Object> garage = null;
                for (int i = 3; i + 1 < args.length; i++) if (args[i].equals("--garage")) garage = Json.map(Json.parse(Files.readString(Path.of(args[i + 1]))));
                Map<String, Object> model = Analyzer.analyze(Path.of(args[1]), garage);
                Files.writeString(Path.of(args[2]), Json.write(model), StandardCharsets.UTF_8);
                System.out.println("model written: " + args[2]);
                break;
            }
            case "generate": {
                if (args.length < 5) usage();
                Map<String, Object> model = Json.map(Json.parse(Files.readString(Path.of(args[1]))));
                Map<String, Object> answers = Json.map(Json.parse(Files.readString(Path.of(args[2]))));
                Map<String, Object> path = Json.map(Json.parse(Files.readString(Path.of(args[3]))));
                org.beesim.team.gen.Generator.Result r = org.beesim.team.gen.Generator.generate(model, answers, path);
                Path out = Path.of(args[4]);
                Files.createDirectories(out);
                for (Map.Entry<String, String> f : r.files.entrySet()) {
                    Path p = out.resolve(f.getKey());
                    Files.createDirectories(p.getParent());
                    Files.writeString(p, f.getValue(), StandardCharsets.UTF_8);
                }
                Files.writeString(out.resolve("report.json"), Json.write(r.report()), StandardCharsets.UTF_8);
                System.out.println(r.ok() ? "generated " + r.files.keySet() : "refused: " + r.errors);
                if (!r.ok()) System.exit(3);
                break;
            }
            default:
                usage();
        }
    }

    private static void usage() {
        System.err.println("usage: analyze <project> <model.json> [--garage profile.json] | generate <model.json> <answers.json> <path.json> <outdir>");
        System.exit(2);
    }
}
