package org.beesim.team.gen;

import java.util.List;

/**
 * How the generated autonomous expresses "do this, then that, at the same time as this": in the team's OWN
 * framework. Road Runner Actions (SequentialAction...), FTCLib / SolversLib commands, or (for teams without a
 * framework) a tiny step runner inside the OpMode. The generator never mixes them.
 */
public abstract class Paradigm {
    protected final PedroAdapter pedro;
    protected final String follower;   // Java expression of the Follower (robot.drive / follower)

    protected Paradigm(PedroAdapter pedro, String follower) {
        this.pedro = pedro;
        this.follower = follower;
    }

    public abstract String name();

    /** The type of one step (Action / Command / Step). */
    public abstract String stepType();

    public abstract List<String> imports();

    public abstract String seq(List<String> items, String ind);

    public abstract String par(List<String> items, String ind);

    /** At the same time; done as soon as the FIRST one is done (TOGETHER ANY). */
    public abstract String race(List<String> items, String ind);

    /** seconds = ref * refScale when ref != null (Config.X.DELAY_SECONDS, or a millisecond constant with refScale 0.001). */
    public abstract String sleep(double seconds, String ref, double refScale);

    public abstract String instant(String statement);

    public abstract String waitUntil(String condition, String timeoutSeconds);

    public abstract String ifThen(String condition, String then);

    public String follow(String path, String timeoutSeconds, double maxPower, String label) {
        return "new FollowPath(" + path + ", " + Gen.num(maxPower) + ", " + timeoutSeconds + ", " + Gen.q(label) + ")";
    }

    public String turn(String radians, String timeoutSeconds, String label) {
        return "new TurnTo(" + radians + ", " + timeoutSeconds + ", " + Gen.q(label) + ")";
    }

    /** A team method that already returns a step of this paradigm (robot.shootAll() returns an Action). */
    public String team(String expr) { return expr; }

    /** One of the team's OWN Actions (a home-made framework: update(now) until inTerminalState()) as a step; null = not here. */
    public String teamAction(String expr) { return null; }

    /** Does a team method returning `kind` (action / command / sync) fit here as a step? */
    public abstract boolean accepts(String kind);

    /** Fields of the OpMode needed to run steps (the list of running Actions...). */
    public abstract List<String> fields(String runnerList);

    /** Statements that start the whole autonomous (in start()). */
    public abstract List<String> startRoot(String rootExpr, String runnerList);

    /** Statements that run the steps once per loop when the team has no runner of its own. */
    public abstract List<String> runOnce(String runnerList);

    /** True when everything finished. */
    public abstract String done(String runnerList);

    /** Nested helper classes (FollowPath, TurnTo, WaitUntil, IfThen...) */
    public abstract List<String> helpers();
}
