import java.io.*;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.stream.*;
import java.util.zip.*;
import javax.tools.*;

/**
 * Control Hub simulat: compilează SDK-ul simulat + codul echipei și rulează un OpMode conectat la sim.
 * Merge la fel pe Windows, Linux și macOS (doar Java, fără bash). Are nevoie de un JDK 11+.
 *   java RunOpMode.java NumeOpMode [port] [--home <folderul java>] [--work <folder pentru build>] [--teamcode <folder>] [--log <fișier>]
 *   java RunOpMode.java --compile-only [--teamcode <folder>]     (doar verifică dacă se compilează)
 * --home lipsește = folderul curent (pornit din java/).
 * Fișierele care nu se compilează (ex. folosesc biblioteci pe care sim-ul nu le are) sunt
 * excluse automat și listate; restul codului rulează în continuare.
 */
public class RunOpMode {
    static final List<String> JAVAC = List.of("--release", "8", "-Xlint:-options", "-encoding", "UTF-8", "-nowarn");

    public static void main(String[] args) throws Exception {
        String opmode, teamcode = null, log = null, homeArg = null, workArg = null;
        int port = 7777;
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("--home") && i + 1 < args.length) homeArg = args[++i];
            else if (args[i].equals("--work") && i + 1 < args.length) workArg = args[++i];
            else if (args[i].equals("--teamcode") && i + 1 < args.length) teamcode = args[++i];
            else if (args[i].equals("--log") && i + 1 < args.length) log = args[++i];
            else pos.add(args[i]);
        }
        if (log != null) {
            // tot ce scrie lansatorul și OpMode-ul ajunge în jurnal (jocul îl citește pentru panoul SIMULATE)
            PrintStream ps = new PrintStream(new FileOutputStream(log), true, "UTF-8");
            System.setOut(ps);
            System.setErr(ps);
        }
        opmode = pos.isEmpty() ? "QuickAuto" : pos.get(0);
        if (pos.size() > 1) port = Integer.parseInt(pos.get(1));
        boolean compileOnly = opmode.equals("--compile-only");

        Path home = (homeArg != null ? Paths.get(homeArg) : Paths.get("")).toAbsolutePath();
        Path work = workArg != null ? Paths.get(workArg).toAbsolutePath() : home;  // home poate fi doar de citit (jocul exportat)
        Path build = work.resolve("build");
        Path cache = work.resolve("build_lib");
        Path codeDir = teamcode != null && !teamcode.isEmpty() ? Paths.get(teamcode) : home.resolve("teamcode");

        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        if (javac == null) {
            System.out.println("ERROR: Java compiler not found. Install a JDK 11 or newer (not only a JRE), e.g. from https://adoptium.net");
            System.exit(6);
        }
        deleteTree(build);
        Files.createDirectories(build);
        if (!Files.isDirectory(codeDir)) {
            System.out.println("ERROR: folderul de cod nu exista: " + slash(codeDir));
            System.exit(3);
        }

        // 1. SDK-ul simulat + bibliotecile pe care le are și robotul real (lib/: Defined, Pedro Pathing...).
        //    Se compilează o singură dată: build_lib/ e refolosit cât timp sursele nu s-au schimbat.
        Path src = home.resolve("src"), lib = home.resolve("lib");
        String stamp = stamp(src, lib);
        Path stampFile = cache.resolve(".stamp");
        if (!Files.exists(stampFile) || !Files.readString(stampFile).trim().equals(stamp)) {
            deleteTree(cache);
            Files.createDirectories(cache);
            if (!compile(javac, javaFiles(src), cache, cache, new StringBuilder(), null)) System.exit(4);
            if (Files.isDirectory(lib)) {
                List<Path> libJava = javaFiles(lib);
                if (!libJava.isEmpty() && !compile(javac, libJava, cache, cache, new StringBuilder(), null)) System.exit(4);
                try (DirectoryStream<Path> jars = Files.newDirectoryStream(lib, "*.jar")) {
                    for (Path j : jars) unzip(j, cache);
                }
            }
            Files.writeString(stampFile, stamp);
        }
        copyTree(cache, build);

        // 2. codul echipei: compilăm, iar fișierele cu erori le scoatem și reîncercăm
        List<Path> files = javaFiles(codeDir);
        for (int attempt = 0; attempt < 10 && !files.isEmpty(); attempt++) {
            StringBuilder out = new StringBuilder();
            Set<Path> bad = new TreeSet<>();
            if (compile(javac, files, build, build, out, bad)) break;
            if (bad.isEmpty()) {
                System.out.print(out.toString().lines().limit(30).collect(Collectors.joining("\n", "", "\n")));
                System.exit(5);
            }
            for (Path f : bad) {
                System.out.println("EXCLUDED " + slash(f));
                String prefix = slash(f) + ":";
                List<String> lines = out.toString().lines().collect(Collectors.toList());
                int shown = 0;
                for (int i = 0; i < lines.size() && shown < 6; i++) {
                    if (!lines.get(i).startsWith(prefix)) continue;
                    for (int k = i; k < Math.min(i + 3, lines.size()) && shown < 6; k++, shown++)
                        System.out.println("    " + lines.get(k));
                }
                files.remove(f);
            }
        }

        if (compileOnly) {
            System.out.println("COMPILE OK");
            return;
        }
        // 3. OpMode-ul rulează în același proces: dacă jocul oprește lansatorul, se oprește și el
        System.setProperty("ftcsim.build", build.toString());
        URLClassLoader cl = new URLClassLoader(new URL[]{build.toUri().toURL()}, ClassLoader.getPlatformClassLoader());
        Thread.currentThread().setContextClassLoader(cl);
        try {
            cl.loadClass("org.ftcsim.OpModeRunner").getMethod("main", String[].class)
                .invoke(null, (Object) new String[]{opmode, String.valueOf(port)});
        } catch (java.lang.reflect.InvocationTargetException e) {
            e.getCause().printStackTrace();  // excepția din OpMode, ca la rularea directă
            System.exit(1);
        }
    }

    /** javac prin API (fără limita de lungime a liniei de comandă de pe Windows). Fișierele cu erori ajung în bad. */
    static boolean compile(JavaCompiler javac, List<Path> files, Path cp, Path out, StringBuilder log, Set<Path> bad) throws IOException {
        if (files.isEmpty()) return true;
        DiagnosticCollector<JavaFileObject> diags = new DiagnosticCollector<>();
        try (StandardJavaFileManager fm = javac.getStandardFileManager(diags, null, StandardCharsets.UTF_8)) {
            List<String> opts = new ArrayList<>(JAVAC);
            opts.addAll(List.of("-cp", cp.toString(), "-d", out.toString()));
            boolean ok = javac.getTask(null, fm, diags, opts, null, fm.getJavaFileObjectsFromPaths(files)).call();
            for (Diagnostic<? extends JavaFileObject> d : diags.getDiagnostics()) {
                if (d.getKind() != Diagnostic.Kind.ERROR) continue;
                String where = "";
                if (d.getSource() != null) {
                    Path p = Paths.get(d.getSource().toUri());
                    where = slash(p) + ":" + d.getLineNumber() + ": ";
                    if (bad != null) bad.add(p);
                }
                // ca javac: mesajul, linia de cod, săgeata spre coloană, apoi detaliile (symbol: ...)
                String[] msg = d.getMessage(Locale.ENGLISH).split("\\R");
                log.append(where).append("error: ").append(msg[0]).append('\n');
                if (d.getSource() != null && d.getLineNumber() > 0) {
                    try {
                        List<String> src = Files.readAllLines(Paths.get(d.getSource().toUri()), StandardCharsets.UTF_8);
                        if (d.getLineNumber() <= src.size()) {
                            log.append(src.get((int) d.getLineNumber() - 1)).append('\n');
                            if (d.getColumnNumber() > 0) log.append(" ".repeat((int) d.getColumnNumber() - 1)).append("^\n");
                        }
                    } catch (IOException | UncheckedIOException ignored) {
                    }
                }
                for (int i = 1; i < msg.length; i++) log.append(msg[i]).append('\n');
            }
            if (!ok && bad == null) System.out.print(log);
            return ok;
        }
    }

    static List<Path> javaFiles(Path dir) throws IOException {
        if (!Files.isDirectory(dir)) return new ArrayList<>();
        try (Stream<Path> s = Files.walk(dir)) {
            return s.filter(p -> p.toString().endsWith(".java")).sorted().collect(Collectors.toCollection(ArrayList::new));
        }
    }

    /** Amprenta surselor SDK-ului și bibliotecilor (nume + data modificării): se schimbă = recompilăm. */
    static String stamp(Path... dirs) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        for (Path d : dirs) {
            for (Path f : javaFiles(d))
                md.update((Files.getLastModifiedTime(f).toMillis() + " " + slash(f) + "\n").getBytes(StandardCharsets.UTF_8));
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    static void unzip(Path jar, Path dest) throws IOException {
        try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(jar))) {
            for (ZipEntry e; (e = zin.getNextEntry()) != null; ) {
                if (e.getName().startsWith("META-INF/")) continue;
                Path p = dest.resolve(e.getName()).normalize();
                if (!p.startsWith(dest)) continue;  // nume periculos în arhivă
                if (e.isDirectory()) Files.createDirectories(p);
                else {
                    Files.createDirectories(p.getParent());
                    Files.copy(zin, p, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    static void copyTree(Path from, Path to) throws IOException {
        try (Stream<Path> s = Files.walk(from)) {
            for (Path p : (Iterable<Path>) s::iterator) {
                Path t = to.resolve(from.relativize(p).toString());
                if (Files.isDirectory(p)) Files.createDirectories(t);
                else Files.copy(p, t, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    static void deleteTree(Path dir) throws IOException {
        if (!Files.exists(dir)) return;
        try (Stream<Path> s = Files.walk(dir)) {
            for (Path p : (Iterable<Path>) s.sorted(Comparator.reverseOrder())::iterator) Files.delete(p);
        }
    }

    /** Căile cu „/” pe orice sistem (jocul le scurtează în mesaje). */
    static String slash(Path p) {
        return p.toString().replace('\\', '/');
    }
}
