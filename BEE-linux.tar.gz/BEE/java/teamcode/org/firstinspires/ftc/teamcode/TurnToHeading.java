package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

/**
 * Cod FTC normal: se întoarce cu IMU la 90° (stânga), apoi la -90° (dreapta), apoi înapoi la 0°.
 * Folosește un regulator P simplu: puterea de rotire e proporțională cu eroarea de unghi.
 */
@Autonomous(name = "Turn To Heading")
public class TurnToHeading extends LinearOpMode {
    private DcMotorEx lf, rf, lb, rb;
    private IMU imu;

    @Override
    public void runOpMode() {
        lf = hardwareMap.get(DcMotorEx.class, "left_front_drive");
        rf = hardwareMap.get(DcMotorEx.class, "right_front_drive");
        lb = hardwareMap.get(DcMotorEx.class, "left_back_drive");
        rb = hardwareMap.get(DcMotorEx.class, "right_back_drive");
        lf.setDirection(DcMotorSimple.Direction.REVERSE);
        lb.setDirection(DcMotorSimple.Direction.REVERSE);

        imu = hardwareMap.get(IMU.class, "imu");
        imu.initialize(new IMU.Parameters(new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.UP,
                RevHubOrientationOnRobot.UsbFacingDirection.FORWARD)));
        imu.resetYaw();

        waitForStart();

        turnTo(90);
        turnTo(-90);
        turnTo(0);

        telemetry.addLine("GATA");
        telemetry.addData("heading final", "%.1f grade", heading());
        telemetry.update();
    }

    private double heading() {
        return imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.DEGREES);
    }

    private void turnTo(double target) {
        long lastPrint = 0;
        while (opModeIsActive()) {
            double error = AngleUnit.DEGREES.normalize(target - heading());
            if (Math.abs(error) < 1.0) break;
            double turn = Math.max(-0.6, Math.min(0.6, error * 0.02));
            // turn pozitiv = rotire spre stânga: roțile din stânga înapoi, cele din dreapta înainte
            lf.setPower(-turn);
            lb.setPower(-turn);
            rf.setPower(turn);
            rb.setPower(turn);
            if (System.currentTimeMillis() - lastPrint > 250) {
                lastPrint = System.currentTimeMillis();
                telemetry.addData("tinta", "%.0f grade", target);
                telemetry.addData("heading", "%.1f grade", heading());
                telemetry.update();
            }
            sleep(10);
        }
        lf.setPower(0);
        lb.setPower(0);
        rf.setPower(0);
        rb.setPower(0);
        sleep(300);
        telemetry.addData("ajuns la", "%.0f grade -> heading %.1f", target, heading());
        telemetry.update();
    }
}
