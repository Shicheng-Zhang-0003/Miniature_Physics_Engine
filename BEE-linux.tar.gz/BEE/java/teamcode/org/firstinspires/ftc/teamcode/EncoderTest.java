package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

/**
 * Cod FTC normal: același fișier ar trebui să compileze și în FtcRobotController.
 * Merge înainte 1 s, apoi lateral (strafe) 1 s, și afișează encoderele.
 */
@Autonomous(name = "Encoder Test")
public class EncoderTest extends LinearOpMode {
    @Override
    public void runOpMode() {
        DcMotorEx lf = hardwareMap.get(DcMotorEx.class, "left_front_drive");
        DcMotorEx rf = hardwareMap.get(DcMotorEx.class, "right_front_drive");
        DcMotorEx lb = hardwareMap.get(DcMotorEx.class, "left_back_drive");
        DcMotorEx rb = hardwareMap.get(DcMotorEx.class, "right_back_drive");

        // motoarele din stânga sunt montate în oglindă, ca pe un robot real
        lf.setDirection(DcMotorSimple.Direction.REVERSE);
        lb.setDirection(DcMotorSimple.Direction.REVERSE);
        for (DcMotorEx m : new DcMotorEx[] {lf, rf, lb, rb}) {
            m.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            m.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }

        waitForStart();

        // 1. înainte
        drive(lf, rf, lb, rb, 0.5, 0.5, 0.5, 0.5, 1000);
        // 2. strafe la dreapta
        drive(lf, rf, lb, rb, 0.5, -0.5, -0.5, 0.5, 1000);
        drive(lf, rf, lb, rb, 0, 0, 0, 0, 500);

        telemetry.addLine("GATA");
        report(lf, rf, lb, rb);
    }

    private void drive(DcMotorEx lf, DcMotorEx rf, DcMotorEx lb, DcMotorEx rb,
                       double plf, double prf, double plb, double prb, long ms) {
        lf.setPower(plf);
        rf.setPower(prf);
        lb.setPower(plb);
        rb.setPower(prb);
        long end = System.currentTimeMillis() + ms;
        while (opModeIsActive() && System.currentTimeMillis() < end) {
            report(lf, rf, lb, rb);
            sleep(250);
        }
    }

    private void report(DcMotorEx lf, DcMotorEx rf, DcMotorEx lb, DcMotorEx rb) {
        telemetry.addData("encodere", "LF %d  RF %d  LB %d  RB %d",
                lf.getCurrentPosition(), rf.getCurrentPosition(), lb.getCurrentPosition(), rb.getCurrentPosition());
        telemetry.addData("viteza LF", "%.0f ticks/s", lf.getVelocity());
        telemetry.update();
    }
}
