package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

/**
 * Autonomie rapidă BEE pentru robotul ROȘU care pornește lipit de peretele stâng (y = 72 in).
 *  1. Iese de lângă perete, merge spre public și LANSEAZĂ cele 4 POLLEN pre-load în CELL-ul roșu
 *     de sus (deschis spre public) -> HIVE TIP. Un CELL se nimerește doar din fața deschiderii lui.
 *  2. Merge în LOADING ZONE și ia cele 4 POLLEN de lângă perete.
 *  3. Le LANSEAZĂ în celălalt CELL roșu (cel care a ajuns sus după TIP).
 *  4. Rămâne parțial în LOADING ZONE, fără să atingă peretele: LEAVE + PARK.
 * Heading: 0 = cu fața spre peretele din spate, pozitiv = rotire spre stânga (ca IMU-ul FTC).
 */
@Autonomous(name = "Quick Auto", group = "BEE")
public class QuickAuto extends LinearOpMode {
    // goBILDA 312 rpm (537.7 ticks/rotație), roți mecanum de 104 mm
    static final double TICKS_PER_INCH = 537.7 / (Math.PI * 4.09);

    private DcMotorEx lf, rf, lb, rb, intake, launcher;
    private Servo feeder;
    private IMU imu;

    @Override
    public void runOpMode() {
        lf = hardwareMap.get(DcMotorEx.class, "left_front_drive");
        rf = hardwareMap.get(DcMotorEx.class, "right_front_drive");
        lb = hardwareMap.get(DcMotorEx.class, "left_back_drive");
        rb = hardwareMap.get(DcMotorEx.class, "right_back_drive");
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        launcher = hardwareMap.get(DcMotorEx.class, "launcher");
        feeder = hardwareMap.get(Servo.class, "feeder");
        imu = hardwareMap.get(IMU.class, "imu");

        lf.setDirection(DcMotorSimple.Direction.REVERSE);
        lb.setDirection(DcMotorSimple.Direction.REVERSE);
        for (DcMotorEx m : new DcMotorEx[] {lf, rf, lb, rb}) {
            m.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            m.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            m.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        imu.initialize(new IMU.Parameters(new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.UP,
                RevHubOrientationOnRobot.UsbFacingDirection.FORWARD)));
        imu.resetYaw();
        feeder.setPosition(0);

        telemetry.addLine("Quick Auto gata, astept START");
        telemetry.update();
        waitForStart();

        launcher.setPower(1.0);          // pornim lansatorul de la început, să prindă turație
        strafe(12, 0.5, 0);              // ieșim de lângă perete
        drive(-38, 0.6, 0);              // spre public: CELL-ul roșu de jos se deschide spre public
        turnTo(-59.5);                   // spre CELL-ul roșu de jos (cel orientat în sus la start)
        shoot(4);

        turnTo(0);
        drive(73.5, 0.7, 0);             // până în dreptul LOADING ZONE
        turnTo(90);                      // cu fața spre peretele stâng
        intake.setPower(1.0);
        drive(16, 0.35, 90, 1800);       // înaintează până în POLLEN-ul de lângă perete (se oprește în el)
        sleep(300);
        drive(-3, 0.4, 90);              // ne desprindem de perete (pentru LEAVE)
        intake.setPower(0);

        turnTo(-114);                    // spre celălalt CELL roșu, sus după TIP (deschis spre spate)
        shoot(4);
        launcher.setPower(0);

        telemetry.addLine("Quick Auto terminat");
        telemetry.update();
        while (opModeIsActive()) {
            sleep(50);
        }
    }

    private double heading() {
        return imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.DEGREES);
    }

    private void setDrive(double forward, double strafe, double turn) {
        // turn pozitiv = rotire spre stânga
        double plf = forward + strafe - turn;
        double prf = forward - strafe + turn;
        double plb = forward - strafe - turn;
        double prb = forward + strafe + turn;
        double max = Math.max(1.0, Math.max(Math.max(Math.abs(plf), Math.abs(prf)), Math.max(Math.abs(plb), Math.abs(prb))));
        lf.setPower(plf / max);
        rf.setPower(prf / max);
        lb.setPower(plb / max);
        rb.setPower(prb / max);
    }

    private double headingCorrection(double target) {
        return AngleUnit.DEGREES.normalize(target - heading()) * 0.02;
    }

    private void drive(double inches, double power, double holdHeading) {
        drive(inches, power, holdHeading, 4000);
    }

    /** Merge înainte (sau înapoi, cu inch negativi), ținând heading-ul cu IMU-ul, cel mult timeoutMs. */
    private void drive(double inches, double power, double holdHeading, long timeoutMs) {
        int[] start = positions();
        double sign = Math.signum(inches);
        long timeout = System.currentTimeMillis() + timeoutMs;
        while (opModeIsActive() && System.currentTimeMillis() < timeout) {
            int[] now = positions();
            double fwd = ((now[0] - start[0]) + (now[1] - start[1]) + (now[2] - start[2]) + (now[3] - start[3])) / 4.0;
            double remaining = Math.abs(inches) - Math.abs(fwd) / TICKS_PER_INCH;
            if (remaining <= 0.3) break;
            double p = Math.min(power, 0.15 + remaining * 0.05);
            setDrive(sign * p, 0, headingCorrection(holdHeading));
            sleep(10);
        }
        setDrive(0, 0, 0);
    }

    /** Merge lateral spre dreapta (inch pozitivi) sau stânga (negativi). */
    private void strafe(double inches, double power, double holdHeading) {
        int[] start = positions();
        double sign = Math.signum(inches);
        long timeout = System.currentTimeMillis() + 4000;
        while (opModeIsActive() && System.currentTimeMillis() < timeout) {
            int[] now = positions();
            double side = ((now[0] - start[0]) - (now[1] - start[1]) - (now[2] - start[2]) + (now[3] - start[3])) / 4.0;
            double remaining = Math.abs(inches) - Math.abs(side) / TICKS_PER_INCH;
            if (remaining <= 0.3) break;
            double p = Math.min(power, 0.15 + remaining * 0.05);
            setDrive(0, sign * p, headingCorrection(holdHeading));
            sleep(10);
        }
        setDrive(0, 0, 0);
    }

    private void turnTo(double target) {
        long timeout = System.currentTimeMillis() + 3000;
        while (opModeIsActive() && System.currentTimeMillis() < timeout) {
            double error = AngleUnit.DEGREES.normalize(target - heading());
            if (Math.abs(error) < 1.5) break;
            double turn = Math.max(-0.6, Math.min(0.6, error * 0.02));
            if (Math.abs(turn) < 0.12) turn = Math.signum(turn) * 0.12;
            setDrive(0, 0, turn);
            sleep(10);
        }
        setDrive(0, 0, 0);
        sleep(150);
    }

    /** Așteaptă ca flywheel-ul să ajungă la turație (viteza nu se mai schimbă), maxim 3 s. */
    private void waitForLauncher() {
        ElapsedTime t = new ElapsedTime();
        double prev = launcher.getVelocity();
        while (opModeIsActive() && t.seconds() < 3.0) {
            sleep(100);
            double v = launcher.getVelocity();
            if (v > 200 && Math.abs(v - prev) < 0.01 * v) break;
            prev = v;
        }
    }

    /** Împinge n piese în lansator cu servo-ul feeder (după ce flywheel-ul e la turație). */
    private void shoot(int n) {
        for (int i = 0; i < n && opModeIsActive(); i++) {
            waitForLauncher();
            feeder.setPosition(1);
            sleep(150);
            feeder.setPosition(0);
            sleep(300);
        }
        telemetry.addData("lansat", n);
        telemetry.addData("heading", "%.1f", heading());
        telemetry.update();
    }

    private int[] positions() {
        return new int[] {lf.getCurrentPosition(), rf.getCurrentPosition(), lb.getCurrentPosition(), rb.getCurrentPosition()};
    }
}
