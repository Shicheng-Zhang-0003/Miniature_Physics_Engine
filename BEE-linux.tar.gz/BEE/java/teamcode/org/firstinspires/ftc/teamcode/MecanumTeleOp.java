package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.NormalizedColorSensor;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.TouchSensor;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

/**
 * Cod FTC normal (OpMode iterativ): mecanum cu gamepad1, intake, lansator, Limelight și senzori.
 * Stick stânga = mers + strafe, stick dreapta = rotire, RB = intake, A = lansează o bilă.
 */
@TeleOp(name = "Mecanum TeleOp", group = "BEE")
public class MecanumTeleOp extends OpMode {
    private DcMotorEx lf, rf, lb, rb, intake, launcher;
    private Servo feeder;
    private Limelight3A limelight;
    private DistanceSensor frontDistance;
    private NormalizedColorSensor intakeColor;
    private TouchSensor bumper;
    private final ElapsedTime feederTimer = new ElapsedTime();

    @Override
    public void init() {
        lf = hardwareMap.get(DcMotorEx.class, "left_front_drive");
        rf = hardwareMap.get(DcMotorEx.class, "right_front_drive");
        lb = hardwareMap.get(DcMotorEx.class, "left_back_drive");
        rb = hardwareMap.get(DcMotorEx.class, "right_back_drive");
        lf.setDirection(DcMotorSimple.Direction.REVERSE);
        lb.setDirection(DcMotorSimple.Direction.REVERSE);
        for (DcMotorEx m : new DcMotorEx[] {lf, rf, lb, rb}) m.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        launcher = hardwareMap.get(DcMotorEx.class, "launcher");
        feeder = hardwareMap.get(Servo.class, "feeder");
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.pipelineSwitch(0);
        limelight.start();
        frontDistance = hardwareMap.get(DistanceSensor.class, "front_distance");
        intakeColor = hardwareMap.get(NormalizedColorSensor.class, "intake_color");
        bumper = hardwareMap.get(TouchSensor.class, "front_bumper");
        telemetry.addLine("Mecanum TeleOp gata");
    }

    @Override
    public void loop() {
        double drive = -gamepad1.left_stick_y;
        double strafe = gamepad1.left_stick_x;
        double turn = gamepad1.right_stick_x;
        // turn pozitiv = spre dreapta (convenția din exemplele FTC pentru TeleOp)
        double fl = drive + strafe + turn, fr = drive - strafe - turn, bl = drive - strafe + turn, br = drive + strafe - turn;
        double max = Math.max(1, Math.max(Math.max(Math.abs(fl), Math.abs(fr)), Math.max(Math.abs(bl), Math.abs(br))));
        lf.setPower(fl / max);
        rf.setPower(fr / max);
        lb.setPower(bl / max);
        rb.setPower(br / max);

        intake.setPower(gamepad1.right_bumper ? 1.0 : 0.0);
        launcher.setPower(1.0);
        if (gamepad1.a && feederTimer.seconds() > 0.3) {
            feeder.setPosition(1);
            feederTimer.reset();
        } else if (feederTimer.seconds() > 0.15) {
            feeder.setPosition(0);
        }

        LLResult r = limelight.getLatestResult();
        if (r != null && r.isValid()) {
            Pose3D p = r.getBotpose();
            telemetry.addData("Limelight", "tx %.1f  ty %.1f  tags %d", r.getTx(), r.getTy(), r.getFiducialResults().size());
            telemetry.addData("Botpose (m)", "x %.2f  y %.2f  yaw %.0f", p.getPosition().x, p.getPosition().y, p.getOrientation().getYaw());
        } else {
            telemetry.addData("Limelight", "no tags");
        }
        NormalizedRGBA c = intakeColor.getNormalizedColors();
        telemetry.addData("Distance (in)", "%.1f", frontDistance.getDistance(DistanceUnit.INCH));
        telemetry.addData("Intake color", "r %.2f g %.2f b %.2f", c.red, c.green, c.blue);
        telemetry.addData("Bumper", bumper.isPressed());
        telemetry.addData("Runtime", "%.1f s", getRuntime());
    }
}
