# Pedro AutoTune in the simulator

- `com/pedropathing/tuning/autotune/` — a small stand-in written for BEE for the AutoTune framework
  (the real one is the `com.pedropathing:tuning` library with a web page on the Control Hub).
  Inputs keep their default values; results go to `telemetry.log()` as `TUNE <key> <value>`.
- `org/ftcsim/pedrotune/ForesightTuner.java` — the official procedure from the Pedro Quickstart
  (https://github.com/Pedro-Pathing/Quickstart, BSD-style FIRST license), only the package changed.

BEE runs it on the simulated robot so the simulation uses Foresight values that fit the simulated robot.
On the real robot you run AutoTune yourself and type the results in BEE (Auto Builder → Pedro tuning).
