package com.pedropathing.tuning.autotune;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;

/** BEE simulator: one step of an AutoTune procedure (see {@link Procedure}). START is implicit. */
public abstract class TuningOpMode<T> {
    private final String name, description;
    protected HardwareMap hardwareMap;
    LinearOpMode host;

    protected TuningOpMode(String name, String description, boolean stopButton) {
        this.name = name;
        this.description = description;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }

    protected abstract T runTuningOpMode() throws InterruptedException;

    protected void waitForStart() {}
    protected boolean isStopRequested() { return host != null && host.isStopRequested(); }
    protected boolean opModeIsActive() { return host == null || host.opModeIsActive(); }
    protected void idle() { Thread.yield(); }
}
