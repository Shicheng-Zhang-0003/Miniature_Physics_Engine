package com.pedropathing.tuning.autotune;

/** BEE simulator: the AutoTune input forms. There is no page to type in: every field keeps its default. */
public class Inputs {
    public static class Field<T> {
        private T value;
        public Field<T> withDefault(T v) { value = v; return this; }
        public T get() { return value; }
        public void set(T v) { value = v; }
    }

    private final String title, description;

    public Inputs(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public Field<Double> d(String name) { return new Field<Double>(); }
    public Field<String> s(String name) { return new Field<String>(); }
    public Field<Boolean> b(String name) { return new Field<Boolean>(); }
    public <E extends Enum<E>> Field<E> e(String name, Class<E> type) { return new Field<E>(); }
}
