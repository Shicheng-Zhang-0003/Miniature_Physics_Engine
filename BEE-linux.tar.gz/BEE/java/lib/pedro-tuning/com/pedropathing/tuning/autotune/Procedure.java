package com.pedropathing.tuning.autotune;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * BEE simulator: a minimal stand-in for Pedro Pathing's AutoTune framework (com.pedropathing:tuning),
 * so the OFFICIAL tuning procedures (e.g. ForesightTuner from the Pedro Quickstart) run unchanged on the
 * simulated robot. There is no web page: every input takes its default value and the results are
 * collected in {@link #results()}.
 */
public abstract class Procedure {
    public enum Language { JAVA, KOTLIN }

    private final String name, description;
    private final Map<String, Object> results = new LinkedHashMap<>();
    private final Map<Language, String> code = new LinkedHashMap<>();
    LinearOpMode host;

    protected Procedure(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public abstract void run() throws InterruptedException;

    /** Runs the procedure inside an OpMode of the simulator (it gives the hardwareMap and the stop button). */
    public void runIn(LinearOpMode host) throws InterruptedException {
        this.host = host;
        run();
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Map<String, Object> results() { return results; }
    public Map<Language, String> code() { return code; }

    protected Inputs inputs(String title, String description) { return new Inputs(title, description); }
    protected void awaitInputs(Inputs... inputs) {}
    protected void confirmation(String title, String text) {}
    protected void withDisplay(Object display, Runnable body) { body.run(); }
    protected void abort(String why) { throw new IllegalStateException("Tuning aborted: " + why); }
    protected void result(String key, Object value) {
        results.put(key, value);
        if (host != null) host.telemetry.log().add("TUNE " + key + " " + value);
    }
    protected void code(Language language, String text) { code.put(language, text); }

    protected <T> T runOpMode(TuningOpMode<T> opMode) throws InterruptedException {
        if (host != null) {
            if (host.isStopRequested()) throw new InterruptedException("stopped");
            host.telemetry.log().add("TUNE_STEP " + opMode.getName());
        }
        opMode.host = host;
        opMode.hardwareMap = host != null ? host.hardwareMap : null;
        return opMode.runTuningOpMode();
    }
}
