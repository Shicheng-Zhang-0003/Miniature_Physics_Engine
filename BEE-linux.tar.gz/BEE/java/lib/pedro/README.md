# Pedro Pathing 3.0.1 — copy for the BEE simulator

Source: https://github.com/Pedro-Pathing/PedroPathing (BSD 3-Clause, see LICENSE), modules `core`
and `revhub`, unchanged. The simulator runs the REAL Pedro algorithm (Foresight) on the simulated
robot. Not included: the OTOS and OctoQuad localizers (the simulator has no such sensors).

On the real robot you use the published library (see the README of an exported project).
