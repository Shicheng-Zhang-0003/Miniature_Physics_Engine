package com.teamundefined.defined.runner;

import com.teamundefined.defined.Log;

import com.teamundefined.defined.Action;

import java.util.function.BooleanSupplier;
import java.util.function.LongConsumer;
import java.util.function.Supplier;

/**
 * Monitor that does something while a button is held and reverts when it's released.
 *
 * <p><b>Simple form (recommended):</b> give it two steps. While the button is held the first
 * step runs <i>every loop</i> (continuous re-assertion — even if something else nudged the
 * hardware, the next loop puts it back); on release the second step runs once to revert.
 *
 * <pre>{@code
 * new WhilePressedAction("manual_intake", () -> gamepad1.a, runner,
 *     now -> intake.start(false),   // runs every loop while held
 *     now -> intake.stop());        // runs once on release
 * }</pre>
 *
 * <p>This form owns no slots and drives the hardware inline, so it does not go through the
 * runner's slot arbitration — it simply wins by re-asserting every loop. That's the right
 * trade-off for a hold-to-run control.
 *
 * <p><b>Advanced form:</b> supply {@code Supplier<Action>} children instead of steps. Each
 * produced action is dispatched through {@link ActionRunner#startGroup}, so if the children
 * declare slots they get full conflict resolution. Use this when the held behavior must
 * cooperate with other slotted actions.
 */
public class WhilePressedAction extends Action {
    private final BooleanSupplier button;
    private final ActionRunner runner;

    // Simple (inline) form
    private final LongConsumer whileHeldStep;
    private final LongConsumer onReleaseStep;

    // Advanced (dispatch) form
    private final Supplier<Action> whilePressedSupplier;
    private final Supplier<Action> whenReleasedSupplier;

    private final boolean inlineMode;

    private boolean lastButtonState = false;
    private boolean initialized = false;
    private Action currentAction = null; // dispatch form only

    /**
     * Simple form: {@code whileHeldStep} runs every loop while the button is held;
     * {@code onReleaseStep} runs once when it's released (and if this monitor is cancelled
     * while holding).
     */
    public WhilePressedAction(String name,
                              BooleanSupplier button,
                              ActionRunner runner,
                              LongConsumer whileHeldStep,
                              LongConsumer onReleaseStep) {
        super(name, now -> {});
        this.button = button;
        this.runner = runner;
        this.whileHeldStep = whileHeldStep;
        this.onReleaseStep = onReleaseStep;
        this.whilePressedSupplier = null;
        this.whenReleasedSupplier = null;
        this.inlineMode = true;

        this.step = this::runStep;
        this.isComplete = () -> false; // monitor: never completes on its own
        this.withOnCancel(this::cleanup);
    }

    /**
     * Advanced form: each supplier produces an action that is dispatched through the runner.
     * The children carry their own slots; the "while pressed" action should never complete on
     * its own (isComplete {@code -> false}) so it keeps running until released.
     */
    public WhilePressedAction(String name,
                              BooleanSupplier button,
                              ActionRunner runner,
                              Supplier<Action> whilePressedAction,
                              Supplier<Action> whenReleasedAction) {
        super(name, now -> {});
        this.button = button;
        this.runner = runner;
        this.whileHeldStep = null;
        this.onReleaseStep = null;
        this.whilePressedSupplier = whilePressedAction;
        this.whenReleasedSupplier = whenReleasedAction;
        this.inlineMode = false;

        this.step = this::runStep;
        this.isComplete = () -> false; // monitor: never completes on its own
        this.withOnCancel(this::cleanup);
    }

    @Override
    public Action reset() {
        super.reset();
        lastButtonState = false;
        initialized = false;
        currentAction = null;
        return this;
    }

    private void runStep(long now) {
        boolean pressed = button.getAsBoolean();

        if (!initialized) {
            initialized = true;
            lastButtonState = pressed;
            if (pressed) {
                if (inlineMode) whileHeldStep.accept(now);
                else startPressed();
            } else if (!inlineMode) {
                startReleased();
            }
            return;
        }

        if (inlineMode) {
            if (pressed) {
                whileHeldStep.accept(now);              // continuous while held
            } else if (lastButtonState) {
                if (onReleaseStep != null) onReleaseStep.accept(now); // once on release
            }
            lastButtonState = pressed;
            return;
        }

        // Dispatch form: act only on a state change.
        if (pressed != lastButtonState) {
            lastButtonState = pressed;
            if (currentAction != null && !currentAction.inTerminalState()) {
                currentAction.cancel("Button state changed");
            }
            currentAction = null;
            if (pressed) {
                Log.i("WhilePressedAction", name + " - button pressed");
                startPressed();
            } else {
                Log.i("WhilePressedAction", name + " - button released");
                startReleased();
            }
        }
    }

    private void startPressed() {
        if (whilePressedSupplier == null) return;
        Action a = whilePressedSupplier.get();
        if (a == null) return;
        currentAction = a;
        runner.startGroup(a); // dispatched: 'a' carries its own slots
    }

    private void startReleased() {
        if (whenReleasedSupplier == null) return;
        Action a = whenReleasedSupplier.get();
        if (a == null) return;
        currentAction = a;
        runner.startGroup(a);
    }

    private void cleanup(long now) {
        if (inlineMode) {
            // Revert if we were mid-hold when cancelled.
            if (lastButtonState && onReleaseStep != null) onReleaseStep.accept(now);
            lastButtonState = false;
        } else if (currentAction != null && !currentAction.inTerminalState()) {
            currentAction.cancel("Parent monitor cancelled");
            currentAction = null;
        }
    }
}
