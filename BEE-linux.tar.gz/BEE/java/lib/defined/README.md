# Defined (defined-core 0.3.1) — copy for the BEE simulator

Source: https://github.com/cstahie/defined (MIT, see LICENSE). Only `defined-core` is here.

The simulator compiles everything with Java 8 (like the Control Hub). defined-core
calls two Java 9/11 methods, so this copy has two mechanical changes, ONLY for the simulator:

- `s.isBlank()`  ->  `s.trim().isEmpty()`
- `List.of()`    ->  `java.util.Collections.emptyList()`

On the real robot you use the published library (Gradle, see the README of an exported
project); Android's D8 compiler back-ports these methods, so nothing changes there.
