BEE - 3D robot simulator (2026-27 season)
=========================================

BEE is an independent project, not affiliated with FIRST.
FIRST, FIRST Tech Challenge, and BIOBUZZ are registered trademarks of FIRST® (www.firstinspires.org) which is not overseeing, involved with, or responsible for this activity, product, or service.

BEE is free. Nothing to install: Java comes with it (the runtime/ folder), so your
TeamCode compiles and runs in the simulator without a JDK on your computer.

Start it
--------
Windows  Unzip, open the BEE folder, run BEE.exe. If Windows SmartScreen stops it:
         More info -> Run anyway.
macOS    Unzip, move BEE.app to Applications and open it. The app is not signed by
         Apple: the first time, macOS refuses to open it. Go to System Settings ->
         Privacy & Security -> "BEE was blocked" -> Open Anyway.
         (Apple Silicon. On an Intel Mac, install a JDK 17+ from adoptium.net first.)
Linux    tar -xzf BEE-linux.tar.gz, then run BEE/BEE.x86_64.

Keep the files of the BEE folder together (java/ and runtime/ sit next to the game).

Your files
----------
Robots, autos, the code BEE generates and your settings are saved in:
  Windows  %APPDATA%\Godot\app_userdata\ftc_project
  macOS    ~/Library/Application Support/Godot/app_userdata/ftc_project
  Linux    ~/.local/share/godot/app_userdata/ftc_project
Updating BEE (a new download) keeps them.

Not in this download: STEP CAD import (it needs the Python tools of the source project).
Export your CAD as STL or GLB instead: those import directly.

Licenses
--------
The Java runtime is Eclipse Temurin (GPLv2 with the Classpath Exception, see runtime/legal).
The libraries in java/lib keep their own LICENSE files. BEE is made with Godot (MIT).
